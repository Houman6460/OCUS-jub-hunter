/**
 * OCUS PREMIUM Extension Popup Script
 * Manages premium usage display and statistics
 */

// Initialize popup
document.addEventListener('DOMContentLoaded', function() {
  initializePopup();
});

/**
 * Initialize popup functionality
 */
async function initializePopup() {
  console.log('PREMIUM popup initializing...');
  
  // Load and display premium statistics
  await updatePremiumStats();
  
  // Set up refresh interval
  setInterval(updatePremiumStats, 10000); // Update every 10 seconds
}

/**
 * Update premium statistics display
 */
async function updatePremiumStats() {
  try {
    // Get premium usage data from storage
    const premiumData = await new Promise((resolve) => {
      chrome.storage.local.get(['premium_usage_data'], (result) => {
        const data = result.premium_usage_data || {
          totalMissions: 0,
          lastUsed: null,
          sessionStart: new Date().toISOString()
        };
        resolve(data);
      });
    });
    
    // Update UI elements
    const totalMissionsElement = document.getElementById('totalMissions');
    const sessionInfoElement = document.getElementById('sessionInfo');
    
    if (totalMissionsElement) {
      totalMissionsElement.textContent = premiumData.totalMissions || 0;
    }
    
    if (sessionInfoElement && premiumData.sessionStart) {
      const sessionDate = new Date(premiumData.sessionStart);
      const formattedDate = sessionDate.toLocaleDateString() + ' ' + 
                           sessionDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
      sessionInfoElement.textContent = `Session started: ${formattedDate}`;
    }
    
    console.log('Premium statistics updated:', premiumData);
    
  } catch (error) {
    console.error('Error updating premium statistics:', error);
    
    // Default display on error
    const totalMissionsElement = document.getElementById('totalMissions');
    const sessionInfoElement = document.getElementById('sessionInfo');
    
    if (totalMissionsElement) totalMissionsElement.textContent = '0';
    if (sessionInfoElement) sessionInfoElement.textContent = 'Session started: Just now';
  }
}