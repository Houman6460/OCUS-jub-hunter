/**
 * OCUS Unified Extension - New Mission Acceptor
 * 
 * A clean implementation focused exclusively on reliably accepting missions
 * when opened in a mission page.
 */

// Configuration
const CONFIG = {
  enabled: true,
  autoRedirect: true,
  redirectDelay: 3000, // 3 seconds - as requested by user
  maxAttempts: 20,
  attemptInterval: 800, // Faster interval to ensure we catch the button quickly
  debug: true, // Set to true for detailed logging
  homepage: 'https://app.ocus.com/' // Homepage URL to redirect to after acceptance
};

/**
 * Check trial status - returns whether user can accept missions
 */
async function checkTrialStatus() {
  return new Promise((resolve) => {
    try {
      // Check if user is activated
      chrome.storage.local.get(['isActivated', 'trialUsed'], (result) => {
        if (chrome.runtime.lastError) {
          log('Chrome storage error, assuming trial active');
          resolve({ canAccept: true, remaining: 3 });
          return;
        }
        
        // If activated, unlimited usage
        if (result.isActivated) {
          resolve({ canAccept: true, remaining: 'unlimited' });
          return;
        }
        
        // Check trial usage
        const trialUsed = result.trialUsed || 0;
        const remaining = Math.max(0, 3 - trialUsed);
        
        log(`Trial status: ${trialUsed}/3 used, ${remaining} remaining`);
        resolve({ 
          canAccept: remaining > 0, 
          remaining: remaining 
        });
      });
    } catch (error) {
      log('Error checking trial status:', error);
      // Default to allowing usage if we can't check
      resolve({ canAccept: true, remaining: 3 });
    }
  });
}

// State tracking
let missionAccepted = false;
let attemptCount = 0;
let attemptTimer = null;

/**
 * Initialize the mission acceptor
 */
async function init() {
  log('Mission acceptor initializing...');
  
  // Check trial status first
  const trialStatus = await checkTrialStatus();
  if (!trialStatus.canAccept) {
    log('Trial exhausted, mission acceptor disabled');
    showStatus('Trial exhausted! Enter activation code to continue.', 'error');
    return;
  }
  
  // Only run on mission pages
  if (!isMissionPage()) {
    log('Not a mission page, skipping initialization');
    return;
  }
  
  // Show status
  showStatus('Looking for Accept button...', 'info');
  
  // Start looking for the accept button
  startAcceptProcess();
  
  // Set up a mutation observer to detect DOM changes
  setupMutationObserver();
  
  log('Mission acceptor initialized successfully');
}

/**
 * Check if the current page is a mission page
 * @returns {boolean} True if the current page appears to be a mission page
 */
function isMissionPage() {
  // Check URL pattern - with updated pattern to match both mission and missions URLs
  const url = window.location.href;
  
  // Explicit check for the URL pattern the user specified
  if (url.includes('app.ocus.com/missions/')) {
    log('Detected mission page from exact URL pattern: app.ocus.com/missions/');
    return true;
  }
  
  // Also check other common patterns as fallback
  if (url.includes('/mission/') || 
      url.includes('/assignments/') || 
      url.includes('ocus.com/assignment')) {
    log('Detected mission page from URL pattern');
    return true;
  }
  
  // Check for the exact button the user specified
  try {
    const exactButton = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (exactButton) {
      const buttonText = (exactButton.innerText || exactButton.textContent || '').trim();
      if (buttonText === 'Accept assignment') {
        log('Detected mission page from exact button match');
        return true;
      }
    }
  } catch (error) {
    log('Error checking for button', error);
  }
  
  // Check for other mission-specific elements
  const missionIndicators = [
    'div[data-test="mission-details"]',
    '.mission-details',
    '.mission-header'
  ];
  
  for (const selector of missionIndicators) {
    try {
      const elements = document.querySelectorAll(selector);
      if (elements && elements.length > 0) {
        log(`Detected mission page from element: ${selector}`);
        return true;
      }
    } catch (error) {
      // Some selectors might not work in all browsers
    }
  }
  
  return false;
}

/**
 * Start the process of finding and clicking the accept button
 */
function startAcceptProcess() {
  attemptCount = 0;
  attemptAcceptMission();
}

/**
 * Attempt to find and click the accept button
 */
async function attemptAcceptMission() {
  // Don't proceed if mission is already accepted or disabled
  if (missionAccepted || !CONFIG.enabled) {
    return;
  }
  
  // Check trial status before each attempt
  const trialStatus = await checkTrialStatus();
  if (!trialStatus.canAccept) {
    log('Trial exhausted during attempt, stopping mission acceptor');
    showStatus('Trial exhausted! Enter activation code to continue.', 'error');
    CONFIG.enabled = false; // Disable the acceptor
    return;
  }
  
  attemptCount++;
  log(`Attempting to accept mission (${attemptCount}/${CONFIG.maxAttempts})`);
  
  // Find the accept button
  const acceptButton = findAcceptButton();
  
  if (acceptButton) {
    log('Found accept button! Attempting to click it...');
    logButtonDetails(acceptButton);
    
    // Make sure button is visible
    scrollButtonIntoView(acceptButton);
    
    // Click with delay to ensure UI is stable
    setTimeout(() => {
      if (clickAcceptButton(acceptButton)) {
        handleAcceptSuccess();
      } else {
        scheduleNextAttempt();
      }
    }, 500);
  } else {
    log('Accept button not found in this attempt');
    scheduleNextAttempt();
  }
}

/**
 * Schedule the next attempt to find and click the accept button
 */
function scheduleNextAttempt() {
  // Stop after max attempts
  if (attemptCount >= CONFIG.maxAttempts) {
    showStatus('Failed to accept mission after multiple attempts', 'error');
    log('Maximum attempts reached, giving up');
    return;
  }
  
  // Schedule next attempt
  log(`Scheduling next attempt in ${CONFIG.attemptInterval}ms`);
  clearTimeout(attemptTimer);
  attemptTimer = setTimeout(attemptAcceptMission, CONFIG.attemptInterval);
}

/**
 * Find the accept assignment button using multiple strategies with exact focus on the user-specified button
 * @returns {Element|null} The accept button element or null if not found
 */
function findAcceptButton() {
  // Debug logging - print the total number of buttons on the page
  const allPageButtons = document.querySelectorAll('button');
  log(`Scanning ${allPageButtons.length} buttons on the page for Accept assignment button`);
  
  // Strategy 1: Find by specific data-test attribute (most reliable)
  const dataTestButton = document.querySelector('button[data-test="accept-assignment-btn"]');
  if (dataTestButton && isVisible(dataTestButton)) {
    log('Found accept button by data-test attribute');
    logButtonDetails(dataTestButton);
    return dataTestButton;
  }
  
  // Strategy 2: Find by the exact class combination from user example
  const exactClassButton = document.querySelector('button.button.my-4[data-test="accept-assignment-btn"]');
  if (exactClassButton && isVisible(exactClassButton)) {
    log('Found accept button by exact class combination');
    logButtonDetails(exactClassButton);
    return exactClassButton;
  }
  
  // Strategy 3: Try even more specific attributes from user example
  try {
    const vueButtons = document.querySelectorAll('button[data-v-1d1d488e][data-v-c6eed17c]');
    log(`Found ${vueButtons.length} buttons with Vue-specific data attributes`);
    
    for (const btn of vueButtons) {
      if (isVisible(btn) && (btn.innerText || btn.textContent || '').trim() === 'Accept assignment') {
        log('Found accept button by Vue data attributes');
        logButtonDetails(btn);
        return btn;
      }
    }
  } catch (error) {
    // Vue attributes might not be consistent across versions
    log('Error searching for Vue buttons:', error.message);
  }
  
  // Strategy 4: Find by exact text content
  const allButtons = Array.from(document.querySelectorAll('button'));
  const textMatchButton = allButtons.find(btn => {
    const text = btn.innerText || btn.textContent || '';
    return text.trim() === 'Accept assignment' && isVisible(btn);
  });
  
  if (textMatchButton) {
    log('Found accept button by exact text match');
    logButtonDetails(textMatchButton);
    return textMatchButton;
  }
  
  // Strategy 5: Combination approach - prioritize buttons with certain classes
  const classMatchButtons = allButtons.filter(btn => {
    const classes = btn.className || '';
    return classes.includes('button') && classes.includes('my-4') && isVisible(btn);
  });
  
  log(`Found ${classMatchButtons.length} buttons with class 'button' and 'my-4'`);
  
  for (const btn of classMatchButtons) {
    const text = (btn.innerText || btn.textContent || '').trim();
    if (text === 'Accept assignment' || text.toLowerCase().includes('accept')) {
      log('Found accept button by class and text combination');
      logButtonDetails(btn);
      return btn;
    }
  }
  
  // Strategy 6: Try partial text matching on all buttons as a last resort
  log('Trying partial text matching as last resort...');
  for (const btn of allButtons) {
    if (!isVisible(btn)) continue;
    
    const text = (btn.innerText || btn.textContent || '').trim().toLowerCase();
    if (text.includes('accept') && (text.includes('assignment') || text.includes('mission'))) {
      log('Found button with accept + assignment/mission text');
      logButtonDetails(btn);
      return btn;
    }
  }
  
  log('No accept button found after trying all detection strategies');
  return null;
}

/**
 * Check if an element is visible
 * @param {Element} element - The element to check
 * @returns {boolean} True if the element is visible
 */
function isVisible(element) {
  if (!element) return false;
  
  const style = window.getComputedStyle(element);
  return style.display !== 'none' && 
         style.visibility !== 'hidden' && 
         style.opacity !== '0' &&
         element.offsetWidth > 0 && 
         element.offsetHeight > 0;
}

/**
 * Scroll the button into view
 * @param {Element} button - The button to scroll into view
 */
function scrollButtonIntoView(button) {
  if (!button || !button.scrollIntoView) return;
  
  try {
    button.scrollIntoView({ behavior: 'auto', block: 'center' });
    log('Scrolled button into view');
  } catch (error) {
    log('Failed to scroll button into view', error);
  }
}

/**
 * Click the accept button using multiple reliable methods
 * @param {Element} button - The button to click
 * @returns {boolean} True if at least one click method succeeded
 */
function clickAcceptButton(button) {
  if (!button) return false;
  
  let clickSucceeded = false;
  
  // Before attempting to click, ensure the button is in view
  scrollButtonIntoView(button);
  
  // Method 1: Native click (most reliable)
  try {
    log('Attempting native click method');
    button.click();
    clickSucceeded = true;
    log('Native click succeeded');
  } catch (error) {
    log('Native click failed', error);
  }
  
  return clickSucceeded;
}

/**
 * Handle successful mission acceptance
 */
async function handleAcceptSuccess() {
  log('Mission accepted successfully!');
  missionAccepted = true;
  showStatus('Mission accepted! Redirecting...', 'success');
  
  // Play success sound if enabled
  try {
    chrome.storage.local.get(['config'], (result) => {
      const config = result.config || {};
      if (config.sounds && config.sounds.enabled && config.sounds.missionAccepted) {
        if (typeof window.playSound === 'function') {
          window.playSound('missionAccepted');
          log('Playing mission accepted sound');
        }
      }
    });
  } catch (error) {
    log('Error playing success sound:', error);
  }
  
  // Clear any pending attempts
  clearTimeout(attemptTimer);
  
  // Update trial tracking and counters after successful click
  try {
    await updateTrialAndCounters();
  } catch (error) {
    log('Error updating trial and counters:', error);
  }
  
  // Redirect to homepage by clicking Home navigation after delay
  if (CONFIG.autoRedirect) {
    setTimeout(() => {
      log(`Redirecting to homepage after ${CONFIG.redirectDelay}ms by clicking Home navigation`);
      
      // Find and click the Home navigation element
      const homeElements = document.querySelectorAll('a[href="/"]');
      let homeLink = null;
      
      // Look for the Home link that contains the "Home" text
      for (const link of homeElements) {
        const homeSpan = link.querySelector('span.tw-border-orange');
        if (homeSpan && homeSpan.textContent.trim() === 'Home') {
          homeLink = link;
          break;
        }
      }
      
      // Fallback: look for any link with "Home" text
      if (!homeLink) {
        for (const link of homeElements) {
          if (link.textContent.includes('Home')) {
            homeLink = link;
            break;
          }
        }
      }
      
      // Click the home link if found
      if (homeLink) {
        log('Found Home navigation element, clicking it');
        homeLink.click();
      } else {
        // Fallback: try clicking the logo
        const logo = document.querySelector('a[href="/"] img') || document.querySelector('a.nux');
        if (logo) {
          log('Home navigation not found, clicking logo instead');
          const logoLink = logo.closest('a');
          if (logoLink) {
            logoLink.click();
          }
        } else {
          log('Could not find Home navigation or logo, using URL redirect as fallback');
          window.location.href = CONFIG.homepage;
        }
      }
    }, CONFIG.redirectDelay);
  }
}

/**
 * Update trial usage and mission counters after successful acceptance
 */
async function updateTrialAndCounters() {
  try {
    // Get current trial status
    chrome.storage.local.get(['isActivated', 'trialUsed'], async (result) => {
      if (!result.isActivated) {
        // Update trial usage
        const trialUsed = (result.trialUsed || 0) + 1;
        const remaining = Math.max(0, 3 - trialUsed);
        
        // Save updated trial usage
        chrome.storage.local.set({ trialUsed: trialUsed }, () => {
          log(`Trial mission accepted. Used: ${trialUsed}/3, Remaining: ${remaining}`);
          
          // Show floating notification with remaining count
          showTrialNotification(remaining);
          
          // Update panel counter if it exists
          updatePanelCounter(trialUsed, remaining);
          
          // Send message to update trial counter in floating panel
          chrome.runtime.sendMessage({
            type: 'UPDATE_TRIAL_COUNTER',
            remaining: remaining
          });
          
          // If no uses remaining, show activation prompt
          if (remaining === 0) {
            setTimeout(() => {
              showStatus('🚀 Trial Complete! Activate for unlimited missions', 'info');
              
              // Show activation prompt
              if (confirm('🎉 You\'ve used all 3 free trial missions! Ready to unlock unlimited mission acceptance?')) {
                window.open('https://jobhunter.one/', '_blank');
              }
            }, 2000);
          }
        });
      } else {
        // Activated user - just update counter
        const currentCount = parseInt(localStorage.getItem('ocus_missions_accepted') || '0') + 1;
        localStorage.setItem('ocus_missions_accepted', currentCount.toString());
        log(`Activated user - mission count: ${currentCount}`);
        updatePanelCounter(currentCount, 'unlimited');
      }
      
      // Update mission accepted counter in stats
      chrome.storage.local.get(['stats'], (statsResult) => {
        const stats = statsResult.stats || {};
        stats.missionsAccepted = (stats.missionsAccepted || 0) + 1;
        chrome.storage.local.set({ stats: stats });
      });
    });
  } catch (error) {
    log('Trial update error:', error);
    // Fallback: update basic counter
    const currentCount = parseInt(localStorage.getItem('ocus_missions_accepted') || '0') + 1;
    localStorage.setItem('ocus_missions_accepted', currentCount.toString());
    updatePanelCounter(currentCount, 'unknown');
  }
}

/**
 * Show floating trial notification
 */
function showTrialNotification(remaining) {
  // Create floating notification
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 600;
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    z-index: 10000;
    animation: slideInRight 0.3s ease-out;
    cursor: pointer;
  `;
  
  if (remaining > 0) {
    notification.textContent = `🔥 TRIAL MODE: ${remaining} mission acceptance${remaining === 1 ? '' : 's'} remaining!`;
  } else {
    notification.textContent = `⚠️ TRIAL EXPIRED! Activate for unlimited missions`;
    notification.style.background = 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)';
  }
  
  // Add close functionality
  notification.addEventListener('click', () => {
    notification.remove();
  });
  
  document.body.appendChild(notification);
  
  // Auto-remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove();
    }
  }, 5000);
  
  log(`Showed trial notification: ${remaining} remaining`);
}

/**
 * Update panel counter display - targets the specific OCUS Hunter panel structure
 */
function updatePanelCounter(accepted, remaining) {
  try {
    // Method 1: Update via DOM manipulation - find the ACCEPTED counter directly
    const acceptedElements = Array.from(document.querySelectorAll('div')).filter(div => {
      const text = div.textContent?.trim();
      return text === 'ACCEPTED' && div.nextElementSibling && div.nextElementSibling.textContent?.match(/^\d+$/);
    });
    
    acceptedElements.forEach(acceptedLabel => {
      const numberDiv = acceptedLabel.nextElementSibling;
      if (numberDiv) {
        numberDiv.textContent = accepted.toString();
        log(`Updated ACCEPTED counter to: ${accepted}`);
      }
    });
    
    // Method 2: Update via extension storage for persistent counter
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.set({
        'ocus_missions_accepted': accepted,
        'ocus_last_mission_time': Date.now()
      }, () => {
        log(`Stored mission count: ${accepted}`);
      });
    }
    
    // Method 3: Update localStorage as backup
    localStorage.setItem('ocus_missions_accepted', accepted.toString());
    localStorage.setItem('ocus_last_mission_time', Date.now().toString());
    
    // Method 4: Try to find by more specific selectors
    const panelCounters = [
      // Look for the specific panel structure
      document.querySelector('.ocus-hunter-panel .accepted-count'),
      document.querySelector('#ocus-panel [data-stat="accepted"]'),
      document.querySelector('.extension-panel .missions-accepted'),
      // Generic counter selectors
      document.querySelector('[data-counter="missions-accepted"]'),
      document.querySelector('.missions-accepted-count'),
      document.querySelector('#missions-counter')
    ].filter(el => el);
    
    panelCounters.forEach(element => {
      if (remaining === 'unlimited') {
        element.textContent = accepted.toString();
      } else if (remaining === 'unknown') {
        element.textContent = accepted.toString();
      } else {
        element.textContent = accepted.toString();
      }
      log(`Updated panel counter element: ${element.className || element.id}`);
    });
    
    // Method 5: Update Chrome extension stats through storage
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['stats'], (result) => {
        let stats = result.stats || {
          missionsFound: 0,
          missionsOpened: 0,
          missionsAccepted: 0,
          loginAttempts: 0,
          successfulLogins: 0
        };
        stats.missionsAccepted = accepted;
        chrome.storage.local.set({ stats: stats }, () => {
          log(`Updated Chrome extension stats: ${accepted} missions accepted`);
        });
      });
      
      // Also send message to popup to update display immediately
      chrome.runtime.sendMessage({
        type: 'UPDATE_MISSION_COUNTER',
        count: accepted
      }, (response) => {
        log('Sent counter update to popup');
      });
    }
    
    // Method 6: Look for panel by walking the DOM tree for blue number displays
    const allDivs = document.querySelectorAll('div');
    allDivs.forEach(div => {
      const text = div.textContent?.trim();
      const style = window.getComputedStyle(div);
      
      // Look for blue colored number displays that could be the counter
      if (text && text.match(/^\d+$/) && (
        style.color.includes('rgb(59, 130, 246)') || // Tailwind blue-500
        style.color.includes('rgb(37, 99, 235)') ||  // Tailwind blue-600
        style.color.includes('#3b82f6') ||           // Hex blue
        style.color.includes('#2563eb') ||           // Hex blue-600
        div.className.includes('blue') ||
        div.parentElement?.textContent?.includes('ACCEPTED')
      )) {
        div.textContent = accepted.toString();
        log(`Updated blue counter div: ${div.className} to ${accepted}`);
      }
    });
    
    // Method 7: Broadcast update event for any listening panels
    window.dispatchEvent(new CustomEvent('missionCounterUpdate', {
      detail: { accepted, remaining, timestamp: Date.now() }
    }));
    
    // Method 8: Direct window variable for immediate access
    window.ocusMissionsAccepted = accepted;
    window.ocusLastMissionTime = Date.now();
    
    log(`Updated all panel counters: ${accepted} accepted, ${remaining} remaining`);
  } catch (error) {
    log('Error updating panel counter:', error);
  }
}

/**
 * Set up mutation observer to detect DOM changes
 */
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    if (missionAccepted) return;
    
    // Only observe if we haven't found the button yet
    const hasButton = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (hasButton && !missionAccepted) {
      log('Mutation observer detected new button, attempting click');
      attemptAcceptMission();
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'data-test']
  });
  
  log('Mutation observer set up successfully');
}

/**
 * Log button details for debugging
 * @param {Element} button - The button to log details for
 */
function logButtonDetails(button) {
  if (!button) return;
  
  const details = {
    tagName: button.tagName,
    className: button.className,
    id: button.id,
    text: (button.innerText || button.textContent || '').trim(),
    dataTest: button.getAttribute('data-test'),
    visible: isVisible(button),
    disabled: button.disabled,
    offsetWidth: button.offsetWidth,
    offsetHeight: button.offsetHeight
  };
  
  log('Button details:', details);
}

/**
 * Show status message to user
 * @param {string} message - The message to show
 * @param {string} type - The type of message (info, success, error)
 */
function showStatus(message, type = 'info') {
  console.log(`[OCUS Mission Acceptor] ${message}`);
  
  // You can enhance this to show UI notifications
  // For now, just log to console
}

/**
 * Enhanced logging function
 * @param {...any} args - Arguments to log
 */
function log(...args) {
  if (CONFIG.debug) {
    console.log('[Mission Acceptor]', ...args);
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { init, findAcceptButton, clickAcceptButton };
}