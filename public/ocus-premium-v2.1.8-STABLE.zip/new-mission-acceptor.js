/**
 * OCUS PREMIUM Mission Acceptor Script
 * Version: 2.1.8-PREMIUM-UNLIMITED
 * Features:
 * - Unlimited mission acceptance for premium users
 * - No trial restrictions or limitations
 * - Full functionality across all sessions and browsers
 * - Sound feedback and floating counter panel
 * - Auto-navigation to home page after acceptance
 */

// Configuration
const CONFIG = {
  enabled: true,
  autoRedirect: true,
  redirectDelay: 3000,
  maxAttempts: 20,
  attemptInterval: 800,
  debug: true,
  homepage: 'https://app.ocus.com/'
};

// State tracking
let missionAccepted = false;
let attemptCount = 0;
let attemptTimer = null;

/**
 * Track premium usage for statistics
 */
async function trackPremiumUsage(missionId) {
  try {
    const usage = await new Promise((resolve) => {
      chrome.storage.local.get(['premium_usage_data'], (result) => {
        const data = result.premium_usage_data || { 
          totalMissions: 0, 
          lastUsed: null,
          sessionStart: new Date().toISOString()
        };
        
        data.totalMissions += 1;
        data.lastUsed = new Date().toISOString();
        
        chrome.storage.local.set({ premium_usage_data: data }, () => {
          resolve(data);
        });
      });
    });
    
    log('Premium usage tracked:', usage);
    return usage;
  } catch (error) {
    log('Error tracking premium usage:', error);
    return { totalMissions: 1, unlimited: true };
  }
}

/**
 * Initialize the mission acceptor
 */
async function init() {
  log('PREMIUM Mission acceptor initializing...');
  
  // Only run on mission pages
  if (!isMissionPage()) {
    log('Not a mission page, skipping initialization');
    return;
  }
  
  // Show premium status
  showStatus('Premium Mode - Unlimited Access', 'premium');
  
  // Start looking for the accept button
  startAcceptProcess();
  
  // Set up a mutation observer to detect DOM changes
  setupMutationObserver();
  
  log('PREMIUM Mission acceptor initialized successfully');
}

/**
 * Check if the current page is a mission page
 */
function isMissionPage() {
  const url = window.location.href;
  
  if (url.includes('app.ocus.com/missions/')) {
    log('Detected mission page from exact URL pattern: app.ocus.com/missions/');
    return true;
  }
  
  if (url.includes('app.ocus.com/mission/')) {
    log('Detected mission page from URL pattern: app.ocus.com/mission/');
    return true;
  }
  
  if (url.includes('.ocus.work/mission')) {
    log('Detected mission page from ocus.work pattern');
    return true;
  }
  
  return false;
}

/**
 * Start the accept process
 */
function startAcceptProcess() {
  if (missionAccepted || attemptCount >= CONFIG.maxAttempts) {
    return;
  }
  
  attemptTimer = setTimeout(() => {
    attemptAccept();
  }, CONFIG.attemptInterval);
}

/**
 * Attempt to accept the mission
 */
async function attemptAccept() {
  if (missionAccepted) return;
  
  attemptCount++;
  log(`Accept attempt ${attemptCount}/${CONFIG.maxAttempts}`);
  
  // Find accept button
  const acceptButton = findAcceptButton();
  
  if (acceptButton) {
    log('Accept button found! Attempting to click...');
    
    try {
      // Track premium usage for statistics
      const missionId = window.location.pathname.split('/').pop();
      const usage = await trackPremiumUsage(missionId);
      
      // Click the button
      acceptButton.click();
      missionAccepted = true;
      
      // Update counter
      updatePanelCounter('ACCEPTED');
      
      // Show success message
      showStatus(`Mission accepted! Total: ${usage.totalMissions}`, 'success');
      
      // Play success sound
      playAcceptSound();
      
      // Auto redirect after delay
      if (CONFIG.autoRedirect) {
        setTimeout(() => {
          log('Auto-redirecting to homepage...');
          window.location.href = CONFIG.homepage;
        }, CONFIG.redirectDelay);
      }
      
      return;
      
    } catch (error) {
      log('Error during mission acceptance:', error);
    }
  }
  
  // Continue trying if not reached max attempts
  if (attemptCount < CONFIG.maxAttempts) {
    startAcceptProcess();
  } else {
    log('Max attempts reached, giving up');
    showStatus('Could not find Accept button', 'error');
  }
}

/**
 * Find the accept button using various selectors
 */
function findAcceptButton() {
  const selectors = [
    'button:contains("Accept")',
    'button[class*="accept" i]',
    'a:contains("Accept")',
    'button:contains("ACCEPT")',
    'button[data-testid*="accept"]',
    '[role="button"]:contains("Accept")',
    '.btn:contains("Accept")',
    'button[type="submit"]:contains("Accept")',
    'button:contains("ACEPTAR")', // Spanish
    'button:contains("ACCETTO")' // Italian
  ];
  
  for (const selector of selectors) {
    try {
      if (selector.includes(':contains')) {
        const text = selector.match(/:contains\("(.+)"\)/)?.[1];
        if (text) {
          const elements = document.querySelectorAll(selector.split(':contains')[0] || 'button');
          for (const element of elements) {
            if (element.textContent.trim().toUpperCase().includes(text.toUpperCase())) {
              return element;
            }
          }
        }
      } else {
        const element = document.querySelector(selector);
        if (element && element.offsetParent !== null) {
          return element;
        }
      }
    } catch (error) {
      // Ignore selector errors
    }
  }
  
  return null;
}

/**
 * Set up mutation observer to detect DOM changes
 */
function setupMutationObserver() {
  if (missionAccepted) return;
  
  const observer = new MutationObserver((mutations) => {
    if (missionAccepted) return;
    
    let shouldCheck = false;
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        shouldCheck = true;
      }
    });
    
    if (shouldCheck) {
      // Clear existing timer and start new attempt
      if (attemptTimer) {
        clearTimeout(attemptTimer);
      }
      setTimeout(() => attemptAccept(), 500);
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  // Clean up after 30 seconds
  setTimeout(() => {
    observer.disconnect();
  }, 30000);
}

// Utility functions
function log(message, ...args) {
  if (CONFIG.debug) {
    console.log(`[PREMIUM Mission Acceptor] ${message}`, ...args);
  }
}

function showStatus(message, type = 'info') {
  // Implementation for status display
  const statusElement = document.getElementById('ocus-status');
  if (statusElement) {
    statusElement.textContent = message;
    statusElement.className = `ocus-status ${type}`;
  }
}

function updatePanelCounter(type) {
  // Implementation for counter update
  try {
    chrome.storage.local.get(['ocusCounters'], (result) => {
      const counters = result.ocusCounters || {};
      counters[type] = (counters[type] || 0) + 1;
      chrome.storage.local.set({ ocusCounters: counters });
    });
  } catch (error) {
    log('Error updating counter:', error);
  }
}

function playAcceptSound() {
  try {
    const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ1/LNeSsFJHfH8N2QQAoUXrTp66hVFApGn+DyvmYdBDSJ');
    audio.volume = 0.3;
    audio.play();
  } catch (error) {
    log('Error playing sound:', error);
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Also initialize after a short delay in case of dynamic content
setTimeout(init, 1000);