/**
 * OCUS Unified Extension - Helper Functions
 * 
 * This script provides common utility functions for all OCUS extension scripts.
 * It runs at document_start to ensure functions are available early.
 */

// Global namespace for OCUS helpers
window.ocusHelpers = window.ocusHelpers || {};

// Check if an element is visible (not hidden by CSS)
window.ocusHelpers.isVisibleElement = function(element) {
  if (!element) return false;
  
  const style = window.getComputedStyle(element);
  
  return style.display !== 'none' && 
         style.visibility !== 'hidden' && 
         style.opacity !== '0' &&
         element.offsetWidth > 0 && 
         element.offsetHeight > 0;
};

// Check if an element is clickable
window.ocusHelpers.isClickable = function(element) {
  if (!element) return false;
  
  // Check if visible first
  if (!window.ocusHelpers.isVisibleElement(element)) return false;
  
  // Check if not disabled
  if (element.hasAttribute('disabled') || 
      element.classList.contains('disabled')) {
    return false;
  }
  
  return true;
};

// Safely add styles to document.head even if it's not ready yet
window.ocusHelpers.safeAppendStyles = function(cssText, id) {
  const style = document.createElement('style');
  style.textContent = cssText;
  
  if (id) {
    style.id = id;
  }
  
  // Make sure we don't add duplicate styles
  if (id && document.getElementById(id)) {
    return;
  }
  
  // Function to actually append the style
  const appendStyle = function() {
    if (document.head) {
      document.head.appendChild(style);
    } else {
      // If document.head isn't available yet, try again later
      setTimeout(appendStyle, 10);
    }
  };
  
  appendStyle();
};

// Show a status message (overlay)
window.ocusHelpers.showStatusMessage = function(message, success) {
  // Create or get status container
  let container = document.getElementById('ocus-status-container');
  
  if (!container) {
    container = document.createElement('div');
    container.id = 'ocus-status-container';
    
    // Apply styles
    container.style.position = 'fixed';
    container.style.bottom = '10px';
    container.style.right = '10px';
    container.style.zIndex = '9999';
    container.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    container.style.color = 'white';
    container.style.padding = '10px 15px';
    container.style.borderRadius = '5px';
    container.style.fontFamily = 'Arial, sans-serif';
    container.style.fontSize = '14px';
    container.style.transition = 'opacity 0.3s';
    
    document.body.appendChild(container);
  }
  
  // Set the message
  container.textContent = message;
  
  // Apply status-specific styles
  if (success === true) {
    container.style.backgroundColor = 'rgba(46, 125, 50, 0.9)';
  } else if (success === false) {
    container.style.backgroundColor = 'rgba(211, 47, 47, 0.9)';
  } else {
    container.style.backgroundColor = 'rgba(33, 150, 243, 0.9)';
  }
  
  // Show the container
  container.style.opacity = '1';
  
  // Auto-hide after 3 seconds
  setTimeout(() => {
    container.style.opacity = '0';
  }, 3000);
};

// Find parent element matching selector or class
window.ocusHelpers.findParentElement = function(element, selector) {
  // Check if we're past the document body or hit the maximum number of iterations
  if (!element || element === document.body) {
    return null;
  }
  
  // Check if current element matches the selector
  if (selector.startsWith('.')) {
    // Class selector
    const className = selector.substring(1);
    if (element.classList.contains(className)) {
      return element;
    }
  } else if (selector.startsWith('#')) {
    // ID selector
    const id = selector.substring(1);
    if (element.id === id) {
      return element;
    }
  } else {
    // Tag selector or complex selector
    if (element.matches && element.matches(selector)) {
      return element;
    }
  }
  
  // Recurse to parent
  return window.ocusHelpers.findParentElement(element.parentElement, selector);
};

// Find first visible element matching selector
window.ocusHelpers.findVisibleElement = function(container, selector) {
  const elements = container.querySelectorAll(selector);
  
  for (const element of elements) {
    if (window.ocusHelpers.isVisibleElement(element)) {
      return element;
    }
  }
  
  return null;
};

// Simple event emitter
window.ocusHelpers.eventEmitter = {
  events: {},
  
  on: function(event, callback) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(callback);
  },
  
  emit: function(event, data) {
    if (this.events[event]) {
      this.events[event].forEach(callback => callback(data));
    }
  }
};

console.log('OCUS Helper Functions loaded');
