/**
 * OCUS Unified Extension - Sound Manager
 * 
 * Handles audio alerts for various extension events
 */

// Sound configuration
const SOUNDS = {
  // When a new mission is found and opened
  newMission: {
    frequency: 880, // A5
    type: 'triangle',
    duration: 200,
    pattern: [1, 0, 1], // Beep-pause-beep
    volume: 0.7
  },
  // When a mission is successfully accepted
  missionAccepted: {
    frequency: 600, // D5
    type: 'sine',
    duration: 300,
    pattern: [1, 0, 1, 0, 1], // Triple beep
    volume: 0.8
  }
};

// Audio context instance
let audioContext = null;

/**
 * Initialize the audio context when needed
 * This helps to avoid the "AudioContext was not allowed to start" error
 * by creating the context only after user interaction
 */
function initAudioContext() {
  if (!audioContext) {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioContext = new AudioContext();
      console.log('[OCUS Sound] AudioContext initialized');
    } catch (error) {
      console.error('[OCUS Sound] Error initializing AudioContext:', error);
    }
  }
  return audioContext;
}

/**
 * Play a sound by its identifier
 * @param {string} soundId - The ID of the sound to play (e.g., 'newMission', 'missionAccepted')
 * @returns {Promise} Resolves when the sound is done playing
 */
function playSound(soundId) {
  const context = initAudioContext();
  if (!context) return Promise.resolve(); // No audio context available
  
  const soundConfig = SOUNDS[soundId];
  if (!soundConfig) {
    console.error(`[OCUS Sound] Unknown sound: ${soundId}`);
    return Promise.resolve();
  }
  
  console.log(`[OCUS Sound] Playing sound: ${soundId}`);
  
  // Resume audio context if it's suspended (browser policy)
  if (context.state === 'suspended') {
    context.resume();
  }
  
  return playPattern(soundConfig);
}

/**
 * Play a sound pattern based on the configuration
 * @param {Object} config - Sound configuration
 * @returns {Promise} Resolves when the pattern is done playing
 */
function playPattern(config) {
  return new Promise((resolve) => {
    const context = audioContext;
    const pattern = config.pattern || [1];
    const duration = config.duration || 200;
    const totalDuration = pattern.length * duration;
    
    let time = context.currentTime;
    
    // Play each note in the pattern
    pattern.forEach((play, index) => {
      if (play) {
        const oscillator = context.createOscillator();
        const gainNode = context.createGain();
        
        oscillator.type = config.type || 'sine';
        oscillator.frequency.value = config.frequency;
        
        gainNode.gain.value = config.volume || 0.5;
        
        oscillator.connect(gainNode);
        gainNode.connect(context.destination);
        
        // Schedule start and stop times
        oscillator.start(time);
        oscillator.stop(time + (duration / 1000));
        
        // Quick fade out to avoid clicks
        gainNode.gain.setValueAtTime(config.volume || 0.5, time + (duration / 1000) - 0.05);
        gainNode.gain.linearRampToValueAtTime(0, time + (duration / 1000));
      }
      
      // Move to the next time slot
      time += duration / 1000;
    });
    
    // Resolve the promise after the entire pattern has played
    setTimeout(resolve, totalDuration);
  });
}

// Export functions for other scripts to use
window.ocusSoundManager = {
  playSound,
  initAudioContext
};

// Also export playSound globally for easy access
window.playSound = playSound;

// Also export playSound globally for easy access
window.playSound = playSound;
