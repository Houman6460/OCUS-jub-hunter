/**
 * OCUS Unified Extension - New Mission Acceptor
 * 
 * A clean implementation focused exclusively on reliably accepting missions
 * when opened in a mission page.
 */

// Configuration
const CONFIG = {
  enabled: true,
  autoRedirect: true,
  redirectDelay: 5000, // 5 seconds - as requested by user
  maxAttempts: 20,
  attemptInterval: 800, // Faster interval to ensure we catch the button quickly
  debug: true, // Set to true for detailed logging
  homepage: 'https://app.ocus.com/' // Homepage URL to redirect to after acceptance
};

// State tracking
let missionAccepted = false;
let attemptCount = 0;
let attemptTimer = null;

/**
 * Initialize the mission acceptor
 */
async function init() {
  log('Mission acceptor initializing...');
  
  // Only run on mission pages
  if (!isMissionPage()) {
    log('Not a mission page, skipping initialization');
    return;
  }
  
  // Show status
  showStatus('Looking for Accept button...', 'info');
  
  // Start looking for the accept button
  startAcceptProcess();
  
  // Set up a mutation observer to detect DOM changes
  setupMutationObserver();
  
  log('Mission acceptor initialized successfully');
}

/**
 * Check if the current page is a mission page
 * @returns {boolean} True if the current page appears to be a mission page
 */
function isMissionPage() {
  // Check URL pattern - with updated pattern to match both mission and missions URLs
  const url = window.location.href;
  
  // Explicit check for the URL pattern the user specified
  if (url.includes('app.ocus.com/missions/')) {
    log('Detected mission page from exact URL pattern: app.ocus.com/missions/');
    return true;
  }
  
  // Also check other common patterns as fallback
  if (url.includes('/mission/') || 
      url.includes('/assignments/') || 
      url.includes('ocus.com/assignment')) {
    log('Detected mission page from URL pattern');
    return true;
  }
  
  // Check for the exact button the user specified
  try {
    const exactButton = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (exactButton) {
      const buttonText = (exactButton.innerText || exactButton.textContent || '').trim();
      if (buttonText === 'Accept assignment') {
        log('Detected mission page from exact button match');
        return true;
      }
    }
  } catch (error) {
    log('Error checking for button', error);
  }
  
  // Check for other mission-specific elements
  const missionIndicators = [
    'div[data-test="mission-details"]',
    '.mission-details',
    '.mission-header'
  ];
  
  for (const selector of missionIndicators) {
    try {
      const elements = document.querySelectorAll(selector);
      if (elements && elements.length > 0) {
        log(`Detected mission page from element: ${selector}`);
        return true;
      }
    } catch (error) {
      // Some selectors might not work in all browsers
    }
  }
  
  return false;
}

/**
 * Start the process of finding and clicking the accept button
 */
function startAcceptProcess() {
  attemptCount = 0;
  attemptAcceptMission();
}

/**
 * Attempt to find and click the accept button
 */
async function attemptAcceptMission() {
  // Don't proceed if mission is already accepted or disabled
  if (missionAccepted || !CONFIG.enabled) {
    return;
  }
  
  attemptCount++;
  log(`Attempting to accept mission (${attemptCount}/${CONFIG.maxAttempts})`);
  
  // Find the accept button
  const acceptButton = findAcceptButton();
  
  if (acceptButton) {
    log('Found accept button! Attempting to click it...');
    logButtonDetails(acceptButton);
    
    // Make sure button is visible
    scrollButtonIntoView(acceptButton);
    
    // Click with delay to ensure UI is stable
    setTimeout(() => {
      if (clickAcceptButton(acceptButton)) {
        handleAcceptSuccess();
      } else {
        scheduleNextAttempt();
      }
    }, 500);
  } else {
    log('Accept button not found in this attempt');
    scheduleNextAttempt();
  }
}

/**
 * Schedule the next attempt to find and click the accept button
 */
function scheduleNextAttempt() {
  // Stop after max attempts
  if (attemptCount >= CONFIG.maxAttempts) {
    showStatus('Failed to accept mission after multiple attempts', 'error');
    log('Maximum attempts reached, giving up');
    return;
  }
  
  // Schedule next attempt
  log(`Scheduling next attempt in ${CONFIG.attemptInterval}ms`);
  clearTimeout(attemptTimer);
  attemptTimer = setTimeout(attemptAcceptMission, CONFIG.attemptInterval);
}

/**
 * Find the accept assignment button using multiple strategies with exact focus on the user-specified button
 * @returns {Element|null} The accept button element or null if not found
 */
function findAcceptButton() {
  // Debug logging - print the total number of buttons on the page
  const allPageButtons = document.querySelectorAll('button');
  log(`Scanning ${allPageButtons.length} buttons on the page for Accept assignment button`);
  
  // Strategy 1: Find by specific data-test attribute (most reliable)
  const dataTestButton = document.querySelector('button[data-test="accept-assignment-btn"]');
  if (dataTestButton && isVisible(dataTestButton)) {
    log('Found accept button by data-test attribute');
    logButtonDetails(dataTestButton);
    return dataTestButton;
  }
  
  // Strategy 2: Find by the exact class combination from user example
  const exactClassButton = document.querySelector('button.button.my-4[data-test="accept-assignment-btn"]');
  if (exactClassButton && isVisible(exactClassButton)) {
    log('Found accept button by exact class combination');
    logButtonDetails(exactClassButton);
    return exactClassButton;
  }
  
  // Strategy 3: Try even more specific attributes from user example
  try {
    const vueButtons = document.querySelectorAll('button[data-v-1d1d488e][data-v-c6eed17c]');
    log(`Found ${vueButtons.length} buttons with Vue-specific data attributes`);
    
    for (const btn of vueButtons) {
      if (isVisible(btn) && (btn.innerText || btn.textContent || '').trim() === 'Accept assignment') {
        log('Found accept button by Vue data attributes');
        logButtonDetails(btn);
        return btn;
      }
    }
  } catch (error) {
    // Vue attributes might not be consistent across versions
    log('Error searching for Vue buttons:', error.message);
  }
  
  // Strategy 4: Find by exact text content
  const allButtons = Array.from(document.querySelectorAll('button'));
  const textMatchButton = allButtons.find(btn => {
    const text = btn.innerText || btn.textContent || '';
    return text.trim() === 'Accept assignment' && isVisible(btn);
  });
  
  if (textMatchButton) {
    log('Found accept button by exact text match');
    logButtonDetails(textMatchButton);
    return textMatchButton;
  }
  
  // Strategy 5: Combination approach - prioritize buttons with certain classes
  const classMatchButtons = allButtons.filter(btn => {
    const classes = btn.className || '';
    return classes.includes('button') && classes.includes('my-4') && isVisible(btn);
  });
  
  log(`Found ${classMatchButtons.length} buttons with class 'button' and 'my-4'`);
  
  for (const btn of classMatchButtons) {
    const text = (btn.innerText || btn.textContent || '').trim();
    if (text === 'Accept assignment' || text.toLowerCase().includes('accept')) {
      log('Found accept button by class and text combination');
      logButtonDetails(btn);
      return btn;
    }
  }
  
  // Strategy 6: Try partial text matching on all buttons as a last resort
  log('Trying partial text matching as last resort...');
  for (const btn of allButtons) {
    if (!isVisible(btn)) continue;
    
    const text = (btn.innerText || btn.textContent || '').trim().toLowerCase();
    if (text.includes('accept') && (text.includes('assignment') || text.includes('mission'))) {
      log('Found button with accept + assignment/mission text');
      logButtonDetails(btn);
      return btn;
    }
  }
  
  log('No accept button found after trying all detection strategies');
  return null;
}

/**
 * Check if an element is visible
 * @param {Element} element - The element to check
 * @returns {boolean} True if the element is visible
 */
function isVisible(element) {
  if (!element) return false;
  
  const style = window.getComputedStyle(element);
  return style.display !== 'none' && 
         style.visibility !== 'hidden' && 
         style.opacity !== '0' &&
         element.offsetWidth > 0 && 
         element.offsetHeight > 0;
}

/**
 * Scroll the button into view
 * @param {Element} button - The button to scroll into view
 */
function scrollButtonIntoView(button) {
  if (!button || !button.scrollIntoView) return;
  
  try {
    button.scrollIntoView({ behavior: 'auto', block: 'center' });
    log('Scrolled button into view');
  } catch (error) {
    log('Failed to scroll button into view', error);
  }
}

/**
 * Click the accept button using multiple reliable methods
 * @param {Element} button - The button to click
 * @returns {boolean} True if at least one click method succeeded
 */
function clickAcceptButton(button) {
  if (!button) return false;
  
  let clickSucceeded = false;
  
  // Before attempting to click, ensure the button is in view
  scrollButtonIntoView(button);
  
  // Method 1: Native click (most reliable)
  try {
    log('Attempting native click method');
    button.click();
    clickSucceeded = true;
    log('Native click succeeded');
  } catch (error) {
    log('Native click failed', error);
  }
  
  return clickSucceeded;
}

/**
 * Handle successful mission acceptance
 */
function handleAcceptSuccess() {
  log('Mission accepted successfully!');
  missionAccepted = true;
  showStatus('Mission accepted! Redirecting...', 'success');
  
  // Clear any pending attempts
  clearTimeout(attemptTimer);
  
  // Optional redirect after delay
  if (CONFIG.autoRedirect) {
    setTimeout(() => {
      log(`Redirecting to ${CONFIG.homepage} after ${CONFIG.redirectDelay}ms`);
      window.location.href = CONFIG.homepage;
    }, CONFIG.redirectDelay);
  }
}

/**
 * Set up mutation observer to detect DOM changes
 */
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    if (missionAccepted) return;
    
    // Only observe if we haven't found the button yet
    const hasButton = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (hasButton && !missionAccepted) {
      log('Mutation observer detected new button, attempting click');
      attemptAcceptMission();
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'data-test']
  });
  
  log('Mutation observer set up successfully');
}

/**
 * Log button details for debugging
 * @param {Element} button - The button to log details for
 */
function logButtonDetails(button) {
  if (!button) return;
  
  const details = {
    tagName: button.tagName,
    className: button.className,
    id: button.id,
    text: (button.innerText || button.textContent || '').trim(),
    dataTest: button.getAttribute('data-test'),
    visible: isVisible(button),
    disabled: button.disabled,
    offsetWidth: button.offsetWidth,
    offsetHeight: button.offsetHeight
  };
  
  log('Button details:', details);
}

/**
 * Show status message to user
 * @param {string} message - The message to show
 * @param {string} type - The type of message (info, success, error)
 */
function showStatus(message, type = 'info') {
  console.log(`[OCUS Mission Acceptor] ${message}`);
  
  // You can enhance this to show UI notifications
  // For now, just log to console
}

/**
 * Enhanced logging function
 * @param {...any} args - Arguments to log
 */
function log(...args) {
  if (CONFIG.debug) {
    console.log('[Mission Acceptor]', ...args);
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { init, findAcceptButton, clickAcceptButton };
}