/**
 * OCUS TRIAL Extension Popup Script
 * Manages trial usage display and purchase redirection
 */

let extensionId = null;
let userFingerprint = null;

// Initialize popup
document.addEventListener('DOMContentLoaded', function() {
  initializePopup();
});

/**
 * Initialize popup functionality
 */
async function initializePopup() {
  console.log('TRIAL popup initializing...');
  
  // Initialize identifiers
  await initializeIdentifiers();
  
  // Load and display trial status
  await updateTrialStatus();
  
  // Set up refresh interval
  setInterval(updateTrialStatus, 10000); // Update every 10 seconds
}

/**
 * Initialize extension ID and fingerprint
 */
async function initializeIdentifiers() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['extensionId', 'userFingerprint'], (result) => {
      if (!result.extensionId) {
        extensionId = generateExtensionId();
        chrome.storage.local.set({ extensionId });
      } else {
        extensionId = result.extensionId;
      }
      
      if (!result.userFingerprint) {
        userFingerprint = generateUserFingerprint();
        chrome.storage.local.set({ userFingerprint });
      } else {
        userFingerprint = result.userFingerprint;
      }
      
      console.log(`Extension ID: ${extensionId}, Fingerprint: ${userFingerprint}`);
      resolve();
    });
  });
}

/**
 * Generate unique extension installation ID
 */
function generateExtensionId() {
  return 'ext_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

/**
 * Generate user fingerprint
 */
function generateUserFingerprint() {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  ctx.textBaseline = 'top';
  ctx.font = '14px Arial';
  ctx.fillText('Fingerprint', 2, 2);
  
  const fingerprint = [
    navigator.userAgent,
    navigator.language,
    screen.width + 'x' + screen.height,
    new Date().getTimezoneOffset(),
    canvas.toDataURL()
  ].join('|');
  
  let hash = 0;
  for (let i = 0; i < fingerprint.length; i++) {
    const char = fingerprint.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return 'fp_' + Math.abs(hash).toString(36);
}

/**
 * Check trial status from server
 */
async function checkServerTrialStatus() {
  try {
    const response = await fetch('https://jobhunter.one/api/extension/check-trial-status', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        extensionId,
        userFingerprint
      })
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log('Server trial status:', data);
      return data;
    }
  } catch (error) {
    console.log('Error checking server trial status:', error);
  }
  
  return null;
}

/**
 * Update trial status display
 */
async function updateTrialStatus() {
  try {
    // Try server first
    let trialData = await checkServerTrialStatus();
    
    // Fallback to local storage
    if (!trialData) {
      trialData = await new Promise((resolve) => {
        chrome.storage.local.get(['trial_usage_data'], (result) => {
          const usage = result.trial_usage_data || { used: 0 };
          resolve({
            usageCount: usage.used || 0,
            remaining: Math.max(0, 3 - (usage.used || 0)),
            expired: (usage.used || 0) >= 3
          });
        });
      });
    }
    
    // Update UI elements
    const remainingElement = document.getElementById('remainingCount');
    const usedElement = document.getElementById('usedCount');
    const expiredWarning = document.getElementById('expiredWarning');
    const expiredOverlay = document.getElementById('expiredOverlay');
    
    if (remainingElement) {
      remainingElement.textContent = trialData.remaining;
      remainingElement.style.color = trialData.remaining > 0 ? '#4CAF50' : '#F44336';
    }
    
    if (usedElement) {
      usedElement.textContent = trialData.usageCount;
    }
    
    // Show/hide expired warning
    if (trialData.expired) {
      if (expiredWarning) {
        expiredWarning.style.display = 'block';
      }
      
      // Show expired overlay if no missions remaining
      if (trialData.remaining <= 0 && expiredOverlay) {
        expiredOverlay.style.display = 'flex';
      }
    } else {
      if (expiredWarning) {
        expiredWarning.style.display = 'none';
      }
      if (expiredOverlay) {
        expiredOverlay.style.display = 'none';
      }
    }
    
    console.log('Trial status updated:', trialData);
    
  } catch (error) {
    console.error('Error updating trial status:', error);
    
    // Default display on error
    const remainingElement = document.getElementById('remainingCount');
    const usedElement = document.getElementById('usedCount');
    
    if (remainingElement) remainingElement.textContent = '3';
    if (usedElement) usedElement.textContent = '0';
  }
}