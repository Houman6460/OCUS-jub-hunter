/**
 * OCUS Unified Extension - Configuration (Fixed)
 * 
 * Central configuration file for API endpoints and settings with production URLs
 */

const EXTENSION_CONFIG = {
  // API Configuration
  API: {
    BASE_URL: 'https://jobhunter.one/api', // Production URL
    ENDPOINTS: {
      TRACK_TRIAL: '/extension/track-trial-usage',
      CHECK_TRIAL_STATUS: '/extension/check-trial-status'
    },
    TIMEOUT: 8000 // 8 second timeout for better reliability
  },

  // Trial Configuration
  TRIAL: {
    MAX_USES: 3,
    STORAGE_KEY: 'trial_usage_data',
    PURCHASE_URL: 'https://jobhunter.one'
  },

  // Extension Type
  TYPE: 'TRIAL',

  // User ID Configuration
  USER_ID: {
    STORAGE_KEY: 'extension_user_id'
  },

  // Extension Status
  STATUS: {
    STORAGE_KEY: 'extension_status'
  },

  // Version Configuration
  VERSION: {
    TOKEN: 'b7d3f8e2-4a1b-4c7d-9e2f-3d8a5c9e7f1b',
    NUMBER: '2.1.0'
  },

  // Demo Activation Keys
  DEMO_KEYS: [
    'OCUS-2024-DEMO-KEY',
    'OCUS-TRIAL-2024-EXT',
    'OCUS-UNLIMITED-2024'
  ]
};

// Make config available globally
if (typeof window !== 'undefined') {
  window.EXTENSION_CONFIG = EXTENSION_CONFIG;
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = EXTENSION_CONFIG;
}