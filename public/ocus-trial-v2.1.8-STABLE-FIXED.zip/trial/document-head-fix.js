/**
 * OCUS Unified Extension - Document Head Fix
 * 
 * This script ensures document.head is always available, even during early document loading.
 * It runs at document_start to fix issues with other extensions that try to access document.head
 * before it's available in the DOM.
 */

// Global container for OCUS-specific functionality
window.ocusGlobals = window.ocusGlobals || {};

// Flag to track if our fix is active
window.ocusGlobals.documentHeadFixed = true;

// Initialize activation manager when available
let activationManager;
if (window.EXTENSION_CONFIG && window.ActivationManager) {
  activationManager = new window.ActivationManager();
  activationManager.initialize().then(() => {
    window.ocusGlobals.activationManager = activationManager;
    console.log('[OCUS] Activation Manager initialized in content script');
  }).catch(error => {
    console.warn('[OCUS] Activation Manager initialization failed:', error);
  });
}

// Method 1: Override the document.head getter globally
(function() {
  // Store the original getter
  const originalHeadGetter = Object.getOwnPropertyDescriptor(Document.prototype, 'head')?.get;
  
  // Only override if we actually got the original getter
  if (originalHeadGetter) {
    // Override with our safe version
    Object.defineProperty(Document.prototype, 'head', {
      get: function() {
        // Try the original getter first
        const originalHead = originalHeadGetter.call(this);
        if (originalHead) return originalHead;
        
        // If original returns null, create a head element if the document has an HTML element
        if (this.documentElement) {
          let head = this.getElementsByTagName('head')[0];
          
          // If no head found, create one
          if (!head) {
            head = this.createElement('head');
            this.documentElement.insertBefore(head, this.documentElement.firstChild);
            console.log('[OCUS] Created missing document.head element');
          }
          
          return head;
        }
        
        // If no document element yet, return null
        return null;
      }
    });
    
    console.log('[OCUS] Document.head getter safely overridden');
  } else {
    console.warn('[OCUS] Could not get original document.head getter');
  }
})();

// Method 2: Set up global error handler for head-related errors
window.addEventListener('error', function(e) {
  // Check if error is related to document.head access
  if (e && e.message && (
      e.message.includes('document.head is null') || 
      e.message.includes('Cannot read properties of null') && e.error?.stack?.includes('head')
  )) {
    console.warn('[OCUS] Caught document.head error:', e.message);
    
    // Try to create head element if missing
    if (!document.head && document.documentElement) {
      const head = document.createElement('head');
      document.documentElement.insertBefore(head, document.documentElement.firstChild);
      console.log('[OCUS] Created missing document.head after error');
      
      // Re-dispatch this error's related event to give code another chance to run
      if (e.target && typeof e.target.dispatchEvent === 'function') {
        try {
          e.target.dispatchEvent(new Event('ocus-retry'));
        } catch (retryError) {
          // Ignore retry errors
        }
      }
    }
    
    // Prevent the error from propagating
    e.preventDefault();
  }
}, true);

// Create a small API for other scripts to use
window.ocusGlobals.ensureHead = function() {
  if (!document.head && document.documentElement) {
    const head = document.createElement('head');
    document.documentElement.insertBefore(head, document.documentElement.firstChild);
    console.log('[OCUS] Created missing document.head via API call');
    return head;
  }
  return document.head;
};

// Method 3: Periodic checking for document readiness
(function checkDocumentReady() {
  if (document.documentElement && !document.head) {
    const head = document.createElement('head');
    document.documentElement.insertBefore(head, document.documentElement.firstChild);
    console.log('[OCUS] Created missing document.head via periodic check');
  }
  
  // Continue checking until document is fully ready
  if (!document.body) {
    setTimeout(checkDocumentReady, 10);
  }
})();

// Safe DOM ready handler
function safeDocumentReady(callback) {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', callback);
  } else {
    // Document is already loaded
    callback();
  }
}

// Check if extension can be used (with activation/demo limits)
async function checkExtensionUsage() {
  if (!window.ocusGlobals.activationManager) {
    // Initialize if not done yet
    if (window.EXTENSION_CONFIG && window.ActivationManager) {
      activationManager = new window.ActivationManager();
      await activationManager.initialize();
      window.ocusGlobals.activationManager = activationManager;
    } else {
      console.warn('[OCUS] Activation Manager not available - allowing fallback usage');
      return true; // Fallback to allow usage if system unavailable
    }
  }
  
  const manager = window.ocusGlobals.activationManager;
  
  if (manager.isActivated) {
    return true; // Full access with activation
  }
  
  // Check demo usage
  if (manager.canUseExtension()) {
    const success = await manager.useDemoAttempt();
    if (success) {
      console.log(`[OCUS] Demo attempt used. Remaining: ${manager.demoUsesRemaining}`);
      return true;
    } else {
      console.warn('[OCUS] Demo limit reached - extension usage blocked');
      manager.showActivationUI();
      return false;
    }
  }
  
  console.warn('[OCUS] Extension usage not allowed');
  manager.showActivationUI();
  return false;
}

// Export for use by other scripts
window.ocusGlobals.safeDocumentReady = safeDocumentReady;
window.ocusGlobals.checkExtensionUsage = checkExtensionUsage;

console.log('[OCUS] Document head fix initialized');
