/**
 * TRIAL SYSTEM TEST - Completely isolated trial counting
 * Use this to test if the trial counting logic works correctly
 */

// Clear ALL storage and start fresh
function resetTrialSystem() {
  chrome.storage.local.clear(() => {
    console.log('🧹 All storage cleared - starting fresh trial system');
    
    // Set initial trial count
    chrome.storage.local.set({ ocus_trial_count: 0 }, () => {
      console.log('✅ Trial system reset to 0');
    });
  });
}

// Test the trial counting logic
function testTrialCount() {
  chrome.storage.local.get(['ocus_trial_count'], (result) => {
    const currentCount = result.ocus_trial_count || 0;
    const newCount = currentCount + 1;
    const remaining = Math.max(0, 3 - newCount);
    
    console.log(`🔍 TEST: Current=${currentCount}, New=${newCount}, Remaining=${remaining}`);
    
    chrome.storage.local.set({ ocus_trial_count: newCount }, () => {
      console.log(`✅ Trial count updated to ${newCount}`);
      
      if (remaining === 0 && newCount === 3) {
        console.log('🎯 TRIAL COMPLETE: Should show activation prompt');
      } else {
        console.log(`🔄 Trial continues: ${newCount}/3 used, ${remaining} remaining`);
      }
    });
  });
}

// Run the test
console.log('🧪 Starting trial system test...');

// First reset, then test 3 times
resetTrialSystem();

setTimeout(() => testTrialCount(), 1000);  // Test 1
setTimeout(() => testTrialCount(), 2000);  // Test 2
setTimeout(() => testTrialCount(), 3000);  // Test 3