/**
 * OCUS Unified Extension - Auto Start Trigger
 * 
 * Automatically triggers start buttons and actions on photographer pages.
 * This script runs on photographer-specific pages to automate workflows.
 */

(function() {
  // Configuration state
  let config = {
    autoStartEnabled: true,
    autoStartDelay: 3000,
    autoConfirmEnabled: true
  };
  
  // Tracking state
  let hasTriggeredStart = false;
  let hasTriggeredConfirm = false;
  
  // Initialize when DOM is ready
  function initialize() {
    console.log('OCUS Auto Start Trigger initializing...');
    
    // Load configuration
    chrome.storage.local.get(['config'], (result) => {
      if (result && result.config) {
        // Update auto-start configuration if it exists
        if (result.config.autoStart) {
          config.autoStartEnabled = result.config.autoStart.enabled !== undefined ? 
            result.config.autoStart.enabled : config.autoStartEnabled;
          
          config.autoStartDelay = result.config.autoStart.delay !== undefined ? 
            result.config.autoStart.delay : config.autoStartDelay;
          
          config.autoConfirmEnabled = result.config.autoStart.autoConfirm !== undefined ? 
            result.config.autoStart.autoConfirm : config.autoConfirmEnabled;
        }
        
        // Start automation if enabled
        if (config.autoStartEnabled) {
          setTimeout(autoStartAction, config.autoStartDelay);
        }
      }
    });
    
    // Listen for configuration updates
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'CONFIG_UPDATED' && message.config) {
        // Update auto-start configuration
        if (message.config.autoStart) {
          config.autoStartEnabled = message.config.autoStart.enabled !== undefined ? 
            message.config.autoStart.enabled : config.autoStartEnabled;
          
          config.autoStartDelay = message.config.autoStart.delay !== undefined ? 
            message.config.autoStart.delay : config.autoStartDelay;
          
          config.autoConfirmEnabled = message.config.autoStart.autoConfirm !== undefined ? 
            message.config.autoStart.autoConfirm : config.autoConfirmEnabled;
        }
      }
    });
    
    // Listen for DOM changes to detect new buttons
    observeDOM();
  }
  
  // Auto-start action execution
  function autoStartAction() {
    if (hasTriggeredStart || !config.autoStartEnabled) {
      return;
    }
    
    // Find start buttons
    let startButton = findStartButton();
    
    if (startButton) {
      console.log('Start button found, clicking...');
      
      // Show status message
      showStatusMessage('Starting mission automatically...', null);
      
      // Click the start button
      startButton.click();
      hasTriggeredStart = true;
      
      // Update stats
      chrome.runtime.sendMessage({ type: 'MISSION_STARTED' });
      
      // Look for confirm buttons if enabled
      if (config.autoConfirmEnabled) {
        setTimeout(autoConfirmAction, 1500);
      }
      
      // Show success notification
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Mission Started',
        message: 'Automatically started the mission',
        priority: 1
      });
    } else {
      console.log('Start button not found, will retry in 2 seconds');
      
      // Try again after a delay
      setTimeout(autoStartAction, 2000);
    }
  }
  
  // Auto-confirm action execution
  function autoConfirmAction() {
    if (hasTriggeredConfirm || !config.autoConfirmEnabled) {
      return;
    }
    
    // Find confirm buttons
    let confirmButton = findConfirmButton();
    
    if (confirmButton) {
      console.log('Confirm button found, clicking...');
      
      // Show status message
      showStatusMessage('Confirming action automatically...', null);
      
      // Click the confirm button
      confirmButton.click();
      hasTriggeredConfirm = true;
      
      // Show success notification
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Action Confirmed',
        message: 'Automatically confirmed the action',
        priority: 1
      });
      
      // Show success message
      showStatusMessage('Action confirmed successfully!', true);
    } else {
      console.log('Confirm button not found, will retry in 1 second');
      
      // Try again after a delay (only retry a few times)
      if (document.querySelectorAll('.modal-content, .v-dialog, .confirmation-dialog').length > 0) {
        setTimeout(autoConfirmAction, 1000);
      }
    }
  }
  
  // Find start buttons
  function findStartButton() {
    // List of possible start button selectors
    const startButtonSelectors = [
      // Common button selectors
      "button:contains('Start')",
      "button:contains('Begin')",
      "button:contains('Start Mission')",
      "button:contains('Start Project')",
      // Specific OCUS selectors
      "button.v-btn--contained:contains('Start')",
      "button.primary:contains('Start')",
      "button.v-btn.primary:contains('Start')",
      // Element attributes
      "button[data-cy-id='startProjectButton']",
      "button[data-cy-id='startMissionButton']",
      "button[data-cy='startMissionButton']",
      // Generic selectors (last resort)
      ".btn-start",
      ".start-mission-btn",
      ".start-button"
    ];
    
    // Function to find button by text content
    function findButtonByText(text) {
      const buttons = Array.from(document.querySelectorAll('button'));
      return buttons.find(button => 
        button.textContent.trim().toLowerCase().includes(text.toLowerCase())
      );
    }
    
    // Try to find the start button
    let startButton = null;
    
    // Try each selector
    for (const selector of startButtonSelectors) {
      if (selector.includes(':contains(')) {
        // Handle custom :contains() selector
        const textMatch = selector.match(/:contains\('([^']+)'\)/);
        if (textMatch && textMatch[1]) {
          const buttonText = textMatch[1];
          startButton = findButtonByText(buttonText);
          if (startButton) break;
        }
      } else {
        // Standard selector
        startButton = document.querySelector(selector);
        if (startButton) break;
      }
    }
    
    // If button found, check if it's visible and enabled
    if (startButton && isVisibleElement(startButton) && !startButton.disabled) {
      return startButton;
    }
    
    return null;
  }
  
  // Find confirm buttons in modals and dialogs
  function findConfirmButton() {
    // List of possible confirm button selectors
    const confirmButtonSelectors = [
      // Common button selectors
      "button:contains('Confirm')",
      "button:contains('Yes')",
      "button:contains('OK')",
      "button:contains('Continue')",
      "button:contains('Proceed')",
      // Specific OCUS selectors
      "button.v-btn--contained:contains('Confirm')",
      "button.primary:contains('Confirm')",
      "button.v-btn.primary:contains('Confirm')",
      // Element attributes
      "button[data-cy-id='confirmButton']",
      "button[data-cy='confirmButton']",
      // Generic selectors (last resort)
      ".btn-confirm",
      ".confirm-button",
      ".btn-primary"
    ];
    
    // Function to find button by text content
    function findButtonByText(text) {
      // Look in modal/dialog containers first
      const modalContainers = document.querySelectorAll('.modal-content, .v-dialog, .confirmation-dialog, .modal');
      
      for (const container of modalContainers) {
        const buttons = Array.from(container.querySelectorAll('button'));
        const matchingButton = buttons.find(button => 
          button.textContent.trim().toLowerCase().includes(text.toLowerCase())
        );
        
        if (matchingButton) {
          return matchingButton;
        }
      }
      
      // If not found in modals, look in the entire document
      const buttons = Array.from(document.querySelectorAll('button'));
      return buttons.find(button => 
        button.textContent.trim().toLowerCase().includes(text.toLowerCase())
      );
    }
    
    // Try to find the confirm button
    let confirmButton = null;
    
    // Try each selector
    for (const selector of confirmButtonSelectors) {
      if (selector.includes(':contains(')) {
        // Handle custom :contains() selector
        const textMatch = selector.match(/:contains\('([^']+)'\)/);
        if (textMatch && textMatch[1]) {
          const buttonText = textMatch[1];
          confirmButton = findButtonByText(buttonText);
          if (confirmButton) break;
        }
      } else {
        // Try to find in modal containers first
        const modalContainers = document.querySelectorAll('.modal-content, .v-dialog, .confirmation-dialog, .modal');
        
        for (const container of modalContainers) {
          confirmButton = container.querySelector(selector);
          if (confirmButton) break;
        }
        
        // If not found in modals, look in the entire document
        if (!confirmButton) {
          confirmButton = document.querySelector(selector);
          if (confirmButton) break;
        }
      }
    }
    
    // If button found, check if it's visible and enabled
    if (confirmButton && isVisibleElement(confirmButton) && !confirmButton.disabled) {
      return confirmButton;
    }
    
    return null;
  }
  
  // Check if an element is visible
  function isVisibleElement(element) {
    if (!element) return false;
    
    const style = window.getComputedStyle(element);
    
    return style.display !== 'none' && 
           style.visibility !== 'hidden' && 
           style.opacity !== '0' &&
           element.offsetWidth > 0 && 
           element.offsetHeight > 0;
  }
  
  // Display a status message overlay
  function showStatusMessage(message, success) {
    // Remove any existing message
    const existingMessage = document.getElementById('ocus-auto-start-message');
    if (existingMessage) {
      existingMessage.remove();
    }
    
    // Create message element
    const messageElement = document.createElement('div');
    messageElement.id = 'ocus-auto-start-message';
    messageElement.textContent = message;
    
    // Choose color based on success state
    let backgroundColor = '#3498db'; // Blue for neutral/processing
    if (success === true) backgroundColor = '#2ecc71'; // Green for success
    if (success === false) backgroundColor = '#e74c3c'; // Red for failure
    
    // Style the message
    Object.assign(messageElement.style, {
      position: 'fixed',
      top: '20px',
      right: '20px',
      padding: '10px 15px',
      borderRadius: '5px',
      zIndex: '9999',
      fontSize: '14px',
      fontFamily: 'Arial, sans-serif',
      boxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
      background: backgroundColor,
      color: 'white',
      transition: 'opacity 0.3s',
      opacity: '1',
      pointerEvents: 'none'
    });
    
    // Add to document
    document.body.appendChild(messageElement);
    
    // Remove after a few seconds if not a permanent message
    if (success !== null) {
      setTimeout(() => {
        if (messageElement.parentNode) {
          messageElement.style.opacity = '0';
          
          // Remove after fade out
          setTimeout(() => {
            if (messageElement.parentNode) {
              messageElement.remove();
            }
          }, 300);
        }
      }, 3000);
    }
  }
  
  // Observe DOM for changes to detect new buttons
  function observeDOM() {
    const observer = new MutationObserver((mutations) => {
      if (!hasTriggeredStart && config.autoStartEnabled) {
        autoStartAction();
      }
      
      if (hasTriggeredStart && !hasTriggeredConfirm && config.autoConfirmEnabled) {
        autoConfirmAction();
      }
    });
    
    // Start observing the document with the configured parameters
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true
    });
  }
  
  // Initialize when the DOM is fully loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
})();
