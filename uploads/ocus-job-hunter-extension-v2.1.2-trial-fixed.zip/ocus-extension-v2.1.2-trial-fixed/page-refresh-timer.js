/**
 * OCUS Unified Extension - Page Refresh Timer
 * 
 * Adds an automatic page refresh timer with a countdown panel to the OCUS website.
 * The timer refreshes the page at intervals set by the user in the extension popup.
 */

(function() {
  'use strict';
  
  // Configuration defaults
  let config = {
    enabled: false,
    intervalSeconds: 30,
    showCountdown: true
  };
  
  // Timer variables
  let refreshTimer = null;
  let countdownTimer = null;
  let secondsLeft = 0;
  let countdownPanel = null;
  let statsPanel = null;
  let isPaused = false;
  
  // Stats variables
  let stats = {
    missionsFound: 0,
    missionsOpened: 0,
    missionsAccepted: 0,
    loginAttempts: 0,
    lastRefreshTime: null,
    totalRefreshes: 0
  };
  
  // Drag state variables
  let isDragging = false;
  let currentDragElement = null;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  
  // Panel position defaults (will be overridden by stored values if available)
  let panelPositions = {
    countdownPanel: { right: '20px', bottom: '20px' },
    statsPanel: { right: '210px', bottom: '20px' }
  };
  
  // Debug mode for easier troubleshooting
  const DEBUG = true;
  
  // Log function that only outputs when debug is enabled
  function log(...args) {
    if (DEBUG) {
      console.log('[OCUS Refresh Timer]', ...args);
    }
  }
  
  /**
   * Check trial status - returns whether user can use timer
   */
  async function checkTrialStatus() {
    return new Promise((resolve) => {
      try {
        // Check if user is activated
        chrome.storage.local.get(['isActivated', 'activation_key_data', 'ocus_trial_count'], (result) => {
          if (chrome.runtime.lastError) {
            log('Chrome storage error, assuming trial active');
            resolve({ canAccept: true, remaining: 3 });
            return;
          }
          
          // Check activation status
          const isActivated = result.isActivated || 
                             (result.activation_key_data && result.activation_key_data.isActivated);
          
          // If activated, unlimited usage
          if (isActivated) {
            resolve({ canAccept: true, remaining: 'unlimited' });
            return;
          }
          
          // Check trial usage using consistent storage key
          const trialUsed = result.ocus_trial_count || 0;
          const remaining = Math.max(0, 3 - trialUsed);
          
          log(`Trial status: ${trialUsed}/3 used, ${remaining} remaining`);
          resolve({ 
            canAccept: remaining > 0, 
            remaining: remaining 
          });
        });
      } catch (error) {
        log('Error checking trial status:', error);
        // Default to allowing usage if we can't check
        resolve({ canAccept: true, remaining: 3 });
      }
    });
  }
  
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
  // Load statistics from storage every minute
  setInterval(loadStats, 60000);
  
  // Listen for counter updates from other tabs
  if (typeof chrome !== 'undefined' && chrome.runtime) {
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'UPDATE_LOGIN_COUNTER') {
        // Update the LOGINS counter in floating panel
        const loginsElements = Array.from(document.querySelectorAll('div')).filter(div => {
          const text = div.textContent?.trim();
          return text === 'LOGINS' && 
                 div.nextElementSibling && 
                 div.nextElementSibling.textContent?.match(/^\d+$/);
        });
        
        loginsElements.forEach(loginsLabel => {
          const numberDiv = loginsLabel.nextElementSibling;
          if (numberDiv) {
            numberDiv.textContent = message.count.toString();
            log(`Updated LOGINS counter to: ${message.count}`);
          }
        });
        
        sendResponse({success: true});
      } else if (message.type === 'UPDATE_TRIAL_COUNTER') {
        // Update trial counter
        const trialRemainingEl = document.getElementById('ocus-trial-remaining');
        if (trialRemainingEl) {
          trialRemainingEl.textContent = message.remaining;
          log(`Updated TRIAL counter to: ${message.remaining}`);
        }
        
        // If trial exhausted, update status and stop automation
        if (message.remaining === 0) {
          const statusEl = document.getElementById('ocus-status-message');
          if (statusEl) {
            statusEl.textContent = 'Trial exhausted - Please activate extension';
            statusEl.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
          }
          
          // Stop refresh timer
          stopRefreshTimer();
        }
        
        sendResponse({success: true});
      }
    });
  }
  
  // Initialize the refresh timer functionality
  async function init() {
    log('Initializing...');
    
    // Always create the panel first regardless of trial status
    loadPanelPositions(() => {
      // Create the unified panel (combines countdown and stats)
      createUnifiedPanel();
      
      // Always show the panel by default
      showCountdownPanel();
      
      // Update active interval button display
      updateActiveIntervalButton();
      
      // Set up global drag event handlers
      setupDragHandlers();
      
      // Load initial stats
      loadStats();
    });
    
    // Check trial status for timer functionality
    const trialStatus = await checkTrialStatus();
    if (!trialStatus.canAccept) {
      log('Trial exhausted, timer functionality disabled but panel remains visible');
      // Update the panel to show trial exhausted status
      setTimeout(() => {
        updateCountdownDisplay('TRIAL EXPIRED');
        const statusEl = document.getElementById('ocus-status-message');
        if (statusEl) {
          statusEl.textContent = 'Trial exhausted - Please activate extension';
        }
      }, 1000);
      return;
    }
    
    // Load configuration from storage
    try {
      chrome.storage.local.get(['config'], function(result) {
        log('Configuration loaded from storage:', result);
        
        if (result.config && result.config.pageRefresh) {
          config = result.config.pageRefresh;
          log('Page Refresh Timer configuration:', config);
          
          // Initialize the timer if enabled
          if (config.enabled) {
            log('Auto-refresh is enabled, starting timer');
            startRefreshTimer();
          } else {
            log('Auto-refresh is disabled');
            hideCountdownPanel();
          }
        } else {
          log('No page refresh configuration found in storage');
        }
      });
    } catch (error) {
      console.error('[OCUS Refresh Timer] Error loading configuration:', error);
    }
    
    // Listen for configuration updates
    try {
      chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
        log('Message received:', message);
        
        if (message.type === 'UPDATE_CONFIG' && message.config && message.config.pageRefresh) {
          const newConfig = message.config.pageRefresh;
          log('New refresh configuration:', newConfig);
          
          // Check if enabled state changed
          if (newConfig.enabled !== config.enabled) {
            if (newConfig.enabled) {
              // Start timer if newly enabled
              log('Timer enabled, starting...');
              config = newConfig;
              startRefreshTimer();
            } else {
              // Stop timer if newly disabled
              log('Timer disabled, stopping...');
              stopRefreshTimer();
              hideCountdownPanel();
            }
          } 
          // Check if interval changed
          else if (newConfig.enabled && newConfig.intervalSeconds !== config.intervalSeconds) {
            // Restart timer with new interval
            log('Refresh interval changed, restarting timer...');
            config = newConfig;
            restartRefreshTimer();
          }
          // Check if countdown visibility changed
          else if (newConfig.showCountdown !== config.showCountdown) {
            config = newConfig;
            if (config.showCountdown) {
              log('Showing countdown panel');
              showCountdownPanel();
            } else {
              log('Hiding countdown panel');
              hideCountdownPanel();
            }
          }
          
          config = newConfig;
          
          // Update interval button state
          updateActiveIntervalButton();
          
          // Send response to confirm receipt
          if (sendResponse) {
            sendResponse({success: true});
          }
          
          return true; // Keep channel open for async response
        }
      });
      
      // Send a ready message to the background script
      chrome.runtime.sendMessage({type: 'PAGE_REFRESH_READY'}, function(response) {
        log('Sent ready message, response:', response);
      });
    } catch (error) {
      console.error('[OCUS Refresh Timer] Error setting up message listener:', error);
    }
  }
  
  // Create the countdown panel element
  function createUnifiedPanel() {
    // Check if panel already exists
    if (document.getElementById('ocus-unified-panel')) {
      return;
    }
    
    // Create panel elements
    countdownPanel = document.createElement('div');
    countdownPanel.id = 'ocus-unified-panel';
    countdownPanel.className = 'ocus-unified-panel';
    
    // Create panel content with modern design
    countdownPanel.innerHTML = `
      <div class="ocus-panel-header" draggable="true">
        <div class="ocus-panel-title">
          <span class="ocus-panel-icon">🎯</span>
          <span>OCUS Hunter</span>
        </div>
        <div class="ocus-panel-actions">
          <button class="ocus-panel-minimize" title="Minimize">−</button>
          <button class="ocus-panel-close" title="Close">&times;</button>
        </div>
      </div>
      <div class="ocus-panel-body">
        <div class="ocus-timer-section">
          <div class="ocus-timer-display">
            <div class="ocus-timer-value">
              <span id="ocus-seconds-left">0</span>
              <span class="ocus-timer-unit">sec</span>
            </div>
            <div class="ocus-timer-label">Next Refresh</div>
          </div>
          <div class="ocus-interval-quick-select">
            <div class="ocus-interval-label">Refresh Interval</div>
            <div class="ocus-interval-buttons">
              <button class="ocus-interval-btn" data-interval="5">5s</button>
              <button class="ocus-interval-btn" data-interval="10">10s</button>
              <button class="ocus-interval-btn" data-interval="20">20s</button>
              <button class="ocus-interval-btn" data-interval="30">30s</button>
            </div>
          </div>
          <div class="ocus-timer-controls">
            <button id="ocus-pause-refresh" class="ocus-btn ocus-btn-primary">
              <span class="ocus-btn-icon">⏸</span>
              <span class="ocus-btn-text">Pause</span>
            </button>
            <button id="ocus-refresh-now" class="ocus-btn ocus-btn-secondary">
              <span class="ocus-btn-icon">🔄</span>
              <span class="ocus-btn-text">Refresh</span>
            </button>
          </div>
        </div>
        <div class="ocus-stats-section">
          <div class="ocus-stats-grid">
            <div class="ocus-stat-item ocus-trial-counter" id="ocus-trial-counter-item">
              <span class="ocus-stat-value" id="ocus-trial-remaining">3</span>
              <span class="ocus-stat-label">Trial Remaining</span>
            </div>
            <div class="ocus-stat-item">
              <span class="ocus-stat-value" id="ocus-missions-refreshing">0</span>
              <span class="ocus-stat-label">Refreshing</span>
            </div>
            <div class="ocus-stat-item">
              <span class="ocus-stat-value" id="ocus-missions-opened">0</span>
              <span class="ocus-stat-label">Opened</span>
            </div>
            <div class="ocus-stat-item">
              <span class="ocus-stat-value" id="ocus-missions-accepted">0</span>
              <span class="ocus-stat-label">Accepted</span>
            </div>
            <div class="ocus-stat-item">
              <span class="ocus-stat-value" id="ocus-login-attempts">0</span>
              <span class="ocus-stat-label">Logins</span>
            </div>
          </div>
        </div>
        <div class="ocus-status-section">
          <div id="ocus-status-message" class="ocus-status-message">Ready</div>
        </div>
      </div>
    `;
    
    // Apply saved position if available
    if (panelPositions.countdownPanel) {
      Object.keys(panelPositions.countdownPanel).forEach(prop => {
        countdownPanel.style[prop] = panelPositions.countdownPanel[prop];
      });
    }
    
    // Restore minimize state
    try {
      const isMinimized = localStorage.getItem('ocus_panel_minimized') === 'true';
      if (isMinimized) {
        countdownPanel.classList.add('ocus-minimized');
      }
    } catch (error) {
      log('Error restoring minimize state:', error);
    }
    
    // Add styles for unified panel
    const style = document.createElement('style');
    style.textContent = `
      .ocus-unified-panel {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 280px;
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        border: 1px solid rgba(71, 85, 105, 0.4);
        border-radius: 12px;
        box-shadow: 
          0 20px 60px rgba(0, 0, 0, 0.3),
          0 8px 24px rgba(0, 0, 0, 0.2),
          inset 0 1px 0 rgba(255, 255, 255, 0.1);
        z-index: 9999;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        transition: all 0.3s ease;
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        overflow: hidden;
      }
      
      .ocus-panel-header {
        cursor: move;
        user-select: none;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 20px;
        background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
        color: white;
        border-radius: 12px 12px 0 0;
        border-bottom: 1px solid rgba(71, 85, 105, 0.3);
      }
      
      .ocus-panel-title {
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 600;
        font-size: 15px;
      }
      
      .ocus-panel-icon {
        font-size: 18px;
      }
      
      .ocus-panel-actions {
        display: flex;
        gap: 8px;
      }
      
      .ocus-panel-minimize,
      .ocus-panel-close {
        background: rgba(255, 255, 255, 0.2);
        border: none;
        color: white;
        font-size: 16px;
        cursor: pointer;
        padding: 4px 8px;
        border-radius: 6px;
        line-height: 1;
        transition: all 0.2s ease;
      }
      
      .ocus-panel-minimize:hover,
      .ocus-panel-close:hover {
        background: rgba(255, 255, 255, 0.3);
        transform: scale(1.1);
      }
      
      .ocus-panel-body {
        padding: 20px;
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
        color: #e2e8f0;
      }
      
      .ocus-timer-section {
        margin-bottom: 20px;
      }
      
      .ocus-timer-display {
        text-align: center;
        margin-bottom: 16px;
        background: linear-gradient(135deg, #334155 0%, #475569 100%);
        padding: 16px;
        border-radius: 8px;
        border: 1px solid rgba(71, 85, 105, 0.3);
      }
      
      .ocus-timer-value {
        display: flex;
        align-items: baseline;
        justify-content: center;
        gap: 4px;
        font-size: 32px;
        font-weight: 700;
        color: #60a5fa;
        line-height: 1;
      }
      
      .ocus-timer-unit {
        font-size: 16px;
        font-weight: 500;
        color: #94a3b8;
      }
      
      .ocus-timer-label {
        font-size: 12px;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-top: 4px;
      }
      
      .ocus-interval-quick-select {
        margin-bottom: 16px;
      }
      
      .ocus-interval-label {
        font-size: 12px;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 8px;
        text-align: center;
      }
      
      .ocus-interval-buttons {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 6px;
      }
      
      .ocus-interval-btn {
        padding: 8px 4px;
        border: 1px solid rgba(71, 85, 105, 0.3);
        border-radius: 6px;
        background: linear-gradient(135deg, #334155 0%, #475569 100%);
        color: #e2e8f0;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        text-align: center;
      }
      
      .ocus-interval-btn:hover {
        background: linear-gradient(135deg, #475569 0%, #64748b 100%);
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      }
      
      .ocus-interval-btn.active {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        color: white;
        border-color: #3b82f6;
        box-shadow: 0 2px 8px rgba(59, 130, 246, 0.3);
      }
      
      .ocus-timer-controls {
        display: flex;
        gap: 8px;
      }
      
      .ocus-btn {
        flex: 1;
        padding: 10px 12px;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 13px;
        font-weight: 500;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
      }
      
      .ocus-btn-primary {
        background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
        color: white;
        box-shadow: 0 2px 4px rgba(59, 130, 246, 0.3);
      }
      
      .ocus-btn-primary:hover {
        background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%);
        transform: translateY(-1px);
        box-shadow: 0 4px 8px rgba(59, 130, 246, 0.4);
      }
      
      .ocus-btn-secondary {
        background: linear-gradient(135deg, #475569 0%, #64748b 100%);
        color: #e2e8f0;
        border: 1px solid rgba(71, 85, 105, 0.3);
      }
      
      .ocus-btn-secondary:hover {
        background: linear-gradient(135deg, #64748b 0%, #475569 100%);
        transform: translateY(-1px);
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
      }
      
      .ocus-btn-icon {
        font-size: 14px;
      }
      
      .ocus-btn-text {
        font-size: 12px;
      }
      
      .ocus-stats-section {
        margin-bottom: 16px;
      }
      
      .ocus-stats-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 12px;
      }
      
      .ocus-stat-item {
        text-align: center;
        padding: 12px;
        background: linear-gradient(135deg, #334155 0%, #475569 100%);
        border-radius: 8px;
        border: 1px solid rgba(71, 85, 105, 0.3);
      }
      
      .ocus-stat-value {
        display: block;
        font-size: 20px;
        font-weight: 700;
        color: #60a5fa;
        line-height: 1;
      }
      
      .ocus-stat-label {
        font-size: 11px;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-top: 4px;
      }
      
      .ocus-status-section {
        border-top: 1px solid rgba(71, 85, 105, 0.3);
        padding-top: 16px;
      }
      
      .ocus-status-message {
        text-align: center;
        font-size: 13px;
        color: #94a3b8;
        font-weight: 500;
        padding: 8px 12px;
        background: linear-gradient(135deg, #334155 0%, #475569 100%);
        border-radius: 6px;
        border: 1px solid rgba(71, 85, 105, 0.3);
      }
      
      .ocus-hidden {
        opacity: 0;
        pointer-events: none;
        transform: translateY(10px);
      }
      
      .ocus-minimized .ocus-panel-body {
        display: none;
      }
      
      .ocus-minimized .ocus-panel-header::after {
        content: attr(data-timer);
        font-size: 14px;
        color: #60a5fa;
        margin-left: 12px;
        font-weight: 700;
        background: rgba(96, 165, 250, 0.1);
        padding: 4px 8px;
        border-radius: 4px;
        border: 1px solid rgba(96, 165, 250, 0.3);
      }
      
      /* Trial Counter Styles */
      .ocus-trial-counter {
        background: linear-gradient(135deg, #7c3aed 0%, #a855f7 100%) !important;
        border: 1px solid rgba(168, 85, 247, 0.5) !important;
        grid-column: span 2;
      }
      
      .ocus-trial-counter .ocus-stat-value {
        color: #fbbf24 !important;
        animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
      }
      
      .ocus-trial-counter .ocus-stat-label {
        color: #e9d5ff !important;
        font-weight: 600;
      }
      
      @keyframes pulse {
        0%, 100% {
          opacity: 1;
        }
        50% {
          opacity: .7;
        }
      }
      
      /* Stats Panel Styles */
      .ocus-stats-panel {
        position: fixed;
        bottom: 20px;
        right: 210px;
        width: 220px;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        z-index: 9999;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        transition: opacity 0.3s ease;
      }
      
      .ocus-stats-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 12px;
        background: #4CAF50;
        color: white;
        border-radius: 5px 5px 0 0;
        font-weight: 500;
        font-size: 14px;
      }
      
      .ocus-stats-close {
        background: none;
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
        padding: 0;
        line-height: 1;
      }
      
      .ocus-stats-body {
        padding: 12px;
      }
      
      .ocus-stats-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        font-size: 13px;
      }
      
      .ocus-stats-label {
        color: #555;
      }
      
      .ocus-stats-value {
        font-weight: bold;
        color: #333;
      }
      
      .ocus-stats-footer {
        display: flex;
        justify-content: center;
        padding: 8px 0 0;
        font-size: 11px;
        color: #777;
        border-top: 1px solid #eee;
        margin-top: 4px;
      }
    `;
    
    // Add to document
    document.head.appendChild(style);
    document.body.appendChild(countdownPanel);
    
    // Initialize stats display after a short delay
    setTimeout(() => {
      loadStats();
      updateUnifiedStatsDisplay();
    }, 200);
    
    // Add event listeners with error handling for unified panel
    try {
      const pauseButton = document.getElementById('ocus-pause-refresh');
      const refreshButton = document.getElementById('ocus-refresh-now');
      const closeButton = document.querySelector('.ocus-panel-close');
      const minimizeButton = document.querySelector('.ocus-panel-minimize');
      
      if (pauseButton) {
        pauseButton.addEventListener('click', togglePauseRefresh);
        log('Pause button event listener attached');
      } else {
        log('Warning: Pause button not found');
      }
      
      if (refreshButton) {
        refreshButton.addEventListener('click', refreshNow);
        log('Refresh now button event listener attached');
      } else {
        log('Warning: Refresh now button not found');
      }
      
      if (closeButton) {
        closeButton.addEventListener('click', function() {
          hideCountdownPanel();
        });
        log('Close button event listener attached');
      } else {
        log('Warning: Close button not found');
      }
      
      if (minimizeButton) {
        minimizeButton.addEventListener('click', function() {
          toggleMinimize();
        });
        log('Minimize button event listener attached');
      } else {
        log('Warning: Minimize button not found');
      }
      
      // Add event listeners for interval quick-select buttons
      const intervalButtons = document.querySelectorAll('.ocus-interval-btn');
      intervalButtons.forEach(button => {
        button.addEventListener('click', function() {
          const newInterval = parseInt(this.dataset.interval);
          changeRefreshInterval(newInterval);
        });
      });
      log('Interval quick-select buttons event listeners attached');
      
      // Add drag functionality for the unified panel
      const panelHeader = document.querySelector('.ocus-panel-header');
      if (panelHeader) {
        let isDragging = false;
        let dragOffsetX, dragOffsetY;
        
        panelHeader.addEventListener('mousedown', function(e) {
          // Only allow dragging from the header area, not buttons
          if (e.target.closest('button')) return;
          
          isDragging = true;
          const rect = countdownPanel.getBoundingClientRect();
          dragOffsetX = e.clientX - rect.left;
          dragOffsetY = e.clientY - rect.top;
          
          countdownPanel.style.cursor = 'grabbing';
          panelHeader.style.cursor = 'grabbing';
          
          e.preventDefault();
        });
        
        document.addEventListener('mousemove', function(e) {
          if (!isDragging) return;
          
          const newLeft = e.clientX - dragOffsetX;
          const newTop = e.clientY - dragOffsetY;
          
          // Remove positioning from right/bottom and use left/top
          countdownPanel.style.right = 'auto';
          countdownPanel.style.bottom = 'auto';
          countdownPanel.style.left = newLeft + 'px';
          countdownPanel.style.top = newTop + 'px';
          
          e.preventDefault();
        });
        
        document.addEventListener('mouseup', function() {
          if (!isDragging) return;
          
          isDragging = false;
          countdownPanel.style.cursor = '';
          panelHeader.style.cursor = 'move';
          
          // Save position
          const position = {
            left: countdownPanel.style.left,
            top: countdownPanel.style.top,
            right: 'auto',
            bottom: 'auto'
          };
          
          panelPositions.countdownPanel = position;
          savePanelPositions();
        });
        
        log('Drag functionality added to unified panel');
      }
    } catch (error) {
      log('Error attaching event listeners:', error);
    }
    
    // Show by default
    showCountdownPanel();
  }
  
  // Start the refresh timer
  async function startRefreshTimer() {
    // Check trial status before starting timer
    const trialStatus = await checkTrialStatus();
    if (!trialStatus.canAccept) {
      log('Trial exhausted, cannot start refresh timer');
      updateCountdownDisplay('TRIAL EXPIRED');
      return;
    }
    
    // Clear any existing timer
    stopRefreshTimer();
    
    // Reset pause state
    isPaused = false;
    const pauseButton = document.getElementById('ocus-pause-refresh');
    if (pauseButton) {
      const buttonText = pauseButton.querySelector('.ocus-btn-text');
      if (buttonText) {
        buttonText.textContent = 'Pause';
      }
    }
    
    log(`Starting page refresh timer with interval of ${config.intervalSeconds} seconds`);
    
    // Initialize countdown
    secondsLeft = config.intervalSeconds;
    updateCountdown();
    
    // Show the countdown panel if enabled
    if (config.showCountdown) {
      showCountdownPanel();
    }
    
    // Set up the refresh timer
    refreshTimer = setTimeout(function() {
      log('Refresh timer triggered');
      refreshPage();
    }, config.intervalSeconds * 1000);
    
    // Set up the countdown timer
    countdownTimer = setInterval(function() {
      secondsLeft--;
      updateCountdown();
      
      if (secondsLeft <= 0) {
        log('Countdown reached zero');
        clearInterval(countdownTimer);
      }
    }, 1000);
  }
  
  // Stop the refresh timer
  function stopRefreshTimer() {
    log('Stopping refresh timer');
    
    if (refreshTimer) {
      clearTimeout(refreshTimer);
      refreshTimer = null;
    }
    
    if (countdownTimer) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
  }
  
  // Restart the refresh timer
  function restartRefreshTimer() {
    stopRefreshTimer();
    startRefreshTimer();
  }
  
  // Update the countdown display
  function updateCountdown() {
    const secondsElement = document.getElementById('ocus-seconds-left');
    if (secondsElement) {
      secondsElement.textContent = secondsLeft;
    }
    
    // Update minimized header timer
    const header = document.querySelector('.ocus-panel-header');
    if (header) {
      header.setAttribute('data-timer', `${secondsLeft}s`);
    }
  }
  
  // Update countdown display with custom message
  function updateCountdownDisplay(message) {
    const secondsElement = document.getElementById('ocus-seconds-left');
    if (secondsElement) {
      secondsElement.textContent = message;
    }
  }
  
  // Update active interval button display
  function updateActiveIntervalButton() {
    const intervalButtons = document.querySelectorAll('.ocus-interval-btn');
    intervalButtons.forEach(button => {
      button.classList.remove('active');
      if (parseInt(button.dataset.interval) === config.intervalSeconds) {
        button.classList.add('active');
      }
    });
  }
  
  // Change refresh interval and sync with popup
  function changeRefreshInterval(newInterval) {
    log(`Changing refresh interval to ${newInterval} seconds`);
    
    // Update local config
    config.intervalSeconds = newInterval;
    
    // Update Chrome storage to sync with popup
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['config'], (result) => {
        let storedConfig = result.config || {};
        storedConfig.pageRefresh = storedConfig.pageRefresh || {};
        storedConfig.pageRefresh.intervalSeconds = newInterval;
        
        chrome.storage.local.set({ config: storedConfig }, () => {
          log(`Saved new interval ${newInterval}s to storage`);
          
          // Notify popup of change
          try {
            chrome.runtime.sendMessage({
              type: 'INTERVAL_CHANGED',
              interval: newInterval
            });
          } catch (e) {
            // Ignore if popup not open
          }
        });
      });
    }
    
    // Update button states
    updateActiveIntervalButton();
    
    // Restart timer with new interval if currently running
    if (refreshTimer) {
      restartRefreshTimer();
    }
    
    log(`Refresh interval changed to ${newInterval} seconds`);
  }
  
  // Show the countdown panel
  function showCountdownPanel() {
    if (countdownPanel) {
      countdownPanel.classList.remove('ocus-hidden');
    }
    
    // Initialize trial counter display
    setTimeout(() => {
      updateUnifiedStatsDisplay();
    }, 100);
  }
  
  // Hide the countdown panel
  function hideCountdownPanel() {
    if (countdownPanel) {
      countdownPanel.classList.add('ocus-hidden');
    }
  }
  
  // Toggle minimize state
  function toggleMinimize() {
    if (countdownPanel) {
      const isMinimized = countdownPanel.classList.toggle('ocus-minimized');
      log('Panel minimized state toggled:', isMinimized);
      
      // Save minimize state
      try {
        localStorage.setItem('ocus_panel_minimized', isMinimized.toString());
      } catch (error) {
        log('Error saving minimize state:', error);
      }
    }
  }
  
  // Toggle pause/resume of the refresh timer
  function togglePauseRefresh() {
    const pauseButton = document.getElementById('ocus-pause-refresh');
    
    if (!pauseButton) {
      log('Error: Pause button not found');
      return;
    }
    
    isPaused = !isPaused;
    log(`Toggling pause state: ${isPaused ? 'PAUSED' : 'ACTIVE'}`);
    
    if (isPaused) {
      // Pause the timer
      log('Pausing refresh timer');
      stopRefreshTimer();
      pauseButton.textContent = 'Resume';
      pauseButton.style.backgroundColor = '#ff9800';
      if (typeof showStatus === 'function') {
        showStatus('Page refresh paused', 'info');
      }
    } else {
      // Resume the timer
      log('Resuming refresh timer');
      startRefreshTimer();
      pauseButton.textContent = 'Pause';
      pauseButton.style.backgroundColor = '#f44336';
      if (typeof showStatus === 'function') {
        showStatus('Page refresh resumed', 'success');
      }
    }
    
    // Save pause state
    try {
      localStorage.setItem('ocus_refresh_paused', isPaused.toString());
    } catch (error) {
      log('Error saving pause state:', error);
    }
  }
  
  // Refresh the page immediately
  function refreshNow() {
    console.log('[OCUS] Manual page refresh triggered.');
    refreshPage();
  }
  
  // Perform the page refresh
  function refreshPage() {
    log('Refreshing page now');
    
    // Update refresh statistics
    chrome.storage.local.get(['stats'], (result) => {
      const currentStats = result.stats || {
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        totalRefreshes: 0,
        lastLoginTime: null,
        lastRefreshTime: null
      };
      
      currentStats.totalRefreshes = (currentStats.totalRefreshes || 0) + 1;
      currentStats.lastRefreshTime = Date.now();
      
      chrome.storage.local.set({ stats: currentStats }, () => {
        log('Updated refresh statistics');
      });
    });
    
    try {
      // Force reload from server, not from cache
      window.location.reload(true);
    } catch (error) {
      console.error('[OCUS Refresh Timer] Error refreshing page:', error);
      // Fallback method
      window.location = window.location.href;
    }
  }
  
  // Create the statistics panel element
  function createStatsPanel() {
    // Check if panel already exists
    if (document.getElementById('ocus-stats-panel')) {
      return;
    }
    
    // Create panel elements
    statsPanel = document.createElement('div');
    statsPanel.id = 'ocus-stats-panel';
    statsPanel.className = 'ocus-stats-panel';
    
    // Create panel content
    statsPanel.innerHTML = `
      <div class="ocus-stats-header" draggable="true">
        <span>OCUS Statistics</span>
        <button class="ocus-stats-close" title="Close">&times;</button>
      </div>
      <div class="ocus-stats-body">
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Missions Found:</span>
          <span class="ocus-stats-value" id="ocus-stats-found">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Missions Opened:</span>
          <span class="ocus-stats-value" id="ocus-stats-opened">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Missions Accepted:</span>
          <span class="ocus-stats-value" id="ocus-stats-accepted">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Total Refreshes:</span>
          <span class="ocus-stats-value" id="ocus-stats-refreshes">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Login Attempts:</span>
          <span class="ocus-stats-value" id="ocus-stats-logins">0</span>
        </div>
        <div class="ocus-stats-footer" id="ocus-stats-last-refresh">
          Last refresh: Never
        </div>
      </div>
    `;
    
    // Apply saved position if available
    if (panelPositions.statsPanel) {
      Object.keys(panelPositions.statsPanel).forEach(prop => {
        statsPanel.style[prop] = panelPositions.statsPanel[prop];
      });
    }
    
    // Add to document body
    document.body.appendChild(statsPanel);
    
    // Add event listener for close button
    document.querySelector('.ocus-stats-close').addEventListener('click', function() {
      hideStatsPanel();
    });
    
    // Add toggle button to countdown panel
    const countdownControls = document.querySelector('.ocus-countdown-controls');
    if (countdownControls) {
      const statsToggleBtn = document.createElement('button');
      statsToggleBtn.id = 'ocus-toggle-stats';
      statsToggleBtn.className = 'ocus-btn';
      statsToggleBtn.textContent = 'Stats';
      statsToggleBtn.addEventListener('click', toggleStatsPanel);
      countdownControls.appendChild(statsToggleBtn);
    }
    
    // Show by default alongside countdown
    showStatsPanel();
  }
  
  // Load statistics from storage
  function loadStats() {
    chrome.storage.local.get(['stats'], function(result) {
      if (result.stats) {
        stats = result.stats;
        updateUnifiedStatsDisplay();
      }
    });
  }
  
  // Update the unified stats display elements
  function updateUnifiedStatsDisplay() {
    log('Updating unified stats display with:', stats);
    
    // Update unified panel stats - show refreshes instead of found
    const elements = {
      'ocus-missions-refreshing': stats.totalRefreshes || 0,
      'ocus-missions-opened': stats.missionsOpened || 0,
      'ocus-missions-accepted': stats.missionsAccepted || 0,
      'ocus-login-attempts': stats.loginAttempts || 0
    };
    
    // Update each stat element in unified panel
    Object.keys(elements).forEach(id => {
      const element = document.getElementById(id);
      if (element) {
        element.textContent = elements[id];
        log(`Updated ${id} to ${elements[id]}`);
      }
    });
    
    // Check trial status and update trial counter
    chrome.storage.local.get(['isActivated', 'activation_key_data', 'ocus_trial_count'], (result) => {
      const trialCounterItem = document.getElementById('ocus-trial-counter-item');
      const trialRemainingEl = document.getElementById('ocus-trial-remaining');
      
      // Check activation status
      const isActivated = result.isActivated || 
                         (result.activation_key_data && result.activation_key_data.isActivated);
      
      if (!isActivated) {
        const trialUsed = result.ocus_trial_count || 0;
        const remaining = Math.max(0, 3 - trialUsed);
        
        if (trialCounterItem) {
          // Fixed: Ensure trial counter is always visible by removing display: none
          trialCounterItem.style.display = 'block';
          trialCounterItem.style.visibility = 'visible';
        }
        if (trialRemainingEl) {
          trialRemainingEl.textContent = remaining;
          trialRemainingEl.style.display = 'block';
        }
        
        // If trial exhausted, show warning and stop automation
        if (remaining === 0) {
          const statusEl = document.getElementById('ocus-status-message');
          if (statusEl) {
            statusEl.textContent = 'Trial exhausted - Please activate extension';
            statusEl.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
          }
          
          // Stop refresh timer if trial exhausted
          stopRefreshTimer();
          hideCountdownPanel();
        }
      } else {
        // Hide trial counter if activated
        if (trialCounterItem) {
          trialCounterItem.style.display = 'none';
        }
        
        // Update normal status message
        const statusElement = document.getElementById('ocus-status-message');
        if (statusElement) {
          if (stats.lastRefreshTime) {
            const lastTime = new Date(stats.lastRefreshTime);
            statusElement.textContent = `Last refresh: ${lastTime.toLocaleTimeString()}`;
          } else {
            statusElement.textContent = 'Ready';
          }
        }
      }
    });
  }
  
  // Update the statistics display
  function updateStatsDisplay() {
    if (!statsPanel) return;
    
    // Update stats values
    document.getElementById('ocus-stats-found').textContent = stats.missionsFound || 0;
    document.getElementById('ocus-stats-opened').textContent = stats.missionsOpened || 0;
    document.getElementById('ocus-stats-accepted').textContent = stats.missionsAccepted || 0;
    document.getElementById('ocus-stats-refreshes').textContent = stats.totalRefreshes || 0;
    document.getElementById('ocus-stats-logins').textContent = stats.loginAttempts || 0;
    
    // Update last refresh time
    const lastRefreshEl = document.getElementById('ocus-stats-last-refresh');
    if (stats.lastRefreshTime) {
      const lastRefreshDate = new Date(stats.lastRefreshTime);
      const hours = lastRefreshDate.getHours().toString().padStart(2, '0');
      const minutes = lastRefreshDate.getMinutes().toString().padStart(2, '0');
      const seconds = lastRefreshDate.getSeconds().toString().padStart(2, '0');
      lastRefreshEl.textContent = `Last refresh: ${hours}:${minutes}:${seconds}`;
    } else {
      lastRefreshEl.textContent = 'Last refresh: Never';
    }
  }
  
  // Show statistics panel
  function showStatsPanel() {
    if (statsPanel) {
      statsPanel.classList.remove('ocus-hidden');
    }
  }
  
  // Hide statistics panel
  function hideStatsPanel() {
    if (statsPanel) {
      statsPanel.classList.add('ocus-hidden');
    }
  }
  
  // Toggle statistics panel visibility
  function toggleStatsPanel() {
    if (statsPanel) {
      if (statsPanel.classList.contains('ocus-hidden')) {
        showStatsPanel();
      } else {
        hideStatsPanel();
      }
    }
  }
  
  // Load saved panel positions from storage
  function loadPanelPositions(callback) {
    chrome.storage.local.get(['panelPositions'], function(result) {
      if (result.panelPositions) {
        panelPositions = result.panelPositions;
        log('Loaded saved panel positions:', panelPositions);
      }
      if (callback) callback();
    });
  }
  
  // Save panel positions to storage
  function savePanelPositions() {
    chrome.storage.local.set({ panelPositions }, function() {
      log('Saved panel positions:', panelPositions);
    });
  }
  
  // Setup global drag event handlers
  function setupDragHandlers() {
    // Prevent native draggable behavior which causes issues
    document.addEventListener('dragstart', function(e) {
      if (e.target.matches('.ocus-countdown-header, .ocus-stats-header')) {
        e.preventDefault();
      }
    });
    
    // Mouse down event for starting drag
    document.addEventListener('mousedown', function(e) {
      // Only handle drag on headers and not on buttons within headers
      if ((e.target.matches('.ocus-countdown-header, .ocus-stats-header') || 
           e.target.matches('.ocus-countdown-header span, .ocus-stats-header span')) && 
          !e.target.matches('button')) {
        
        e.preventDefault();
        
        // Determine which panel we're dragging
        const panel = e.target.closest('.ocus-refresh-countdown, .ocus-stats-panel, .ocus-unified-panel');
        if (!panel) return;
        
        isDragging = true;
        currentDragElement = panel;
        
        // Calculate offset from where the mouse clicked relative to panel top-left
        const rect = panel.getBoundingClientRect();
        dragOffsetX = e.clientX - rect.left;
        dragOffsetY = e.clientY - rect.top;
        
        // Add a class to indicate dragging
        panel.classList.add('ocus-dragging');
        
        log('Started dragging panel:', panel.id);
        
        // Prevent text selection during drag
        e.preventDefault();
      }
    });
    
    // Mouse move event for dragging
    document.addEventListener('mousemove', function(e) {
      if (isDragging && currentDragElement) {
        // Calculate new position
        const newLeft = e.clientX - dragOffsetX;
        const newTop = e.clientY - dragOffsetY;
        
        // Apply new position
        currentDragElement.style.right = 'auto';
        currentDragElement.style.bottom = 'auto';
        currentDragElement.style.left = newLeft + 'px';
        currentDragElement.style.top = newTop + 'px';
        
        // Prevent text selection during drag
        e.preventDefault();
      }
    });
    
    // Mouse up event for ending drag
    document.addEventListener('mouseup', function() {
      if (isDragging && currentDragElement) {
        // Save the final positions
        const panelId = currentDragElement.id === 'ocus-refresh-countdown' ? 'countdownPanel' : 'statsPanel';
        panelPositions[panelId] = {
          left: currentDragElement.style.left,
          top: currentDragElement.style.top,
          right: 'auto',
          bottom: 'auto'
        };
        
        // Remove dragging class
        currentDragElement.classList.remove('ocus-dragging');
        
        // Save positions to storage
        savePanelPositions();
        
        log('Saved new position for', panelId);
        
        // Reset drag state
        isDragging = false;
        currentDragElement = null;
      }
    });
    
    // Add a small amount of CSS for the dragging state
    const dragStyle = document.createElement('style');
    dragStyle.textContent = `
      .ocus-dragging {
        opacity: 0.8;
        transition: none !important;
        z-index: 10000;
      }
    `;
    document.head.appendChild(dragStyle);
  }
})();
