// OCUS Job Hunter Extension - Background Script
// Installation-based activation system

class BackgroundManager {
  constructor() {
    this.init();
  }

  init() {
    // Handle extension installation
    chrome.runtime.onInstalled.addListener((details) => {
      this.handleInstallation(details);
    });

    // Handle extension startup
    chrome.runtime.onStartup.addListener(() => {
      console.log('OCUS Extension started');
    });

    // Request notification permission
    this.requestNotificationPermission();
  }

  handleInstallation(details) {
    console.log('OCUS Extension installed:', details.reason);
    
    if (details.reason === 'install') {
      // First time installation
      this.showWelcomeNotification();
      
      // Open the main website for activation
      chrome.tabs.create({
        url: 'https://app.ocus.com'
      });
    } else if (details.reason === 'update') {
      // Extension updated
      console.log('Extension updated to version', chrome.runtime.getManifest().version);
    }
  }

  async requestNotificationPermission() {
    try {
      const permission = await chrome.permissions.request({
        permissions: ['notifications']
      });
      
      if (permission) {
        console.log('Notification permission granted');
      }
    } catch (error) {
      console.log('Notification permission not available:', error);
    }
  }

  showWelcomeNotification() {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icon48.png',
      title: 'OCUS Job Hunter Installed!',
      message: 'Navigate to app.ocus.com and click the extension icon to activate.'
    });
  }
}

// Initialize background manager
new BackgroundManager();