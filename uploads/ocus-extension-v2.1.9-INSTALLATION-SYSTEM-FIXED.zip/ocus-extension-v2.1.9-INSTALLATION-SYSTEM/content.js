// OCUS Job Hunter Extension - Content Script
// Installation-based activation system integration

class OcusExtensionManager {
  constructor() {
    this.activationManager = null;
    this.isInitialized = false;
    this.missionAcceptor = null;
    
    this.init();
  }

  async init() {
    try {
      // Wait for activation manager to be available
      await this.waitForActivationManager();
      
      // Setup message listener for popup communication
      this.setupMessageListener();
      
      // Initialize mission acceptor if activated
      if (this.activationManager.isActivated) {
        this.initializeMissionAcceptor();
      }
      
      this.isInitialized = true;
      console.log('OCUS Extension Manager initialized successfully');
    } catch (error) {
      console.error('Failed to initialize OCUS Extension Manager:', error);
    }
  }

  async waitForActivationManager() {
    let attempts = 0;
    const maxAttempts = 20; // 10 seconds max
    
    while (attempts < maxAttempts) {
      if (window.ocusActivationManager) {
        this.activationManager = window.ocusActivationManager;
        return;
      }
      
      await new Promise(resolve => setTimeout(resolve, 500));
      attempts++;
    }
    
    throw new Error('Activation manager not available');
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      this.handleMessage(request, sender, sendResponse);
      return true; // Keep the message channel open for async responses
    });
  }

  async handleMessage(request, sender, sendResponse) {
    try {
      switch (request.action) {
        case 'getActivationStatus':
          const status = this.activationManager.getActivationStatus();
          sendResponse({
            ...status,
            stats: this.getMissionStats()
          });
          break;

        case 'activateExtension':
          const result = await this.activationManager.activateWithCode(request.code);
          
          if (result.success) {
            // Initialize mission acceptor after successful activation
            this.initializeMissionAcceptor();
            
            sendResponse({
              success: true,
              message: result.message,
              installationId: this.activationManager.installationId
            });
          } else {
            sendResponse({
              success: false,
              message: result.message
            });
          }
          break;

        case 'deactivateExtension':
          await this.activationManager.deactivate();
          
          // Stop mission acceptor
          if (this.missionAcceptor) {
            this.missionAcceptor.stop();
            this.missionAcceptor = null;
          }
          
          sendResponse({
            success: true,
            message: 'Extension deactivated successfully',
            installationId: this.activationManager.installationId
          });
          break;

        default:
          sendResponse({ success: false, message: 'Unknown action' });
      }
    } catch (error) {
      console.error('Message handling error:', error);
      sendResponse({ 
        success: false, 
        message: 'Internal error: ' + error.message 
      });
    }
  }

  initializeMissionAcceptor() {
    if (this.missionAcceptor) {
      return; // Already initialized
    }

    // Create simple mission acceptor for activated users
    this.missionAcceptor = new MissionAcceptor();
    console.log('Mission acceptor initialized for activated user');
  }

  getMissionStats() {
    // Get stats from localStorage or mission acceptor
    const stats = JSON.parse(localStorage.getItem('ocus_mission_stats') || '{}');
    
    return {
      missionsAccepted: stats.accepted || 0,
      successRate: stats.successRate || 0,
      lastActivity: stats.lastActivity || null
    };
  }

  updateMissionStats(accepted = false, success = false) {
    const stats = this.getMissionStats();
    
    if (accepted) {
      stats.missionsAccepted = (stats.missionsAccepted || 0) + 1;
    }
    
    if (success) {
      const total = stats.missionsAccepted || 1;
      const currentSuccesses = Math.floor((stats.successRate || 0) * total / 100);
      stats.successRate = Math.round(((currentSuccesses + 1) / total) * 100);
    }
    
    stats.lastActivity = new Date().toISOString();
    localStorage.setItem('ocus_mission_stats', JSON.stringify(stats));
  }
}

// Simple Mission Acceptor for activated users
class MissionAcceptor {
  constructor() {
    this.isRunning = false;
    this.checkInterval = null;
    this.start();
  }

  start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('Mission acceptor started');
    
    // Check for missions every 5 seconds
    this.checkInterval = setInterval(() => {
      this.checkForMissions();
    }, 5000);
  }

  stop() {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    
    console.log('Mission acceptor stopped');
  }

  checkForMissions() {
    // Look for mission accept buttons
    const acceptButtons = document.querySelectorAll('[data-cy="accept-mission-button"], button[contains(@class, "accept")]');
    
    acceptButtons.forEach(button => {
      if (button && !button.disabled && button.offsetParent !== null) {
        // Found an available mission
        this.acceptMission(button);
      }
    });
  }

  acceptMission(button) {
    try {
      // Click the accept button
      button.click();
      
      // Update stats
      if (window.ocusExtensionManager) {
        window.ocusExtensionManager.updateMissionStats(true, true);
      }
      
      console.log('Mission accepted successfully');
      
      // Show notification
      this.showNotification('Mission Accepted!', 'A new mission has been accepted automatically.');
      
    } catch (error) {
      console.error('Failed to accept mission:', error);
    }
  }

  showNotification(title, message) {
    // Create simple notification
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, {
        body: message,
        icon: chrome.runtime.getURL('icon48.png')
      });
    }
  }
}

// Initialize the extension manager
window.ocusExtensionManager = new OcusExtensionManager();