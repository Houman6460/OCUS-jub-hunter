// OCUS Job Hunter Extension - Popup Script
// Installation-based activation system

class PopupManager {
  constructor() {
    this.activationManager = null;
    this.init();
  }

  async init() {
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.setupUI());
    } else {
      this.setupUI();
    }
  }

  setupUI() {
    // Get references to UI elements
    this.statusBadge = document.getElementById('statusBadge');
    this.installationInfo = document.getElementById('installationInfo');
    this.activationSection = document.getElementById('activationSection');
    this.activatedSection = document.getElementById('activatedSection');
    this.activationCodeInput = document.getElementById('activationCode');
    this.activateBtn = document.getElementById('activateBtn');
    this.deactivateBtn = document.getElementById('deactivateBtn');
    this.messageContainer = document.getElementById('messageContainer');
    this.purchaseLink = document.getElementById('purchaseLink');
    this.missionsAccepted = document.getElementById('missionsAccepted');
    this.successRate = document.getElementById('successRate');

    // Setup event listeners
    this.activateBtn.addEventListener('click', () => this.handleActivation());
    this.deactivateBtn.addEventListener('click', () => this.handleDeactivation());
    this.purchaseLink.addEventListener('click', () => this.openPurchasePage());

    // Initialize connection to content script
    this.connectToContentScript();
  }

  async connectToContentScript() {
    try {
      // Get current tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (tab && tab.url && tab.url.includes('app.ocus.com')) {
        // Try to get activation status from content script
        chrome.tabs.sendMessage(tab.id, { action: 'getActivationStatus' }, (response) => {
          if (chrome.runtime.lastError) {
            console.log('No content script available, showing basic UI');
            this.updateStatus({
              isActivated: false,
              installationId: 'Not connected to OCUS',
              activationCode: null
            });
          } else if (response) {
            this.updateStatus(response);
          }
        });
      } else {
        this.updateStatus({
          isActivated: false,
          installationId: 'Please navigate to app.ocus.com',
          activationCode: null
        });
      }
    } catch (error) {
      console.error('Failed to connect to content script:', error);
      this.updateStatus({
        isActivated: false,
        installationId: 'Connection error',
        activationCode: null
      });
    }
  }

  updateStatus(status) {
    // Update status badge
    if (status.isActivated) {
      this.statusBadge.textContent = 'ACTIVATED';
      this.statusBadge.className = 'status-badge status-active';
      this.activationSection.classList.add('hidden');
      this.activatedSection.classList.remove('hidden');
    } else {
      this.statusBadge.textContent = 'NOT ACTIVATED';
      this.statusBadge.className = 'status-badge status-inactive';
      this.activationSection.classList.remove('hidden');
      this.activatedSection.classList.add('hidden');
    }

    // Update installation info
    const installationId = status.installationId || 'Unknown';
    this.installationInfo.textContent = `Installation: ${installationId.substring(0, 20)}...`;

    // If activated, show the activation code
    if (status.activationCode) {
      this.activationCodeInput.value = status.activationCode;
    }

    // Update stats if available
    if (status.stats) {
      this.missionsAccepted.textContent = status.stats.missionsAccepted || 0;
      this.successRate.textContent = `${status.stats.successRate || 0}%`;
    }
  }

  async handleActivation() {
    const code = this.activationCodeInput.value.trim();
    
    if (!code) {
      this.showMessage('Please enter an activation code', 'error');
      return;
    }

    this.activateBtn.textContent = 'Activating...';
    this.activateBtn.disabled = true;

    try {
      // Get current tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.url || !tab.url.includes('app.ocus.com')) {
        this.showMessage('Please navigate to app.ocus.com first', 'error');
        return;
      }

      // Send activation request to content script
      chrome.tabs.sendMessage(tab.id, { 
        action: 'activateExtension', 
        code: code 
      }, (response) => {
        if (chrome.runtime.lastError) {
          this.showMessage('Failed to communicate with extension. Please refresh the page.', 'error');
        } else if (response) {
          if (response.success) {
            this.showMessage(response.message, 'success');
            this.updateStatus({
              isActivated: true,
              installationId: response.installationId,
              activationCode: code
            });
          } else {
            this.showMessage(response.message, 'error');
          }
        }
      });

    } catch (error) {
      console.error('Activation error:', error);
      this.showMessage('Activation failed. Please try again.', 'error');
    } finally {
      this.activateBtn.textContent = 'Activate Extension';
      this.activateBtn.disabled = false;
    }
  }

  async handleDeactivation() {
    if (!confirm('Are you sure you want to deactivate the extension?')) {
      return;
    }

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (tab && tab.url && tab.url.includes('app.ocus.com')) {
        chrome.tabs.sendMessage(tab.id, { action: 'deactivateExtension' }, (response) => {
          if (response && response.success) {
            this.showMessage('Extension deactivated successfully', 'success');
            this.updateStatus({
              isActivated: false,
              installationId: response.installationId,
              activationCode: null
            });
          }
        });
      }
    } catch (error) {
      console.error('Deactivation error:', error);
      this.showMessage('Deactivation failed', 'error');
    }
  }

  openPurchasePage() {
    // Open the dashboard/login page in a new tab
    // For testing locally, always use localhost:5000
    const purchaseUrl = 'http://localhost:5000/dashboard';
    
    console.log('🔗 Opening purchase page:', purchaseUrl);
    chrome.tabs.create({ url: purchaseUrl });
  }

  detectBaseURL() {
    // Try to detect the correct backend URL
    const hostname = window.location.hostname;
    
    if (hostname === 'localhost' || hostname === '127.0.0.1') {
      return 'http://localhost:5000';
    }
    
    // For production, try to detect the domain
    if (hostname.includes('replit.app') || hostname.includes('replit.dev')) {
      return window.location.origin.replace('https://app.ocus.com', 'https://your-replit-app-url.replit.app');
    }
    
    // Default production URL
    return 'https://your-production-domain.com';
  }

  showMessage(message, type) {
    this.messageContainer.innerHTML = '';
    
    const messageEl = document.createElement('div');
    messageEl.className = `message message-${type}`;
    messageEl.textContent = message;
    
    this.messageContainer.appendChild(messageEl);
    
    // Auto-hide success messages after 3 seconds
    if (type === 'success') {
      setTimeout(() => {
        if (messageEl.parentNode) {
          messageEl.remove();
        }
      }, 3000);
    }
  }
}

// Initialize popup manager
new PopupManager();