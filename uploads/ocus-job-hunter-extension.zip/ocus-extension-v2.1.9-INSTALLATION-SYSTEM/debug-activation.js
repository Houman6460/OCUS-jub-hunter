// Debug helper for activation issues
// This script can be run in browser console to test extension activation

class DebugActivation {
    constructor() {
        this.baseURL = this.detectBaseURL();
        console.log('🔧 Debug Activation Helper Loaded');
        console.log('🌐 Base URL:', this.baseURL);
    }

    detectBaseURL() {
        const hostname = window.location.hostname;
        console.log('🔍 Current hostname:', hostname);
        
        if (hostname === 'localhost' || hostname === '127.0.0.1') {
            console.log('✅ Using localhost backend');
            return 'http://localhost:5000';
        }
        
        if (hostname.includes('replit.app') || hostname.includes('replit.dev')) {
            const replitURL = window.location.origin.replace('https://app.ocus.com', window.location.origin);
            console.log('✅ Using Replit backend:', replitURL);
            return replitURL;
        }
        
        console.log('⚠️ Using default production backend');
        return 'https://your-production-domain.com';
    }

    generateInstallationId() {
        const timestamp = Date.now();
        const random = Math.random().toString(36).substring(2, 15);
        const screen = `${window.screen.width}x${window.screen.height}`;
        const fingerprint = btoa(`${timestamp}-${random}-${screen}`).substring(0, 32);
        return `install-${timestamp}-${fingerprint}`;
    }

    async testConnection() {
        console.log('🔄 Testing basic connection...');
        try {
            const response = await fetch(`${this.baseURL}/api/products/pricing`);
            if (response.ok) {
                const data = await response.json();
                console.log('✅ Connection successful:', data.name);
                return true;
            } else {
                console.error('❌ Connection failed:', response.status, response.statusText);
                return false;
            }
        } catch (error) {
            console.error('❌ Network error:', error.message);
            return false;
        }
    }

    async testValidation(code = 'OCUS-1754324507792-K05VJND6') {
        console.log('🔄 Testing activation validation...');
        const installationId = this.generateInstallationId();
        
        try {
            console.log('📝 Request URL:', `${this.baseURL}/api/extension/validate-activation`);
            console.log('📝 Request payload:', { activationCode: code, installationId });
            
            const response = await fetch(`${this.baseURL}/api/extension/validate-activation`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    activationCode: code,
                    installationId: installationId
                })
            });

            console.log('📡 Response status:', response.status);
            console.log('📡 Response headers:', [...response.headers.entries()]);
            
            if (!response.ok) {
                console.error('❌ HTTP Error:', response.status, response.statusText);
                return false;
            }

            const result = await response.json();
            console.log('📋 Response data:', result);
            
            if (result.valid) {
                console.log('✅ Validation successful!');
                console.log('💬 Message:', result.message);
                console.log('🆔 Activation ID:', result.activationId);
                return true;
            } else {
                console.error('❌ Validation failed:', result.message);
                return false;
            }
        } catch (error) {
            console.error('❌ Validation error:', error);
            return false;
        }
    }

    async runFullTest() {
        console.clear();
        console.log('🧪 Starting Full Debug Test');
        console.log('='.repeat(50));
        
        const connectionOK = await this.testConnection();
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const validationOK = await this.testValidation();
        
        console.log('='.repeat(50));
        console.log('📊 Test Results:');
        console.log('Connection:', connectionOK ? '✅ OK' : '❌ FAILED');
        console.log('Validation:', validationOK ? '✅ OK' : '❌ FAILED');
        
        if (connectionOK && validationOK) {
            console.log('🎉 All tests passed! Extension should work.');
        } else {
            console.log('⚠️ Some tests failed. Check the errors above.');
        }
    }
}

// Auto-run debug test if this script is loaded
if (typeof window !== 'undefined') {
    window.debugActivation = new DebugActivation();
    console.log('🔧 Debug helper available as window.debugActivation');
    console.log('🔧 Run debugActivation.runFullTest() to test everything');
}