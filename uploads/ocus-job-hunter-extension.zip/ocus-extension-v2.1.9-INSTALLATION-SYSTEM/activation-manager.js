// !!! CRITICAL - INSTALLATION-BASED ACTIVATION SYSTEM !!!
//
// This activation manager implements the new installation-based system where:
// 1. Each extension installation has a unique ID
// 2. Activation codes are bound to specific installations 
// 3. One-to-one activation binding prevents sharing
// 4. Daily validation limits prevent abuse
//
// <BEGIN_ACTIVATION_MANAGER>

class ActivationManager {
  constructor() {
    this.baseURL = this.detectBaseURL();
    this.installationId = null;
    this.isActivated = false;
    this.activationCode = null;
    this.lastValidation = null;
    this.validationInterval = 5 * 60 * 1000; // 5 minutes
    
    this.init();
  }

  detectBaseURL() {
    // FIXED: Always use localhost for development
    console.log('🔍 Detecting base URL from window.location:', window.location.href);
    
    // For extensions, we need to determine the backend URL differently
    // Since extensions run on app.ocus.com, we can't rely on window.location
    
    // For development (when testing locally)
    if (window.location.href.includes('localhost') || 
        window.location.hostname === 'localhost' || 
        window.location.hostname === '127.0.0.1') {
      console.log('✅ Using localhost backend');
      return 'http://localhost:5000';
    }
    
    // For extension context (running on app.ocus.com)
    // We need to determine if we're in development or production
    // For now, default to localhost for testing
    console.log('⚠️ Extension context detected, using localhost for testing');
    return 'http://localhost:5000';
  }

  async init() {
    try {
      // Get or create installation ID
      await this.initializeInstallation();
      
      // Check current activation status
      await this.checkActivationStatus();
      
      // Start periodic validation if activated
      if (this.isActivated) {
        this.startPeriodicValidation();
      }
    } catch (error) {
      console.error('ActivationManager initialization failed:', error);
    }
  }

  async initializeInstallation() {
    // Get stored installation ID or create new one
    let installationId = localStorage.getItem('ocus_installation_id');
    
    if (!installationId) {
      // Generate unique installation ID
      installationId = this.generateInstallationId();
      localStorage.setItem('ocus_installation_id', installationId);
    }
    
    this.installationId = installationId;
    
    // Register installation with server
    await this.registerInstallation();
  }

  generateInstallationId() {
    // Create unique ID based on timestamp and random values
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 15);
    const userAgent = navigator.userAgent.slice(0, 50);
    
    // Create a more unique fingerprint
    const fingerprint = btoa(userAgent + timestamp + random).substring(0, 32);
    
    return `install-${timestamp}-${fingerprint}`;
  }

  async registerInstallation() {
    try {
      const deviceFingerprint = this.createDeviceFingerprint();
      
      const response = await fetch(`${this.baseURL}/api/extension/register-installation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          installationId: this.installationId,
          deviceFingerprint,
          userAgent: navigator.userAgent,
          extensionVersion: '2.1.9'
        })
      });

      const result = await response.json();
      
      if (!result.success) {
        console.error('Failed to register installation:', result.error);
      } else {
        console.log('Installation registered successfully:', result.message);
      }
    } catch (error) {
      console.error('Installation registration error:', error);
    }
  }

  createDeviceFingerprint() {
    // Create a device fingerprint (non-invasive)
    const screen = `${window.screen.width}x${window.screen.height}`;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const language = navigator.language;
    const platform = navigator.platform;
    
    return btoa(`${screen}-${timezone}-${language}-${platform}`).substring(0, 50);
  }

  async checkActivationStatus() {
    try {
      const response = await fetch(`${this.baseURL}/api/extension/activation-status/${this.installationId}`);
      
      if (response.ok) {
        const status = await response.json();
        this.isActivated = status.isActivated;
        
        if (status.activationCode) {
          this.activationCode = status.activationCode.code;
        }
        
        console.log('Activation status:', this.isActivated ? 'ACTIVATED' : 'NOT ACTIVATED');
      }
    } catch (error) {
      console.error('Failed to check activation status:', error);
    }
  }

  async validateActivationCode(code) {
    try {
      console.log('🌐 Making validation request to:', `${this.baseURL}/api/extension/validate-activation`);
      console.log('📝 Request payload:', { activationCode: code, installationId: this.installationId });
      
      const response = await fetch(`${this.baseURL}/api/extension/validate-activation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          activationCode: code,
          installationId: this.installationId
        })
      });

      console.log('📡 Response status:', response.status);
      
      if (!response.ok) {
        console.error('❌ HTTP Error:', response.status, response.statusText);
        return { success: false, message: `Server error: ${response.status}` };
      }

      const result = await response.json();
      console.log('📋 Response data:', result);
      
      if (result.valid) {
        this.isActivated = true;
        this.activationCode = code;
        this.lastValidation = Date.now();
        
        // Save activation state
        localStorage.setItem('ocus_activation_code', code);
        localStorage.setItem('ocus_last_validation', this.lastValidation.toString());
        
        // Start periodic validation
        this.startPeriodicValidation();
        
        console.log('✅ Activation successful!');
        return { success: true, message: 'Extension activated successfully!' };
      } else {
        console.log('❌ Activation failed:', result.message);
        return { success: false, message: result.message || 'Invalid activation code' };
      }
    } catch (error) {
      console.error('❗ Validation error:', error);
      return { success: false, message: `Network error: ${error.message}` };
    }
  }

  startPeriodicValidation() {
    // Clear any existing interval
    if (this.validationTimer) {
      clearInterval(this.validationTimer);
    }
    
    this.validationTimer = setInterval(async () => {
      if (this.activationCode) {
        await this.validateActivationCode(this.activationCode);
      }
    }, this.validationInterval);
  }

  stopPeriodicValidation() {
    if (this.validationTimer) {
      clearInterval(this.validationTimer);
      this.validationTimer = null;
    }
  }

  async deactivate() {
    this.isActivated = false;
    this.activationCode = null;
    this.lastValidation = null;
    
    // Clear stored data
    localStorage.removeItem('ocus_activation_code');
    localStorage.removeItem('ocus_last_validation');
    
    // Stop validation
    this.stopPeriodicValidation();
    
    console.log('Extension deactivated');
  }

  // Public API methods
  getActivationStatus() {
    return {
      isActivated: this.isActivated,
      installationId: this.installationId,
      activationCode: this.activationCode,
      lastValidation: this.lastValidation
    };
  }

  async activateWithCode(code) {
    if (!code || typeof code !== 'string') {
      return { success: false, message: 'Please enter a valid activation code' };
    }
    
    console.log('🔑 Activating with code:', code);
    console.log('🆔 Installation ID:', this.installationId);
    console.log('🌐 Base URL:', this.baseURL);
    
    // Clean the code (remove spaces, convert to uppercase)
    const cleanCode = code.trim().toUpperCase();
    console.log('🧹 Cleaned code:', cleanCode);
    
    const result = await this.validateActivationCode(cleanCode);
    console.log('✅ Activation result:', result);
    return result;
  }
}

// Create global activation manager instance
window.ocusActivationManager = new ActivationManager();

// <END_ACTIVATION_MANAGER>

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = ActivationManager;
}