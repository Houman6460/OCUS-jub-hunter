# OCUS Unified Extension

A Chrome extension that combines the functionality of three separate OCUS extensions into a single unified package:

1. **OCUS Automation** - Auto-login to the OCUS website
2. **OCUS Auto Clicker** - Monitor for new missions and open them in new tabs
3. **OCUS Auto Accept** - Automatically accept missions and close tabs

## Features

### Auto Login

- Automatically logs in to the OCUS platform using stored credentials
- Configurable maximum login attempts
- Tracks successful logins

### Mission Monitor

- Automatically scans for available missions on the OCUS platform
- Opens detected missions in new tabs
- Configurable refresh interval and maximum simultaneous missions
- Keeps track of processed missions to avoid duplicates

### Mission Acceptor

- Automatically accepts missions when opened in new tabs
- Option to automatically close tabs after successful acceptance
- Configurable close delay
- Enhanced Vue/Nuxt.js support for improved reliability
- Intelligent button detection and verification

### Emergency Controls

- Access quick controls by pressing Alt+E on any OCUS page
- Emergency stop button to disable all automation at once
- Individual toggle switches for each feature

## Installation

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top-right corner
4. Click "Load unpacked" and select the extension folder
5. The extension icon will appear in your browser toolbar

## Configuration

Click on the extension icon to open the configuration popup:

- **Auto Login**: Configure your OCUS username and password
- **Mission Monitor**: Set refresh interval and maximum simultaneous missions
- **Mission Acceptor**: Configure auto-close behavior and delay
- **Statistics**: View performance metrics and reset if needed

## Usage

1. Configure the extension by clicking on its icon
2. Visit the OCUS platform
3. The extension will automatically:
   - Log you in (if enabled)
   - Monitor for new missions (if enabled)
   - Accept missions (if enabled)
4. Access emergency controls at any time by pressing Alt+E

## Security Notes

- Credentials are stored locally in Chrome's secure storage
- No data is transmitted outside of the OCUS platform
- For testing purposes, credentials are stored in plain text

## Troubleshooting

If the extension isn't working as expected:

1. Check that all required permissions are granted
2. Ensure the extension is enabled
3. Verify your configuration settings
4. Try disabling and re-enabling the extension
5. Clear your browser cache and cookies

### Vue/Nuxt.js Support Troubleshooting

If you're experiencing issues with Vue/Nuxt.js based pages:

1. Check the console logs for diagnostic information
2. Ensure you're using the latest version of the extension
3. If mission acceptance fails on Vue pages, try increasing the `maxAttempts` value
4. For persistent issues, check the Vue component structure using browser developer tools

## Development

This extension combines the functionality of three separate extensions while maintaining all the original methods, URLs, and elements used on the OCUS website.

### File Structure
- `manifest.json` - Extension configuration
- `background.js` - Background script for initialization and message handling
- `content.js` - Main content script that integrates all functionality
- `login-functions.js` - Handles auto-login functionality
- `mission-monitor.js` - Monitors for and opens new missions
- `mission-acceptor.js` - Automatically accepts missions
- `vue-support.js` - Provides Vue/Nuxt.js specific support functionality
- `emergency-panel.js` - Provides emergency controls
- `popup.html` and `popup.js` - Configuration interface

## License

This extension is for personal use only and is not affiliated with OCUS or any related entities.
