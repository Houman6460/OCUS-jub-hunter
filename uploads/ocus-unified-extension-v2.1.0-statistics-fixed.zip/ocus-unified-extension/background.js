/**
 * OCUS Unified Extension - Background Script
 * 
 * Combines functionality from three extensions:
 * 1. OCUS Automation (login)
 * 2. OCUS Auto Clicker (mission monitoring)
 * 3. OCUS Auto Accept (mission acceptance)
 */

// Default configuration for the unified extension
const DEFAULT_CONFIG = {
  // Auto-login settings
  autoLogin: {
    enabled: false,
    username: '',
    password: '',
    maxLoginAttempts: 5
  },
  // Mission monitoring settings
  missionMonitor: {
    enabled: true,
    refreshInterval: 30000,
    showNotifications: true,
    maxSimultaneousMissions: 3,
    openInNewTab: true
  },
  // Mission acceptance settings
  missionAccept: {
    enabled: true,
    autoClose: true,
    closeDelay: 2000
  },
  // Page refresh timer settings
  pageRefresh: {
    enabled: false,
    intervalSeconds: 30,
    showCountdown: true
  },
  // Set to track processed missions
  processedMissions: []
};

// Initialize storage with default values if not already set
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === 'install') {
    chrome.storage.local.set({ 
      config: DEFAULT_CONFIG,
      stats: {
        totalClicks: 0,
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        loginAttempts: 0,
        successfulLogins: 0,
        totalRefreshes: 0,
        lastLoginTime: null
      }
    });
    console.log('OCUS Unified Extension installed with default configuration');
    
    // Show installation notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'OCUS Unified Extension Installed',
      message: 'The extension will automate login, mission monitoring, and acceptance on the OCUS platform',
      priority: 2
    });
  }
});

// Handle browser startup
chrome.runtime.onStartup.addListener(() => {
  // Auto-activate when browser starts
  chrome.storage.local.get(['config'], (result) => {
    const config = result.config || DEFAULT_CONFIG;
    
    console.log('OCUS Unified Extension initialized on browser startup');
    
    // Update icon badge based on configuration
    updateBadgeStatus(config);
  });
});

// Listen for tab updates to inject content scripts when needed
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // Only proceed if the tab URL matches OCUS domains and the page has completed loading
  if (changeInfo.status === 'complete' && 
     (tab.url?.includes('app.ocus.com') || tab.url?.includes('ocus.work'))) {
    console.log('Tab updated with OCUS URL:', tab.url);
    
    // Check if we need to initialize content scripts
    chrome.storage.local.get(['config'], (result) => {
      const config = result.config || DEFAULT_CONFIG;
      
      // Send configuration to the content scripts
      chrome.tabs.sendMessage(tabId, { 
        type: 'CONFIG_UPDATED', 
        config: config
      }).catch(() => {
        // Catch error that occurs when content script is not yet ready
        console.log('Content script not ready, this is normal on first load');
      });
      
      // Force a login check on each page load
      setTimeout(() => {
        chrome.tabs.sendMessage(tabId, { type: 'FORCE_LOGIN_CHECK' }).catch(() => {
          console.log('Could not send login check message, content script may not be ready');
        });
      }, 1000);
    });
  }
});

// Listen for navigation events to catch login pages
chrome.webNavigation.onCompleted.addListener((details) => {
  // Check if the URL contains login-related paths
  if (details.url.includes('/login') || 
      details.url.includes('/auth') || 
      details.url.includes('/sign-in')) {
        
    console.log('Navigation to possible login page detected:', details.url);
    
    // Get config and check if auto-login is enabled
    chrome.storage.local.get(['config'], (result) => {
      const config = result.config || DEFAULT_CONFIG;
      
      if (config.autoLogin.enabled) {
        console.log('Auto-login enabled, will force login attempt');
        
        // Give the page a moment to fully load before attempting login
        setTimeout(() => {
          chrome.tabs.sendMessage(details.tabId, { type: 'FORCE_LOGIN' })
            .catch(() => console.log('Could not send force login message, content script may not be ready'));
        }, 1500);
      }
    });
  }
}, {
  url: [{ urlContains: 'ocus.com' }, { urlContains: 'ocus.work' }]
});

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'ACTIVATE_EXTENSION') {
    // Handle activation request from popup
    handleActivationRequest(message.activationKey, sendResponse);
    return true; // Required for async response
  }
  
  if (message.type === 'GET_CONFIG') {
    chrome.storage.local.get(['config'], (result) => {
      let config = result.config || DEFAULT_CONFIG;
      
      // Ensure we have processedMissions array (backward compatibility)
      if (!config.processedMissions) {
        config.processedMissions = [];
        chrome.storage.local.set({ config });
      }
      
      sendResponse({ config });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'UPDATE_CONFIG') {
    // Save configuration
    chrome.storage.local.set({ config: message.config }, () => {
      // Update all tabs with new configuration
      updateAllTabs(message.config);
      
      // Update badge status
      updateBadgeStatus(message.config);
      
      console.log('Configuration updated in background script:', message.config);
      
      sendResponse({ success: true });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'PAGE_REFRESH_READY') {
    // A page is ready to receive the page refresh configuration
    console.log('Page refresh ready message received from tab:', sender.tab?.id);
    
    // Send the current configuration to the tab that sent the ready message
    chrome.storage.local.get(['config'], (result) => {
      if (result.config && sender.tab) {
        console.log('Sending configuration to tab:', sender.tab.id);
        chrome.tabs.sendMessage(sender.tab.id, {
          type: 'UPDATE_CONFIG',
          config: result.config
        });
      }
      sendResponse({ received: true });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'MISSION_FOUND') {
    // Update statistics for missions found
    chrome.storage.local.get(['stats'], (result) => {
      const stats = result.stats || { 
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        lastLoginTime: null
      };
      
      stats.missionsFound++;
      
      chrome.storage.local.set({ stats });
      sendResponse({ success: true });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'MISSION_OPENED') {
    // Update statistics for missions opened
    chrome.storage.local.get(['stats'], (result) => {
      const stats = result.stats || { 
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        lastLoginTime: null
      };
      
      stats.missionsOpened++;
      stats.totalClicks++;
      
      chrome.storage.local.set({ stats });
      sendResponse({ success: true });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'MISSION_ACCEPTED') {
    // Update statistics for missions accepted
    chrome.storage.local.get(['stats'], (result) => {
      const stats = result.stats || { 
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        lastLoginTime: null
      };
      
      stats.missionsAccepted++;
      
      chrome.storage.local.set({ stats });
      sendResponse({ success: true });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'LOGIN_ATTEMPT') {
    // Update statistics for login attempt
    chrome.storage.local.get(['stats'], (result) => {
      const stats = result.stats || { 
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        loginAttempts: 0,
        successfulLogins: 0,
        totalRefreshes: 0,
        lastLoginTime: null
      };
      
      stats.loginAttempts++;
      
      chrome.storage.local.set({ stats });
      sendResponse({ success: true });
    });
    return true; // Required for async response
  }

  if (message.type === 'LOGIN_COMPLETED') {
    // Update statistics for successful login
    chrome.storage.local.get(['stats'], (result) => {
      const stats = result.stats || { 
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        loginAttempts: 0,
        successfulLogins: 0,
        totalRefreshes: 0,
        lastLoginTime: null
      };
      
      stats.successfulLogins++;
      stats.lastLoginTime = new Date().toISOString();
      
      chrome.storage.local.set({ stats });
      
      // Show success notification
      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Login Successful',
        message: 'Successfully logged in to OCUS platform',
        priority: 1
      });
      
      sendResponse({ success: true });
    });
    return true; // Required for async response
  }

  if (message.type === 'PAGE_REFRESHED') {
    // Update statistics for page refresh
    chrome.storage.local.get(['stats'], (result) => {
      const stats = result.stats || { 
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        loginAttempts: 0,
        successfulLogins: 0,
        totalRefreshes: 0,
        lastLoginTime: null
      };
      
      stats.totalRefreshes++;
      
      chrome.storage.local.set({ stats });
      sendResponse({ success: true });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'LOGIN_FAILED') {
    console.log('Login failed:', message.reason);
    
    // Show failure notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'Login Failed',
      message: message.reason || 'Could not log in to OCUS platform',
      priority: 2
    });
    
    sendResponse({ success: true });
    return false;
  }
  
  if (message.type === 'CHECK_LOGIN_CREDENTIALS') {
    // Send current credentials to the requesting content script
    chrome.storage.local.get(['config'], (result) => {
      const config = result.config || DEFAULT_CONFIG;
      sendResponse({
        success: true,
        credentials: {
          username: config.autoLogin.username,
          password: config.autoLogin.password,
          enabled: config.autoLogin.enabled
        }
      });
    });
    return true; // Required for async response
  }
  
  if (message.type === 'SEND_NOTIFICATION') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: message.title || 'OCUS Unified Extension',
      message: message.message || '',
      priority: message.priority || 0
    });
    sendResponse({ success: true });
    return false;
  }
});

// When extension icon is clicked (simple toggle without opening popup)
chrome.action.onClicked.addListener((tab) => {
  if (tab.url.match(/^https?:\/\/.*ocus\.(com|work)/)) {
    chrome.storage.local.get(['config'], (result) => {
      const config = result.config || DEFAULT_CONFIG;
      
      // Toggle all features
      config.autoLogin.enabled = !config.autoLogin.enabled;
      config.missionMonitor.enabled = !config.missionMonitor.enabled;
      config.missionAccept.enabled = !config.missionAccept.enabled;
      
      // Update configuration
      chrome.storage.local.set({ config }, () => {
        // Update all tabs with new configuration
        updateAllTabs(config);
        
        // Update badge status
        updateBadgeStatus(config);
      });
    });
  }
});

// Helper function to update all tabs with new configuration
function updateAllTabs(config) {
  console.log('Updating all tabs with new configuration');
  
  // Get all OCUS tabs - Updated to include app.ocus.com explicitly
  chrome.tabs.query({ url: ['*://app.ocus.com/*', '*://*.ocus.work/*'] }, (tabs) => {
    if (tabs.length === 0) {
      console.log('No OCUS tabs found to update');
      return;
    }
    
    console.log('Found', tabs.length, 'OCUS tabs to update');
    
    // Update each tab with the new configuration
    for (const tab of tabs) {
      console.log('Sending config update to tab:', tab.id, 'URL:', tab.url);
      
      // Send message to content script - NOTE: using UPDATE_CONFIG instead of CONFIG_UPDATED
      // to match what the page-refresh-timer.js is listening for
      chrome.tabs.sendMessage(tab.id, { 
        type: 'UPDATE_CONFIG', 
        config: config
      }).catch((error) => {
        console.log(`Error updating tab ${tab.id}:`, error);
        // Non-blocking error handling
      });
    }
  });
}

// Handle activation request
async function handleActivationRequest(activationKey, sendResponse) {
  try {
    const response = await fetch('http://localhost:5000/api/activate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ activation_key: activationKey }),
      signal: AbortSignal.timeout(5000) // 5 second timeout
    });

    const result = await response.json();
    
    if (result.status === 'valid') {
      // Update stored config
      chrome.storage.local.get(['config'], (data) => {
        let config = data.config || DEFAULT_CONFIG;
        config.activation = {
          isActivated: true,
          activationKey: activationKey,
          activatedAt: new Date().toISOString()
        };
        
        chrome.storage.local.set({ config: config });
        updateBadgeStatus(config);
        
        sendResponse({ success: true });
      });
    } else {
      sendResponse({ success: false, message: 'Invalid activation key' });
    }
  } catch (error) {
    console.error('Activation request failed:', error);
    sendResponse({ success: false, message: 'Activation request failed. Please check your connection.' });
  }
}

// Helper function to update badge status
function updateBadgeStatus(config) {
  const isAnyEnabled = config.autoLogin.enabled || 
                       config.missionMonitor.enabled || 
                       config.missionAccept.enabled;
  
  // Check activation status
  if (config.activation?.isActivated) {
    if (isAnyEnabled) {
      chrome.action.setBadgeText({ text: 'ON' });
      chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
    } else {
      chrome.action.setBadgeText({ text: 'LIC' });
      chrome.action.setBadgeBackgroundColor({ color: '#2196F3' });
    }
  } else {
    const remaining = config.demo?.usesRemaining || 3;
    if (remaining > 0) {
      chrome.action.setBadgeText({ text: remaining.toString() });
      chrome.action.setBadgeBackgroundColor({ color: '#FF9800' });
    } else {
      chrome.action.setBadgeText({ text: 'EXP' });
      chrome.action.setBadgeBackgroundColor({ color: '#F44336' });
    }
  }
}
