/**
 * OCUS Unified Extension - Login Functions
 * 
 * Handles the auto-login functionality for the OCUS platform.
 * This implementation exactly matches the original OCUS Automation extension
 * for maximum reliability and compatibility.
 */

// Global variables for login
window.loginAttempts = 0;
window.maxLoginAttempts = 5;
window.isLoginPending = false; // Track when a login attempt is in progress
window.credentials = null;

// Load credentials from chrome storage - no hardcoded credentials
function loadCredentials() {
  return new Promise((resolve) => {
    try {
      console.log('Loading credentials for auto-login');
      // Try to get from Chrome storage
      chrome.storage.sync.get(['username', 'password'], function(result) {
        if (chrome.runtime.lastError) {
          console.error('Chrome storage error:', chrome.runtime.lastError);
          tryLocalStorage();
          return;
        }
        
        if (result && result.username && result.password) {
          console.log('Retrieved credentials from Chrome storage');
          window.credentials = result;
          resolve(window.credentials);
        } else {
          console.warn('No credentials in Chrome storage, trying localStorage');
          tryLocalStorage();
        }
      });
      
      function tryLocalStorage() {
        // Try to get from Chrome local storage (extension configuration)
        chrome.storage.local.get(['config'], function(result) {
          if (chrome.runtime.lastError) {
            console.error('Chrome storage local error:', chrome.runtime.lastError);
            tryFallbackStorage();
            return;
          }
          
          if (result && result.config && result.config.autoLogin) {
            const autoLogin = result.config.autoLogin;
            if (autoLogin.username && autoLogin.password) {
              console.log('Retrieved credentials from extension configuration');
              window.credentials = {
                username: autoLogin.username,
                password: autoLogin.password
              };
              resolve(window.credentials);
              return;
            }
          }
          
          console.warn('No credentials in extension config, trying localStorage');
          tryFallbackStorage();
        });
      }
      
      function tryFallbackStorage() {
        try {
          const localCreds = localStorage.getItem('ocusCredentials');
          if (localCreds) {
            const parsedCreds = JSON.parse(localCreds);
            if (parsedCreds && parsedCreds.username && parsedCreds.password) {
              console.log('Retrieved credentials from localStorage');
              window.credentials = parsedCreds;
              resolve(window.credentials);
              return;
            }
          }
          // Call the fallback function
          useFallbackCredentials();
        } catch (e) {
          console.error('LocalStorage error:', e);
          useFallbackCredentials();
        }
      }
      
      // Define the function to handle missing credentials
      function useFallbackCredentials() {
        console.warn('No credentials found - user must enter credentials in extension popup');
        window.credentials = {
          username: '',
          password: ''
        };
        
        resolve(window.credentials);
      }
      
      // Call the fallback function by default
      useFallbackCredentials();
    } catch (e) {
      console.error('Error in loadCredentials:', e);
      window.credentials = {username: '', password: ''};
      resolve(window.credentials);
    }
  });
}

// Determine if the current page is a login page
function isLoginPage() {
  const url = window.location.href.toLowerCase();
  
  // Only return true for the exact login page URL
  const isExactLoginPage = url === 'https://app.ocus.com/auth/login';
  
  // Check if URL contains /auth/login as fallback
  const isLoginPath = url.includes('/auth/login');
  
  // Only log once to reduce console spam
  if (!window.lastLoginCheck || Date.now() - window.lastLoginCheck > 5000) {
    console.log(`Login page check: URL=${isLoginPath}, ExactMatch=${isExactLoginPage}`);
    window.lastLoginCheck = Date.now();
  }
  
  // Only return true for the login page, not any page with a password field
  return isLoginPath;
}

// Check if user is on login page and attempt login
function checkAndAttemptLogin() {
  console.log('Checking if login is needed...');
  
  // If login is already pending, don't attempt again
  if (window.isLoginPending) {
    console.log('Login already pending, skipping check');
    return;
  }
  
  // Login check
  if (isLoginPage()) {
    console.log('On login page, attempting login...');
    
    // Make sure we have credentials first
    loadCredentials().then(creds => {
      if (creds && creds.username && creds.password) {
        window.isLoginPending = true;
        attemptLogin();
        // Reset login pending after a timeout
        setTimeout(() => {
          window.isLoginPending = false;
        }, 3000);
      } else {
        console.log('No credentials available for login - please set them in the options page');
        window.isLoginPending = false;
      }
    });
  } else {
    console.log('Not on login page, no login needed');
  }
}

// Attempt to log in with stored credentials
function attemptLogin() {
  // Add login attempt tracking for debug purposes
  console.log('Attempting login with direct method, attempt #', window.loginAttempts + 1);
  
  // Send login attempt message to background script for statistics
  chrome.runtime.sendMessage({ type: 'LOGIN_ATTEMPT' });
  
  // Load credentials from storage - users must enter their own
  if (!window.credentials) {
    console.log('No credentials found in storage - user must enter credentials in popup');
    return false;
  }
  
  // Check if we have valid credentials from storage
  if (!window.credentials || !window.credentials.username || !window.credentials.password) {
    console.log('No valid credentials available - user must enter credentials in extension popup');
    chrome.runtime.sendMessage({
      type: 'LOGIN_FAILED',
      reason: 'No credentials configured. Please enter your OCUS login credentials in the extension popup.'
    });
    return false;
  }
  
  const credentials = window.credentials;
  
  try {
    // Find login form elements with multiple selector fallbacks
    const emailSelectors = [
      'input[name="email"][id="input-43"][type="text"]',
      'input[name="email"]',
      'input[type="email"]',
      '#input-43'
    ];
    
    const passwordSelectors = [
      'input[name="password"][id="input-47"][type="password"]',
      'input[name="password"]',
      'input[type="password"]',
      '#input-47'
    ];
    
    const buttonSelectors = [
      'button[type="submit"]',
      'button.v-btn',
      'button.white--text',
      'button.uppercase',
      'button.v-btn--rounded'
    ];
    
    // Find elements
    let emailField = null;
    for (const selector of emailSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        emailField = el;
        break;
      }
    }
    
    let passwordField = null;
    for (const selector of passwordSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        passwordField = el;
        break;
      }
    }
    
    let loginButton = null;
    for (const selector of buttonSelectors) {
      const el = document.querySelector(selector);
      if (el) {
        loginButton = el;
        break;
      }
    }
    
    if (emailField && passwordField) {
      console.log('Login form found, attempting login...');
      
      // Fill credentials
      emailField.value = credentials.username;
      
      // Trigger events for reactivity in Vue.js forms
      ['input', 'change', 'blur', 'focus', 'keyup', 'keydown', 'keypress'].forEach(eventType => {
        emailField.dispatchEvent(new Event(eventType, { bubbles: true }));
      });
      
      // Force Vue data binding with a fake input event
      const inputEvent = new InputEvent('input', { bubbles: true, composed: true });
      emailField.dispatchEvent(inputEvent);
      
      // Give the framework time to process the first field
      setTimeout(() => {
        passwordField.value = credentials.password;
        
        // Trigger events for reactivity in Vue.js forms
        ['input', 'change', 'blur', 'focus', 'keyup', 'keydown', 'keypress'].forEach(eventType => {
          passwordField.dispatchEvent(new Event(eventType, { bubbles: true }));
        });
        
        // Force Vue data binding with a fake input event
        passwordField.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true }));
        
        // Dispatch a form validation event to trigger Vue.js form validation
        const form = emailField.closest('form');
        if (form) {
          form.dispatchEvent(new Event('validate', { bubbles: true }));
        }
      }, 100);
      
      // Enable button if it's disabled
      if (loginButton) {
        // Wait to ensure form validation has happened
        setTimeout(() => {
          if (loginButton.disabled || loginButton.hasAttribute('disabled') || 
              loginButton.classList.contains('v-btn--disabled')) {
            console.log('Login button is disabled, attempting to enable it');
            
            // Try all possible ways to enable the button in Vue.js
            loginButton.removeAttribute('disabled');
            loginButton.classList.remove('v-btn--disabled');
            loginButton.disabled = false;
            
            // Remove all Vue-specific disabled classes
            const disabledClasses = ['v-btn--disabled', 'disabled', 'v-disable'];
            disabledClasses.forEach(className => {
              if (loginButton.classList.contains(className)) {
                loginButton.classList.remove(className);
              }
            });
            
            // Sometimes Vue uses a data attribute for disabled state
            if (loginButton.dataset.disabled) {
              delete loginButton.dataset.disabled;
            }
            
            // Try to access Vue component instance via __vue__ property (dev mode)
            if (loginButton.__vue__) {
              try {
                loginButton.__vue__.disabled = false;
              } catch (e) {
                console.log('Could not modify Vue component directly');
              }
            }
            
            console.log('Button enabled state: disabled:', loginButton.disabled, 'has attribute:', loginButton.hasAttribute('disabled'));
          }
        }, 200); // Close the button enable setTimeout
        
        // Give the form a moment to validate
        setTimeout(() => {
          // Try direct click first
          loginButton.click();
          console.log('Login button clicked');
          
          // Try programmatic click
          setTimeout(() => {
            // If still on login page, try alternative click methods
            if (window.location.href.includes('/auth/login')) {
              console.log('First click method failed, trying alternatives...');
              
              // Try MouseEvent click
              const clickEvent = new MouseEvent('click', {
                bubbles: true,
                cancelable: true,
                view: window
              });
              loginButton.dispatchEvent(clickEvent);
              
              // Try form submit as last resort
              setTimeout(() => {
                if (window.location.href.includes('/auth/login')) {
                  const form = emailField.closest('form');
                  if (form) {
                    console.log('Attempting form submit as final fallback');
                    try {
                      // First try normal submit
                      // Prevent actual form submission to avoid refresh
                      console.log('%c 🚫 FORM SUBMISSION PREVENTED - AVOIDING REFRESH', 'background:#e74c3c; color:white; font-weight:bold; padding:5px;');
                      
                      // Trigger submit event without actual submission
                      const submitEvent = new Event('submit', {bubbles: true, cancelable: true});
                      form.dispatchEvent(submitEvent);
                    } catch (e) {
                      console.error('Form submit error:', e);
                      // If that fails, try submit event
                      try {
                        form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
                      } catch (e2) {
                        console.error('Form submit event error:', e2);
                      }
                    }
                  }
                }
              }, 1000);
            }
          }, 500);
        }, 750);
      } else {
        console.log('Login button not found, trying form submit');
        const form = emailField.closest('form');
        if (form) {
          // Prevent actual form submission to avoid refresh
          console.log('%c 🚫 FORM SUBMISSION PREVENTED - AVOIDING REFRESH', 'background:#e74c3c; color:white; font-weight:bold; padding:5px;');
          
          // Trigger submit event without actual submission
          const submitEvent = new Event('submit', {bubbles: true, cancelable: true});
          form.dispatchEvent(submitEvent);
        } else {
          console.log('Form not found either, login may fail');
        }
      }
      
      // Update login attempts counter
      loginAttempts++;
      
      if (loginAttempts >= maxLoginAttempts) {
        console.log('Max login attempts reached, stopping automation');
      }
    } else {
      console.log('Login form elements not found');
      console.log('Email selectors tried:', emailSelectors);
      console.log('Password selectors tried:', passwordSelectors);
    }
  } catch (error) {
    console.error('Error during login:', error);
    console.log('Login error: ' + error.message);
  }
}

// Add debug hooks to window for troubleshooting
window.ocusDebug = {
  forceLogin: function() {
    console.log('Manually forcing login attempt');
    attemptLogin();
    return 'Login attempt initiated';
  },
  checkLoginPage: function() {
    const result = isLoginPage();
    console.log('Is login page:', result);
    return result;
  },
  resetLoginAttempts: function() {
    window.loginAttempts = 0;
    console.log('Login attempts reset to 0');
    return 'Reset complete';
  }
};

// Function to find a button by its text content
function findButtonByText(text) {
  const possibleButtons = Array.from(document.querySelectorAll('.btn, .v-btn, .button, [role="button"]'));
  for (const button of possibleButtons) {
    const buttonText = button.textContent || button.value || button.innerText || '';
    if (buttonText.trim().toLowerCase().includes(text.toLowerCase())) {
      console.log('Found possible button with text:', buttonText);
      return button;
    }
  }
  
  console.log('Button with text not found:', text);
  return null;
}

// Check for login when script loads (will only run if we're on OCUS domain due to manifest match patterns)
setTimeout(checkAndAttemptLogin, 1000);
// Run another check after a longer delay to catch slow-loading pages
setTimeout(checkAndAttemptLogin, 3000);
// Add more checks with increasing delays for pages that load very slowly
setTimeout(checkAndAttemptLogin, 5000);
setTimeout(checkAndAttemptLogin, 8000);

// Only set up login checks if we're currently on a login page
if (isLoginPage()) {
  console.log('Login page detected - activating automatic login checks');
  // Add an interval to periodically check for login - ONLY on login pages
  window.loginCheckInterval = setInterval(function() {
    if (isLoginPage() && !window.isLoginPending && window.loginAttempts < window.maxLoginAttempts) {
      console.log('Periodic login check - on login page');
      checkAndAttemptLogin();
    } else if (!isLoginPage() && window.loginCheckInterval) {
      // If we navigate away from login page, clear the interval
      console.log('No longer on login page - stopping login checks');
      clearInterval(window.loginCheckInterval);
      window.loginCheckInterval = null;
    }
  }, 10000);
} else {
  console.log('Not on login page - login functionality inactive');
}

// Listen for messages from background script and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CHECK_LOGIN') {
    console.log('Received login check request from background script');
    checkAndAttemptLogin();
    sendResponse({status: 'Login check initiated'});
    return true; // Keep the message channel open for the async response
  } else if (message.type === 'UPDATE_CONFIG') {
    console.log('Received configuration update from popup');
    // Update credentials from configuration
    if (message.config && message.config.autoLogin) {
      window.credentials = {
        username: message.config.autoLogin.username || '',
        password: message.config.autoLogin.password || ''
      };
      
      // Also save to Chrome storage sync for persistence
      if (window.credentials.username && window.credentials.password) {
        chrome.storage.sync.set({
          username: window.credentials.username,
          password: window.credentials.password
        }, function() {
          console.log('User credentials saved to Chrome storage');
        });
      }
      
      console.log('Credentials updated from configuration:', {
        username: window.credentials.username ? '***' : '(empty)',
        password: window.credentials.password ? '***' : '(empty)'
      });
      
      // If on login page and have new credentials, attempt login
      if (isLoginPage() && window.credentials.username && window.credentials.password) {
        console.log('New credentials received on login page - attempting login');
        setTimeout(checkAndAttemptLogin, 1000);
      }
    }
    sendResponse({status: 'Configuration updated'});
    return true;
  }
});

// Set up a mutation observer to detect login form insertions
const observer = new MutationObserver(() => {
  if (!window.isLoginPending && isLoginPage()) {
    checkAndAttemptLogin();
  }
});

// Start observing the document with the configured parameters
observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});

// Add a periodic check for login page (some OCUS pages load login forms dynamically)
setInterval(() => {
  if (!window.isLoginPending) {
    checkAndAttemptLogin();
  }
}, 5000);

// Debug helpers
console.log('OCUS Login Functions loaded successfully');
