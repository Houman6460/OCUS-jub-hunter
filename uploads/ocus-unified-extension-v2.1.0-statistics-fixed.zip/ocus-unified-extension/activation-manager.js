/**
 * OCUS Unified Extension - Activation Manager
 * 
 * Manages license activation and demo usage tracking
 */

class ActivationManager {
  constructor() {
    this.config = window.EXTENSION_CONFIG || {};
    this.userId = null;
    this.isActivated = false;
    this.demoUsesRemaining = 3;
    this.initialized = false;
  }

  /**
   * Initialize the activation manager
   */
  async initialize() {
    if (this.initialized) return;

    try {
      // Get or create user ID
      this.userId = await this.getOrCreateUserId();
      
      // Check activation status
      await this.checkActivationStatus();
      
      // If not activated, check demo status
      if (!this.isActivated) {
        await this.checkDemoStatus();
      }
      
      this.initialized = true;
      console.log('Activation Manager initialized:', {
        userId: this.userId,
        isActivated: this.isActivated,
        demoUsesRemaining: this.demoUsesRemaining
      });
    } catch (error) {
      console.error('Failed to initialize activation manager:', error);
      // Continue with demo mode as fallback
      this.demoUsesRemaining = 3;
    }
  }

  /**
   * Get or create a unique user ID
   */
  async getOrCreateUserId() {
    return new Promise((resolve) => {
      chrome.storage.local.get([this.config.USER_ID?.STORAGE_KEY || 'extension_user_id'], (result) => {
        const storageKey = this.config.USER_ID?.STORAGE_KEY || 'extension_user_id';
        let userId = result[storageKey];
        
        if (!userId) {
          // Generate UUID-like ID
          userId = this.generateUUID();
          chrome.storage.local.set({ [storageKey]: userId });
        }
        
        resolve(userId);
      });
    });
  }

  /**
   * Generate a UUID-like identifier
   */
  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  /**
   * Check activation status from stored key
   */
  async checkActivationStatus() {
    return new Promise((resolve) => {
      const storageKey = this.config.ACTIVATION?.STORAGE_KEY || 'activation_key_data';
      chrome.storage.local.get([storageKey], async (result) => {
        const activationData = result[storageKey];
        
        if (activationData && activationData.key) {
          try {
            const isValid = await this.validateActivationKey(activationData.key);
            this.isActivated = isValid;
            
            if (!isValid) {
              // Remove invalid key
              chrome.storage.local.remove([storageKey]);
            }
          } catch (error) {
            console.warn('Could not validate activation key:', error);
            this.isActivated = false;
          }
        }
        
        resolve(this.isActivated);
      });
    });
  }

  /**
   * Validate activation key with server
   */
  async validateActivationKey(activationKey) {
    const apiUrl = (this.config.API?.BASE_URL || '') + (this.config.API?.ENDPOINTS?.ACTIVATE || '/activate');
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.API?.TIMEOUT || 5000);

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ activation_key: activationKey }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.status === 'valid';
    } catch (error) {
      console.warn('Activation validation failed:', error);
      // Return false but don't throw - allow extension to continue in demo mode
      return false;
    }
  }

  /**
   * Check demo usage status
   */
  async checkDemoStatus() {
    if (this.isActivated) {
      this.demoUsesRemaining = -1; // Unlimited when activated
      return;
    }

    const apiUrl = (this.config.API?.BASE_URL || '') + (this.config.API?.ENDPOINTS?.CHECK_DEMO || '/check-demo');
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), this.config.API?.TIMEOUT || 5000);

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_id: this.userId }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      
      if (result.status === 'demo_limit_reached') {
        this.demoUsesRemaining = 0;
      } else if (result.status === 'demo_allowed') {
        this.demoUsesRemaining = result.remaining || 0;
      }
    } catch (error) {
      console.warn('Demo status check failed:', error);
      // Fallback to local storage check
      this.checkLocalDemoStatus();
    }
  }

  /**
   * Fallback demo status check using local storage
   */
  checkLocalDemoStatus() {
    const storageKey = this.config.DEMO?.STORAGE_KEY || 'demo_usage_data';
    chrome.storage.local.get([storageKey], (result) => {
      const demoData = result[storageKey] || { used: 0, maxUses: 3 };
      this.demoUsesRemaining = Math.max(0, demoData.maxUses - demoData.used);
    });
  }

  /**
   * Check if extension can be used (either activated or demo uses remaining)
   */
  canUseExtension() {
    return this.isActivated || this.demoUsesRemaining > 0;
  }

  /**
   * Use one demo attempt
   */
  async useDemoAttempt() {
    if (this.isActivated) return true; // No limit when activated

    if (this.demoUsesRemaining <= 0) {
      return false; // No demo uses left
    }

    // Decrement local counter immediately
    this.demoUsesRemaining--;

    // Try to sync with server (non-blocking)
    this.syncDemoUsageWithServer().catch(error => {
      console.warn('Failed to sync demo usage with server:', error);
    });

    // Update local storage as backup
    this.updateLocalDemoCount();

    return true;
  }

  /**
   * Sync demo usage with server
   */
  async syncDemoUsageWithServer() {
    const apiUrl = (this.config.API?.BASE_URL || '') + (this.config.API?.ENDPOINTS?.CHECK_DEMO || '/check-demo');
    
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ user_id: this.userId })
      });

      if (response.ok) {
        const result = await response.json();
        if (result.remaining !== undefined) {
          this.demoUsesRemaining = result.remaining;
        }
      }
    } catch (error) {
      console.warn('Server sync failed:', error);
    }
  }

  /**
   * Update local demo usage count
   */
  updateLocalDemoCount() {
    const storageKey = this.config.DEMO?.STORAGE_KEY || 'demo_usage_data';
    const used = (this.config.DEMO?.MAX_USES || 3) - this.demoUsesRemaining;
    
    chrome.storage.local.set({
      [storageKey]: {
        used: used,
        maxUses: this.config.DEMO?.MAX_USES || 3,
        lastUsed: new Date().toISOString()
      }
    });
  }

  /**
   * Activate extension with provided key
   */
  async activateExtension(activationKey) {
    if (!activationKey || typeof activationKey !== 'string') {
      throw new Error('Invalid activation key');
    }

    const isValid = await this.validateActivationKey(activationKey);
    
    if (isValid) {
      // Store activation key
      const storageKey = this.config.ACTIVATION?.STORAGE_KEY || 'activation_key_data';
      chrome.storage.local.set({
        [storageKey]: {
          key: activationKey,
          activatedAt: new Date().toISOString()
        }
      });
      
      this.isActivated = true;
      this.demoUsesRemaining = -1; // Unlimited
      
      return true;
    } else {
      throw new Error('Invalid activation key');
    }
  }

  /**
   * Get current status for UI display
   */
  getStatus() {
    return {
      isActivated: this.isActivated,
      canUse: this.canUseExtension(),
      demoUsesRemaining: this.isActivated ? -1 : this.demoUsesRemaining,
      userId: this.userId
    };
  }

  /**
   * Show activation required UI
   */
  showActivationUI() {
    // This will be implemented in the UI scripts
    console.log('Activation required - please enter your activation key');
    
    // Send message to popup or content script to show activation UI
    try {
      chrome.runtime.sendMessage({
        type: 'SHOW_ACTIVATION_UI',
        status: this.getStatus()
      });
    } catch (error) {
      console.warn('Could not send activation UI message:', error);
    }
  }
}

// Make ActivationManager available globally
if (typeof window !== 'undefined') {
  window.ActivationManager = ActivationManager;
}