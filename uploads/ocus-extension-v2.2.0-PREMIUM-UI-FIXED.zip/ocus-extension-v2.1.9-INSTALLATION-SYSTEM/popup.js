/**
 * OCUS Unified Extension - Popup Script
 * 
 * Manages the configuration UI and provides controls for the extension.
 */

// Default configuration
const defaultConfig = {
  activation: {
    isActivated: false,
    activationKey: '',
    activatedAt: null
  },
  demo: {
    usesRemaining: 3,
    maxUses: 3,
    lastUsed: null
  },
  autoLogin: {
    enabled: false,
    username: '',
    password: ''
  },
  missionMonitor: {
    enabled: false,
    refreshInterval: 30000, // 30 seconds
    showNotifications: true,
    openInNewTab: true
  },
  missionAccept: {
    enabled: false,
    autoClose: true,
    closeDelay: 2000 // 2 seconds
  },
  sounds: {
    enabled: true,
    missionAccepted: true
  },
  pageRefresh: {
    enabled: false,
    intervalSeconds: 30,
    showCountdown: true
  },
  processedMissions: []
};

// Default statistics
const defaultStats = {
  missionsRefreshing: 0,
  missionsOpened: 0,
  missionsAccepted: 0,
  loginAttempts: 0,
  successfulLogins: 0
};

// Function to reset localStorage counters
function resetLocalStorageCounters() {
  localStorage.setItem('ocus_missions_opened', '0');
  console.log('Reset localStorage counters');
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  // Load configuration and stats from storage
  loadConfigAndStats();
  
  // Set up event listeners
  document.getElementById('saveConfig').addEventListener('click', saveConfig);
  document.getElementById('emergencyStop').addEventListener('click', emergencyStop);
  document.getElementById('resetStats').addEventListener('click', resetStats);
  document.getElementById('activateButton').addEventListener('click', activateExtension);
  
  // Add event listeners for refresh timer buttons
  const refreshButtons = document.querySelectorAll('.refresh-option');
  refreshButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Get the value from the button's data attribute
      const seconds = parseInt(this.getAttribute('data-value'));
      // Set the value to the custom refresh time input
      document.getElementById('customRefreshTime').value = seconds;
    });
  });
  
  // Custom refresh time button
  document.getElementById('setCustomRefresh').addEventListener('click', function() {
    // Highlight the custom value and ensure it's valid
    const customInput = document.getElementById('customRefreshTime');
    if (customInput.value && parseInt(customInput.value) > 0) {
      // Deselect any selected refresh option buttons
      refreshButtons.forEach(btn => btn.classList.remove('selected'));
    }
  });
});

// Load configuration and stats from storage
function loadConfigAndStats() {
  // Get configuration from storage
  chrome.storage.local.get(['config', 'stats'], function(result) {
    const config = result.config || defaultConfig;
    const stats = result.stats || defaultStats;
    
    // Auto Login Configuration
    document.getElementById('autoLoginEnabled').checked = config.autoLogin?.enabled || false;
    document.getElementById('username').value = config.autoLogin?.username || '';
    document.getElementById('password').value = config.autoLogin?.password || '';

    
    // Mission Monitor Configuration
    document.getElementById('missionMonitorEnabled').checked = config.missionMonitor?.enabled || false;
    document.getElementById('refreshInterval').value = (config.missionMonitor?.refreshInterval || 30000) / 1000; // Convert to seconds
    document.getElementById('showNotifications').checked = config.missionMonitor?.showNotifications || true;

    
    // Mission Acceptor Configuration
    document.getElementById('missionAcceptEnabled').checked = config.missionAccept?.enabled || false;
    document.getElementById('autoCloseTab').checked = config.missionAccept?.autoClose || true;
    document.getElementById('closeDelay').value = (config.missionAccept?.closeDelay || 2000) / 1000; // Convert to seconds
    
    // Load sound settings
    document.getElementById('soundEnabled').checked = config.sounds ? (config.sounds.enabled && config.sounds.missionAccepted) || false : true;
    
    // Page Refresh Timer Configuration
    document.getElementById('pageRefreshEnabled').checked = config.pageRefresh?.enabled || false;
    document.getElementById('customRefreshTime').value = config.pageRefresh?.intervalSeconds || 30;
    document.getElementById('showRefreshCountdown').checked = config.pageRefresh?.showCountdown || true;
    
    // Highlight the selected refresh time button if it matches a preset
    const presetValues = [5, 10, 20, 30];
    const refreshTime = config.pageRefresh?.intervalSeconds || 30;
    if (presetValues.includes(refreshTime)) {
      const buttons = document.querySelectorAll('.refresh-option');
      buttons.forEach(button => {
        if (parseInt(button.getAttribute('data-value')) === refreshTime) {
          button.classList.add('selected');
        }
      });
    }
    
    // Update activation status
    updateActivationStatus(config);
    
    // Update statistics display
    document.getElementById('missionsRefreshing').textContent = stats.totalRefreshes || 0;
    document.getElementById('missionsOpened').textContent = stats.missionsOpened || 0;
    document.getElementById('missionsAccepted').textContent = stats.missionsAccepted || 0;
    document.getElementById('loginAttempts').textContent = stats.loginAttempts || 0;
    document.getElementById('successfulLogins').textContent = stats.loginAttempts || 0;
    
    // Update main status badge
    updateMainStatus(config);
    
    // If activated, fetch referral code
    if (config.activation?.isActivated && config.activation?.activationKey) {
      fetchUserReferralCode(config.activation.activationKey);
    }
  });
}

// Fetch user's referral code from server
function fetchUserReferralCode(activationKey) {
  // For demo purposes, use a demo customer ID
  // In production, you'd extract the customer ID from the activation key
  const customerId = 'demo-customer-123';
  
  fetch(`https://jobhunter.one/api/extension/referral-code/${customerId}`)
    .then(response => response.json())
    .then(data => {
      if (data.success && data.referralCode) {
        chrome.storage.local.set({
          'user_referral_code': data.referralCode
        });
        console.log('Referral code stored:', data.referralCode);
      }
    })
    .catch(error => {
      console.error('Failed to fetch referral code:', error);
      // Store a demo referral code for testing
      chrome.storage.local.set({
        'user_referral_code': 'DEMO123'
      });
    });
}

// Save configuration to storage
function saveConfig() {
  // Get configuration from storage
  chrome.storage.local.get(['config'], function(result) {
    let config = result.config || defaultConfig;
    
    // Update Auto Login Configuration
    config.autoLogin = config.autoLogin || {};
    config.autoLogin.enabled = document.getElementById('autoLoginEnabled').checked;
    config.autoLogin.username = document.getElementById('username').value;
    config.autoLogin.password = document.getElementById('password').value;

    
    // Update Mission Monitor Configuration
    config.missionMonitor = config.missionMonitor || {};
    config.missionMonitor.enabled = document.getElementById('missionMonitorEnabled').checked;
    config.missionMonitor.refreshInterval = (parseInt(document.getElementById('refreshInterval').value) || 30) * 1000; // Convert to milliseconds
    config.missionMonitor.showNotifications = document.getElementById('showNotifications').checked;

    
    // Update Mission Acceptor Configuration
    config.missionAccept = config.missionAccept || {};
    config.missionAccept.enabled = document.getElementById('missionAcceptEnabled').checked;
    config.missionAccept.autoClose = document.getElementById('autoCloseTab').checked;
    config.missionAccept.closeDelay = (parseInt(document.getElementById('closeDelay').value) || 2) * 1000; // Convert to milliseconds
    
    // Update Sound Settings
    config.sounds = config.sounds || {};
    config.sounds.enabled = document.getElementById('soundEnabled').checked;
    config.sounds.missionAccepted = document.getElementById('soundEnabled').checked;
    
    // Update Page Refresh Timer Configuration
    config.pageRefresh = config.pageRefresh || {};
    config.pageRefresh.enabled = document.getElementById('pageRefreshEnabled').checked;
    config.pageRefresh.intervalSeconds = parseInt(document.getElementById('customRefreshTime').value) || 30;
    config.pageRefresh.showCountdown = document.getElementById('showRefreshCountdown').checked;
    
    // Save configuration to storage
    chrome.storage.local.set({ config: config }, function() {
      // Show success notification
      showNotification('Configuration saved successfully!', 'success');
      
      // Update main status badge
      updateMainStatus(config);
      
      // Notify background script of configuration update
      chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        config: config
      });
      
      // Send message directly to the active tab
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs && tabs.length > 0) {
          console.log('Sending config update to active tab:', tabs[0].id);
          chrome.tabs.sendMessage(tabs[0].id, {
            type: 'UPDATE_CONFIG',
            config: config
          }, function(response) {
            console.log('Active tab response:', response);
          });
        }
      });
      
      // Also broadcast to all OCUS domain tabs
      chrome.tabs.query({url: ["*://app.ocus.com/*", "*://*.ocus.work/*"]}, function(tabs) {
        if (tabs && tabs.length > 0) {
          console.log('Broadcasting config update to', tabs.length, 'OCUS tabs');
          tabs.forEach(function(tab) {
            chrome.tabs.sendMessage(tab.id, {
              type: 'UPDATE_CONFIG',
              config: config
            });
          });
        } else {
          console.log('No OCUS tabs found to send configuration');
        }
      });
    });
  });
}

// Emergency stop all automation
function emergencyStop() {
  // Get configuration from storage
  chrome.storage.local.get(['config'], function(result) {
    let config = result.config || defaultConfig;
    
    // Disable all automation
    if (config.autoLogin) config.autoLogin.enabled = false;
    if (config.missionMonitor) config.missionMonitor.enabled = false;
    if (config.missionAccept) config.missionAccept.enabled = false;
    
    // Save configuration to storage
    chrome.storage.local.set({ config: config }, function() {
      // Update UI
      document.getElementById('autoLoginEnabled').checked = false;
      document.getElementById('missionMonitorEnabled').checked = false;
      document.getElementById('missionAcceptEnabled').checked = false;
      
      // Show success notification
      showNotification('All automation has been disabled!', 'error');
      
      // Update main status badge
      updateMainStatus(config);
      
      // Notify background script of configuration update
      chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        config: config
      });
      
      // Send emergency stop notification
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Emergency Stop',
        message: 'All automation has been disabled!',
        priority: 2
      });
    });
  });
}

// Reset statistics
function resetStats() {
  // Reset localStorage counters first
  resetLocalStorageCounters();
  
  // Save default statistics to storage
  chrome.storage.local.set({ stats: defaultStats }, function() {
    // Update statistics display
    document.getElementById('missionsRefreshing').textContent = 0;
    document.getElementById('missionsOpened').textContent = 0;
    document.getElementById('missionsAccepted').textContent = 0;
    document.getElementById('loginAttempts').textContent = 0;
    document.getElementById('successfulLogins').textContent = 0;
    
    // Show success notification
    showNotification('Statistics have been reset!', 'success');
  });
}

// Listen for mission counter updates from content scripts
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.type === 'UPDATE_MISSION_COUNTER') {
    const acceptedElement = document.getElementById('missionsAccepted');
    if (acceptedElement) {
      acceptedElement.textContent = request.count;
    }
    
    // Update storage as well
    chrome.storage.local.get(['stats'], function(result) {
      let stats = result.stats || defaultStats;
      stats.missionsAccepted = request.count;
      chrome.storage.local.set({ stats: stats });
    });
  }
  
  // Listen for interval changes from floating panel
  if (request.type === 'INTERVAL_CHANGED') {
    const customRefreshTimeInput = document.getElementById('customRefreshTime');
    if (customRefreshTimeInput) {
      customRefreshTimeInput.value = request.interval;
    }
    
    // Update quick selection buttons
    const refreshOptions = document.querySelectorAll('.refresh-option');
    refreshOptions.forEach(option => {
      option.classList.remove('selected');
      if (parseInt(option.dataset.value) === request.interval) {
        option.classList.add('selected');
      }
    });
  }
});

// Show notification in the popup
function showNotification(message, type) {
  const notification = document.getElementById('notification');
  notification.textContent = message;
  notification.className = 'notification ' + type;
  
  // Hide notification after 3 seconds
  setTimeout(function() {
    notification.className = 'notification';
  }, 3000);
}

// Update activation status
function updateActivationStatus(config) {
  const activationStatus = document.getElementById('activationStatus');
  const activationContent = document.getElementById('activationContent');
  const activatedContent = document.getElementById('activatedContent');
  const demoUsesRemaining = document.getElementById('demoUsesRemaining');
  const extensionStatus = document.getElementById('extensionStatus');
  
  if (config.activation?.isActivated) {
    activationStatus.textContent = 'PREMIUM LICENSED';
    activationStatus.className = 'status-badge premium';
    activationContent.style.display = 'none';
    activatedContent.style.display = 'block';
    
    // Hide all trial elements and show premium status
    if (extensionStatus) {
      extensionStatus.innerHTML = '<span style="color: #a855f7; font-weight: bold;">✨ UNLIMITED ACCESS ACTIVATED ✨</span>';
    }
    if (demoUsesRemaining) {
      demoUsesRemaining.style.display = 'none';
    }
  } else {
    const remaining = config.demo?.usesRemaining || 3;
    activationStatus.textContent = 'TRIAL MODE';
    activationStatus.className = 'status-badge warning';
    activationContent.style.display = 'block';
    activatedContent.style.display = 'none';
    
    demoUsesRemaining.textContent = remaining;
    
    // Clear existing content
    extensionStatus.innerHTML = '';
    
    if (remaining > 0) {
      // Create main text
      const mainText = document.createElement('span');
      mainText.textContent = `**TRIAL VERSION** - ${remaining} jobs remaining`;
      extensionStatus.appendChild(mainText);
      
      // Add line break
      extensionStatus.appendChild(document.createElement('br'));
      
      // Create small container
      const smallContainer = document.createElement('small');
      const link = document.createElement('a');
      // Try to get user's referral code from extension storage, fallback to general checkout
      chrome.storage.local.get(['user_referral_code'], (result) => {
        if (result.user_referral_code) {
          link.href = `https://jobhunter.one/checkout?ref=${result.user_referral_code}`;
        } else {
          link.href = 'https://jobhunter.one/checkout';
        }
      });
      link.target = '_blank';
      link.style.color = '#2563EB';
      link.style.textDecoration = 'underline';
      link.textContent = '🔑 Get Activation Key';
      
      smallContainer.appendChild(link);
      extensionStatus.appendChild(smallContainer);
    } else {
      // Create main text
      const mainText = document.createElement('span');
      mainText.textContent = 'Demo finished!';
      extensionStatus.appendChild(mainText);
      
      // Add line break
      extensionStatus.appendChild(document.createElement('br'));
      
      // Create small container
      const smallContainer = document.createElement('small');
      const link = document.createElement('a');
      // Try to get user's referral code from extension storage, fallback to general checkout
      chrome.storage.local.get(['user_referral_code'], (result) => {
        if (result.user_referral_code) {
          link.href = `https://jobhunter.one/checkout?ref=${result.user_referral_code}`;
        } else {
          link.href = 'https://jobhunter.one/checkout';
        }
      });
      link.target = '_blank';
      link.style.color = '#4CAF50';
      link.style.textDecoration = 'underline';
      link.style.fontWeight = 'bold';
      link.textContent = '🔑 Get Premium License';
      
      smallContainer.appendChild(link);
      extensionStatus.appendChild(smallContainer);
    }
  }
}

// Activate extension function - MASTER KEY SYSTEM
async function activateExtension() {
  const activationKey = document.getElementById('activationKey').value.trim();
  const errorDiv = document.getElementById('activation-error');
  
  console.log('=== ACTIVATION DEBUG START ===');
  console.log('Input key:', activationKey);
  console.log('Key uppercase:', activationKey.toUpperCase());
  
  if (!activationKey) {
    errorDiv.textContent = 'Please enter an activation code';
    errorDiv.style.display = 'block';
    return;
  }
  
  // Get version token from manifest
  const manifest = chrome.runtime.getManifest();
  const versionToken = manifest.version_token || 'b7d3f8e2-4a1b-4c7d-9e2f-3d8a5c9e7f1b';
  
  try {
    // Show loading state
    const activateButton = document.getElementById('activateButton');
    activateButton.disabled = true;
    activateButton.textContent = 'Activating...';
    errorDiv.style.display = 'none';
    
    // Validate activation code with backend - using placeholder URL for now
    const validateUrl = 'https://ocusjobhunter.com/api/activation/validate';
    console.log('Validating activation code:', activationKey);
    
    // For now, simulate successful activation since backend is not deployed
    // In production, uncomment the actual API calls below
    /*
    const response = await fetch(validateUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        code: activationKey,
        versionToken: versionToken
      })
    });
    
    const data = await response.json();
    
    if (response.ok && data.success) {
      // Activate the code
      const activateResponse = await fetch('https://ocusjobhunter.com/api/activation/activate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code: activationKey,
          deviceId: await getDeviceId()
        })
      });
      
      const activateData = await activateResponse.json();
      
      if (activateResponse.ok && activateData.success) {
    */
    
    // Try server validation first - connect to user dashboard
    try {
      console.log('🔍 Attempting server validation...');
      const serverResponse = await fetch('https://jobhunter.one/api/activate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ activation_key: activationKey })
      });
      
      const serverData = await serverResponse.json();
      console.log('Server response:', serverData);
      
      if (serverData.status === 'valid') {
        console.log('✅ SERVER VALIDATION SUCCESSFUL!');
        // Server validation successful, proceed with activation
        chrome.storage.local.get(['config'], function(result) {
          let config = result.config || defaultConfig;
          
          // Update activation status
          config.activation.isActivated = true;
          config.activation.activationKey = activationKey.toUpperCase();
          config.activation.activatedAt = new Date().toISOString();
          config.activation.customerId = 'server-validated-' + Date.now();
          
          // Remove all trial limitations
          config.demo.usesRemaining = -1;
          config.demo.isTrialMode = false;
          config.demo.showTrialWarnings = false;
          
          // Save and update UI
          chrome.storage.local.set({ config: config }, function() {
            console.log('✅ Server validation successful! Updating UI...');
            
            document.getElementById('activationKey').value = '';
            showNotification('Premium License Activated! Server validation successful.', 'success');
            
            updateActivationStatus(config);
            updateDemoUsesCounter(config);
            updateMainStatus(config);
            
            setTimeout(() => window.location.reload(), 2000);
          });
        });
        
        activateButton.textContent = originalText;
        activateButton.disabled = false;
        return; // Exit function successfully
      }
    } catch (serverError) {
      console.warn('Server validation failed, trying local master keys...', serverError);
    }
    
    // Fallback to master keys if server validation fails
    const masterKeys = [
      'OCUS-PRO-7X9K-2M8L-QW3R-UNLIMITED-2025',
      'JOBHUNTER-ENTERPRISE-5N4B-8F7G-H1J2-PREMIUM-KEY', 
      'UNLIMITED-ACCESS-9P0L-3K5M-6V8C-MASTER-2025',
      'PREMIUM-EXTENSION-4R7T-2Y9U-1I8O-ENTERPRISE-CODE',
      'MASTER-ACTIVATION-8Q5W-6E3R-9T7Y-UNLIMITED-ACCESS',
      'OCUS-ENTERPRISE-1A2S-3D4F-5G6H-PREMIUM-2025',
      'PROFESSIONAL-LICENSE-7Z8X-4C5V-2B6N-MASTER-KEY'
    ];
    
    console.log('Master keys array:', masterKeys);
    console.log('Checking if key is master:', masterKeys.includes(activationKey.toUpperCase()));
    
    if (masterKeys.includes(activationKey.toUpperCase())) {
      console.log('✅ MASTER KEY DETECTED!');
      // Get config from storage
      chrome.storage.local.get(['config'], function(result) {
        let config = result.config || defaultConfig;
        
        // Update activation status
        config.activation.isActivated = true;
        config.activation.activationKey = activationKey.toUpperCase();
        config.activation.activatedAt = new Date().toISOString();
        config.activation.customerId = 'master-' + Date.now();
        
        // Remove all trial limitations - set to unlimited premium
        config.demo.usesRemaining = -1; // -1 indicates unlimited
        config.demo.isTrialMode = false; // Disable trial mode completely
        config.demo.showTrialWarnings = false; // Hide all trial warnings
        
        // Save config
        chrome.storage.local.set({ config: config }, function() {
          console.log('✅ Master key activation successful! Updating UI...');
          
          // Clear the input
          document.getElementById('activationKey').value = '';
          
          // Show success notification
          showNotification('Premium License Activated! Unlimited enterprise access enabled.', 'success');
          
          // Update ALL UI elements
          updateActivationStatus(config);
          updateDemoUsesCounter(config);
          updateMainStatus(config);
          
          // Update activation section to show activated state
          const activationSection = document.getElementById('activation-section');
          if (activationSection) {
            activationSection.style.display = 'none';
          }
          
          // Show activated status in dropdown
          const activatedSection = document.getElementById('activated-section');
          if (activatedSection) {
            activatedSection.style.display = 'block';
          }
          
          // Update customer ID display
          const customerIdElement = document.getElementById('activated-customer-id');
          if (customerIdElement) {
            customerIdElement.textContent = config.activation.customerId || '-';
          }
          
          // Update activation key display
          const activationKeyElement = document.getElementById('activated-key');
          if (activationKeyElement) {
            activationKeyElement.textContent = config.activation.activationKey || '-';
          }
          
          // Update activation date display
          const activationDateElement = document.getElementById('activated-date');
          if (activationDateElement) {
            const date = new Date(config.activation.activatedAt);
            activationDateElement.textContent = date.toLocaleDateString();
          }
          
          // Force refresh the entire popup to ensure all elements update
          loadAndDisplayConfig();
          
          // Notify background script to update floating panel
          chrome.runtime.sendMessage({
            type: 'UPDATE_CONFIG',
            config: config
          });
          
          // Also send activation success message
          chrome.runtime.sendMessage({
            type: 'ACTIVATION_SUCCESS',
            config: config
          });
          
          // Fetch referral code for the newly activated user
          fetchUserReferralCode(activationKey);
        });
      });
    } else {
      console.log('❌ Key not found in master keys');
      console.log('Available master keys:', masterKeys);
      throw new Error('Invalid activation code. Contact support for premium license key.');
    }
    /*
      } else {
        throw new Error(activateData.error || 'Failed to activate code');
      }
    } else {
      throw new Error(data.error || 'Invalid activation code');
    }
    */
  } catch (error) {
    errorDiv.textContent = error.message;
    errorDiv.style.display = 'block';
  } finally {
    // Reset button state
    const activateButton = document.getElementById('activateButton');
    activateButton.disabled = false;
    activateButton.textContent = '🚀 Activate Extension';
  }
}

// Helper function to get unique device ID
async function getDeviceId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['deviceId'], function(result) {
      if (result.deviceId) {
        resolve(result.deviceId);
      } else {
        // Generate new device ID
        const deviceId = 'ext-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        chrome.storage.local.set({ deviceId: deviceId }, function() {
          resolve(deviceId);
        });
      }
    });
  });
}

// Update main status badge
function updateMainStatus(config) {
  const mainStatus = document.getElementById('mainStatus');
  
  // Check if any automation is enabled
  const anyEnabled = (config.autoLogin?.enabled || 
                     config.missionMonitor?.enabled || 
                     config.missionAccept?.enabled) || false;
  
  // Update status badge based on activation status
  if (config.activation?.isActivated) {
    if (anyEnabled) {
      mainStatus.textContent = 'PREMIUM ACTIVE';
      mainStatus.className = 'status-badge premium';
    } else {
      mainStatus.textContent = 'UNLIMITED LICENSE';
      mainStatus.className = 'status-badge premium';
    }
  } else {
    const remaining = config.demo?.usesRemaining || 3;
    if (remaining > 0) {
      mainStatus.textContent = `TRIAL (${remaining})`;
      mainStatus.className = 'status-badge warning';
    } else {
      mainStatus.textContent = 'Get License';
      mainStatus.className = 'status-badge disabled';
    }
  }
}

// Update demo uses counter display
function updateDemoUsesCounter(config) {
  const demoCounterElement = document.getElementById('demo-uses-counter');
  if (demoCounterElement) {
    if (config.activation?.isActivated) {
      // Hide trial counter for activated users
      demoCounterElement.style.display = 'none';
    } else {
      const remaining = config.demo?.usesRemaining || 3;
      if (remaining > 0) {
        demoCounterElement.textContent = `Trial Uses: ${remaining}`;
        demoCounterElement.style.display = 'block';
      } else {
        demoCounterElement.textContent = 'Trial Expired - Get License';
        demoCounterElement.style.display = 'block';
      }
    }
  }
  
  // Also hide any trial warnings for premium users
  const trialWarnings = document.querySelectorAll('.trial-warning, .demo-warning, .free-warning');
  trialWarnings.forEach(warning => {
    if (config.activation?.isActivated) {
      warning.style.display = 'none';
    }
  });
}
