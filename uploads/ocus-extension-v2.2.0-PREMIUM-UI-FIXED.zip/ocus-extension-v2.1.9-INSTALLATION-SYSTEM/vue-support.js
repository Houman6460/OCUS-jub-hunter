/**
 * OCUS Unified Extension - Vue/Nuxt.js Support Module
 * 
 * This module provides specialized support for the Vue/Nuxt.js architecture of the OCUS platform,
 * enabling better detection of DOM changes, handling of routing events, and interaction with
 * dynamically rendered components.
 */

// Global container for Vue-specific helpers
window.ocusVueSupport = window.ocusVueSupport || {};

// Track URL changes to detect SPA navigation
let lastUrl = location.href;
window.ocusVueSupport.lastUrl = lastUrl;

/**
 * Initialize Vue support module
 */
function initVueSupport() {
  console.log('[OCUS] Initializing Vue/Nuxt.js support');
  
  // Setup URL change detection for SPA navigation
  setupUrlChangeDetection();
  
  // Setup Vue-specific mutation observer
  setupVueMutationObserver();
  
  // Expose helper functions
  setupHelperFunctions();
}

/**
 * Setup URL change detection to catch SPA navigation
 */
function setupUrlChangeDetection() {
  // Create a history state observer
  const originalPushState = history.pushState;
  const originalReplaceState = history.replaceState;
  
  // Override pushState
  history.pushState = function() {
    const result = originalPushState.apply(this, arguments);
    
    // Detect URL change
    if (lastUrl !== location.href) {
      const oldUrl = lastUrl;
      lastUrl = location.href;
      window.ocusVueSupport.lastUrl = lastUrl;
      
      // Dispatch a custom event for URL change
      window.dispatchEvent(new CustomEvent('ocusUrlChanged', {
        detail: {
          oldUrl: oldUrl,
          newUrl: lastUrl
        }
      }));
      
      console.log(`[OCUS] SPA navigation detected: ${oldUrl} -> ${lastUrl}`);
    }
    
    return result;
  };
  
  // Override replaceState
  history.replaceState = function() {
    const result = originalReplaceState.apply(this, arguments);
    
    // Detect URL change
    if (lastUrl !== location.href) {
      const oldUrl = lastUrl;
      lastUrl = location.href;
      window.ocusVueSupport.lastUrl = lastUrl;
      
      // Dispatch a custom event for URL change
      window.dispatchEvent(new CustomEvent('ocusUrlChanged', {
        detail: {
          oldUrl: oldUrl,
          newUrl: lastUrl
        }
      }));
      
      console.log(`[OCUS] SPA navigation detected (replaceState): ${oldUrl} -> ${lastUrl}`);
    }
    
    return result;
  };
  
  // Also listen for popstate to catch browser back/forward
  window.addEventListener('popstate', () => {
    if (lastUrl !== location.href) {
      const oldUrl = lastUrl;
      lastUrl = location.href;
      window.ocusVueSupport.lastUrl = lastUrl;
      
      // Dispatch a custom event for URL change
      window.dispatchEvent(new CustomEvent('ocusUrlChanged', {
        detail: {
          oldUrl: oldUrl,
          newUrl: lastUrl
        }
      }));
      
      console.log(`[OCUS] SPA navigation detected (popstate): ${oldUrl} -> ${lastUrl}`);
    }
  });
  
  console.log('[OCUS] URL change detection initialized');
}

/**
 * Setup Vue-specific mutation observer for DOM changes
 */
function setupVueMutationObserver() {
  // Setup a mutation observer that's tuned for Vue/Nuxt.js rendering
  const vueObserver = new MutationObserver((mutations) => {
    // Process mutations specifically for Vue-rendered content
    const significantChanges = processVueMutations(mutations);
    
    if (significantChanges) {
      // Dispatch event for significant Vue DOM changes
      window.dispatchEvent(new CustomEvent('ocusVueDomChanged', {
        detail: {
          mutations: mutations
        }
      }));
    }
  });
  
  // Start observing with configuration optimized for Vue
  vueObserver.observe(document.body || document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'data-v-']
  });
  
  // Store observer reference
  window.ocusVueSupport.vueObserver = vueObserver;
  
  console.log('[OCUS] Vue-specific mutation observer initialized');
}

/**
 * Process mutations from the Vue observer to determine if they're significant
 * @param {MutationRecord[]} mutations - Array of mutation records
 * @returns {boolean} - Whether significant Vue-related changes were detected
 */
function processVueMutations(mutations) {
  let significantChanges = false;
  
  // Check for Vue-specific mutations that indicate important content changes
  for (const mutation of mutations) {
    // Look for new nodes with Vue-specific attributes
    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === Node.ELEMENT_NODE) {
          // Check for Vue-specific attributes or classes
          if (
            node.hasAttribute && (
              node.hasAttribute('data-v-') || 
              node.querySelector('[data-v-]') ||
              node.classList.contains('v-') ||
              node.querySelector('.v-')
            )
          ) {
            significantChanges = true;
            break;
          }
          
          // Check specifically for mission cards or mission details
          if (
            node.classList && (
              node.classList.contains('mission-card') ||
              node.classList.contains('mission-details') ||
              node.querySelector('.mission-card') ||
              node.querySelector('.mission-details')
            )
          ) {
            significantChanges = true;
            break;
          }
        }
      }
    }
    
    // Also consider certain attribute changes significant
    if (!significantChanges && mutation.type === 'attributes') {
      const target = mutation.target;
      if (target.nodeType === Node.ELEMENT_NODE) {
        // Check if the attribute is Vue-related or affects visibility
        if (
          mutation.attributeName === 'data-v-' ||
          mutation.attributeName === 'style' ||
          mutation.attributeName === 'class'
        ) {
          // If the element or its parent is mission-related, consider it significant
          if (
            target.classList.contains('mission-card') ||
            target.classList.contains('mission-details') ||
            target.closest('.mission-card') ||
            target.closest('.mission-details')
          ) {
            significantChanges = true;
            break;
          }
        }
      }
    }
  }
  
  return significantChanges;
}

/**
 * Setup Vue-specific helper functions
 */
function setupHelperFunctions() {
  // Function to click a Vue element with proper event handling
  window.ocusVueSupport.clickVueElement = function(element) {
    if (!element) return false;
    
    try {
      // First check if the element is actually visible and clickable
      if (window.ocusHelpers && typeof window.ocusHelpers.isVisibleElement === 'function') {
        if (!window.ocusHelpers.isVisibleElement(element)) {
          console.log('[OCUS] Cannot click element - not visible', element);
          return false;
        }
      }
      
      // Track click success
      let clickSuccess = false;
      
      // Try Vue-specific click handling first
      if (tryVueClick(element)) {
        clickSuccess = true;
      } 
      // Fallback to standard click events
      else {
        // Create and dispatch standard events
        ['mousedown', 'mouseup', 'click'].forEach(eventType => {
          const event = new MouseEvent(eventType, {
            view: window,
            bubbles: true,
            cancelable: true,
            buttons: 1
          });
          
          element.dispatchEvent(event);
        });
        
        clickSuccess = true;
      }
      
      console.log('[OCUS] Vue element click ' + (clickSuccess ? 'successful' : 'failed'), element);
      return clickSuccess;
    } catch (error) {
      console.error('[OCUS] Error clicking Vue element:', error);
      return false;
    }
  };
  
  // Function to find all Vue component instances by name pattern
  window.ocusVueSupport.findVueComponentInstances = function(namePattern) {
    console.log(`[OCUS] Searching for Vue components matching pattern: ${namePattern}`);
    const results = [];
    
    // Helper to check if a component name matches our pattern
    const matchesNamePattern = (componentName) => {
      if (!componentName) return false;
      componentName = componentName.toLowerCase();
      namePattern = namePattern.toLowerCase();
      
      return componentName.includes(namePattern) || 
             componentName.includes(namePattern.replace('-', '')) ||
             componentName.includes(namePattern.replace('_', ''));
    };
    
    // Try to find Vue root from window.__vue__ or document elements
    const findComponentsInInstance = (instance) => {
      if (!instance) return;
      
      // Check if this component matches our pattern
      try {
        const componentName = instance.$options && 
                             (instance.$options.name || 
                              instance.$options._componentTag || 
                              instance.$options.__file);
        
        const componentProps = instance.$props || {};
        const componentData = instance.$data || {};
        
        // Check the name or tag
        if (componentName && matchesNamePattern(componentName)) {
          results.push(instance);
        }
        
        // Check props - if any props relate to missions
        const propsKeys = Object.keys(componentProps);
        for (const propKey of propsKeys) {
          if (matchesNamePattern(propKey)) {
            results.push(instance);
            break;
          }
        }
        
        // Check data properties
        const dataKeys = Object.keys(componentData);
        for (const dataKey of dataKeys) {
          if (matchesNamePattern(dataKey)) {
            results.push(instance);
            break;
          }
        }
      } catch (e) {
        // Silently continue if property access fails
      }
      
      // Check children
      try {
        // Vue 2.x children
        if (instance.$children && instance.$children.length) {
          for (const child of instance.$children) {
            findComponentsInInstance(child);
          }
        }
        
        // Vue 3.x children via subTree
        if (instance.subTree && instance.subTree.children) {
          for (const child of instance.subTree.children) {
            if (child.component) {
              findComponentsInInstance(child.component);
            }
          }
        }
      } catch (e) {
        // Silently continue if property access fails
      }
    };
    
    // Look for Vue instances in the DOM
    try {
      // Get all elements with Vue-specific attributes
      const vueElements = Array.from(document.querySelectorAll('[data-v-], [class*="v-"], [class*="mission"], .mission-card, .v-card, .v-list-item'));
      
      console.log(`[OCUS] Found ${vueElements.length} potential Vue elements in DOM`);
      
      // Check each element for Vue instance
      for (const element of vueElements) {
        const vueInstance = getVueInstance(element);
        if (vueInstance) {
          findComponentsInInstance(vueInstance);
        }
      }
    } catch (e) {
      console.error('[OCUS] Error finding Vue components in DOM:', e);
    }
    
    // Try to access global Vue instances (works in dev mode)
    try {
      if (window.__VUE_DEVTOOLS_GLOBAL_HOOK__) {
        const devtools = window.__VUE_DEVTOOLS_GLOBAL_HOOK__;
        if (devtools.Vue && devtools.Vue.prototype && devtools._instances) {
          for (const instance of devtools._instances) {
            findComponentsInInstance(instance);
          }
        }
      }
    } catch (e) {
      console.error('[OCUS] Error accessing Vue devtools:', e);
    }
    
    // Remove duplicates
    const uniqueResults = Array.from(new Set(results));
    console.log(`[OCUS] Found ${uniqueResults.length} Vue components matching pattern: ${namePattern}`);
    
    return uniqueResults;
  };
  
  // Function to get props from a Vue instance
  window.ocusVueSupport.getVueComponentProps = function(instance) {
    if (!instance) return null;
    
    try {
      // Try different ways to access props
      const props = instance.$props || 
                   (instance.$options && instance.$options.propsData) || 
                   {};
      
      // Also check data for mission-related properties
      const data = instance.$data || {};
      
      // Combine props and relevant data
      return { ...props, ...data };
    } catch (error) {
      console.error('[OCUS] Error getting Vue component props:', error);
      return null;
    }
  };
  
  // Function to find mission-related Vue components
  window.ocusVueSupport.findMissionComponents = function() {
    console.log('[OCUS] Searching for mission-related Vue components');
    
    // Enhanced pattern search with more comprehensive terms
    const missionPatterns = [
      'mission', 'project', 'assignment', 'task',
      'card', 'list-item', 'offer', 'extension',
      'review', 'food', 'availablemission', 'v-card'
    ];
    let missionComponents = [];
    
    // Search for each mission-related pattern
    for (const pattern of missionPatterns) {
      const components = window.ocusVueSupport.findVueComponentInstances(pattern);
      missionComponents = [...missionComponents, ...components];
    }
    
    // Also search for components with mission-related DOM attributes
    const vueInstances = window.ocusVueSupport.findVueComponentInstances();
    const attributePatterns = [
      { attr: 'data-cy-id', value: 'availablemission' },
      { attr: 'data-cy', value: 'mission' },
      { attr: 'data-test', value: 'mission' },
      { attr: 'href', value: '/mission/' },
      { attr: 'to', value: '/mission/' },
      { attr: 'class', value: 'mission-card' },
      { attr: 'class', value: 'v-card--link' },
      { attr: 'role', value: 'button' }
    ];
    
    // Add components with matching DOM attributes
    for (const instance of vueInstances) {
      try {
        const el = instance.$el;
        if (el) {
          for (const pattern of attributePatterns) {
            const attrValue = el.getAttribute(pattern.attr);
            if (attrValue && attrValue.includes(pattern.value)) {
              missionComponents.push(instance);
              break;
            }
          }
          
          // Check for specific element classes
          if (el.className && typeof el.className === 'string') {
            const classStr = el.className.toLowerCase();
            if (classStr.includes('mission') || classStr.includes('card') || classStr.includes('v-list-item')) {
              missionComponents.push(instance);
            }
          }
        }
      } catch (e) {
        // Continue if property access fails
      }
    }
    
    // Remove duplicates
    const uniqueComponents = Array.from(new Set(missionComponents));
    console.log(`[OCUS] Found ${uniqueComponents.length} mission-related Vue components`);
    
    // Categorize components by type with enhanced detection
    const result = {
      all: uniqueComponents,
      missionCards: [],
      detailViews: [],
      actionButtons: [],
      lists: []
    };
    
    // Categorize each component with more comprehensive rules
    for (const component of uniqueComponents) {
      try {
        const props = window.ocusVueSupport.getVueComponentProps(component);
        const el = component.$el;
        const componentName = component.$options && 
                            (component.$options.name || 
                             component.$options._componentTag || 
                             component.$options.__file);
        
        // Enhanced name detection
        const nameLower = (componentName || '').toLowerCase();
        let isMissionCard = false;
        let isDetailView = false;
        let isActionButton = false;
        let isList = false;
        
        // Check component name patterns
        if (nameLower.includes('card') || 
            nameLower.includes('item') || 
            nameLower.includes('mission') || 
            nameLower.includes('tile')) {
          isMissionCard = true;
        } 
        if (nameLower.includes('detail') || 
            nameLower.includes('view') || 
            nameLower.includes('page')) {
          isDetailView = true;
        } 
        if (nameLower.includes('button') || 
            nameLower.includes('action') || 
            nameLower.includes('accept')) {
          isActionButton = true;
        } 
        if (nameLower.includes('list') || 
            nameLower.includes('table') || 
            nameLower.includes('collection')) {
          isList = true;
        }
        
        // Check DOM attributes and structure
        if (el) {
          // Check for mission card patterns in element
          if (el.className && typeof el.className === 'string') {
            const classes = el.className.toLowerCase();
            if (classes.includes('mission-card') || 
                classes.includes('v-card') || 
                classes.includes('list-item') || 
                classes.includes('mission')) {
              isMissionCard = true;
            }
            if (classes.includes('mission-detail') || 
                classes.includes('mission-view')) {
              isDetailView = true;
            }
            if (classes.includes('btn') || 
                classes.includes('button') || 
                classes.includes('v-btn')) {
              isActionButton = true;
            }
          }
          
          // Check for specific OCUS patterns
          for (const attr of ['data-cy-id', 'data-cy', 'data-test', 'id']) {
            const attrValue = el.getAttribute(attr);
            if (attrValue) {
              if (attrValue.includes('mission') || attrValue.includes('available')) {
                isMissionCard = true;
              }
              if (attrValue.includes('detail') || attrValue.includes('view')) {
                isDetailView = true;
              }
              if (attrValue.includes('accept') || attrValue.includes('button')) {
                isActionButton = true;
              }
              if (attrValue.includes('list') || attrValue.includes('table')) {
                isList = true;
              }
            }
          }
          
          // Check for link to mission details
          if (el.tagName === 'A' && el.href && 
              (el.href.includes('/mission/') || 
               el.href.includes('/missions/'))) {
            isMissionCard = true;
          }
          
          // Check for content suggesting a mission card
          if (el.textContent) {
            const text = el.textContent.toLowerCase();
            if ((text.includes('extension') || text.includes('review')) && 
                (text.match(/\d+/) || text.includes('mission'))) {
              isMissionCard = true;
            }
          }
        }
        
        // Check Vue props for mission-related data
        if (props) {
          // Check for props indicating mission cards
          if (props.mission || props.missionId || 
              props.project || props.projectId || 
              props.assignment || props.assignmentId) {
            isMissionCard = true;
          }
          
          // Check for route props
          if (props.to && typeof props.to === 'string' && 
              (props.to.includes('/mission/') || props.to.includes('/missions/'))) {
            isMissionCard = true;
          } else if (props.to && typeof props.to === 'object' && props.to.path && 
                    (props.to.path.includes('/mission/') || props.to.path.includes('/missions/'))) {
            isMissionCard = true;
          }
          
          // Check for accept button props
          const propKeys = Object.keys(props);
          if (propKeys.some(key => {
            return key.toLowerCase().includes('accept') || 
                  (key.toLowerCase().includes('button') && 
                   props[key] && 
                   typeof props[key] === 'string' && 
                   props[key].toLowerCase().includes('accept'));
          })) {
            isActionButton = true;
          }
          
          // Check for action/primary button indicators
          if (props.primary === true || props.color === 'primary' || 
              (props.variant && props.variant.includes('primary'))) {
            isActionButton = true;
          }
        }
        
        // Add to appropriate categories
        if (isMissionCard) result.missionCards.push(component);
        if (isDetailView) result.detailViews.push(component);
        if (isActionButton) result.actionButtons.push(component);
        if (isList) result.lists.push(component);
        
      } catch (e) {
        console.warn('[OCUS] Error categorizing Vue component:', e);
        // Continue to next component
      }
    }
    
    // Log results with clear counts
    console.log('[OCUS] Categorized mission components:', {
      missionCards: result.missionCards.length,
      detailViews: result.detailViews.length,
      actionButtons: result.actionButtons.length,
      lists: result.lists.length
    });
    
    return result;
  };
  
  // Function to set up a watcher for mission components
  window.ocusVueSupport.watchMissionComponents = function(callback, interval = 2000) {
    console.log('[OCUS] Setting up mission component watcher');
    
    // Store previous mission components to detect changes
    let previousMissionComponents = {
      missionCards: 0,
      detailViews: 0,
      actionButtons: 0,
      lists: 0
    };
    
    // Function to check for changes
    const checkForChanges = () => {
      try {
        // Find current mission components
        const missionComponents = window.ocusVueSupport.findMissionComponents();
        
        // Prepare current counts
        const currentCounts = {
          missionCards: missionComponents.missionCards.length,
          detailViews: missionComponents.detailViews.length,
          actionButtons: missionComponents.actionButtons.length,
          lists: missionComponents.lists.length
        };
        
        // Check for changes
        let hasChanges = false;
        for (const key in currentCounts) {
          if (currentCounts[key] !== previousMissionComponents[key]) {
            hasChanges = true;
            break;
          }
        }
        
        // If changes detected, call the callback
        if (hasChanges) {
          console.log('[OCUS] Mission component change detected');
          callback(missionComponents, previousMissionComponents);
          
          // Update previous counts
          previousMissionComponents = { ...currentCounts };
        }
      } catch (error) {
        console.error('[OCUS] Error in mission component watcher:', error);
      }
    };
    
    // Perform initial check
    setTimeout(checkForChanges, 500);
    
    // Set up interval for regular checks
    const watcherId = setInterval(checkForChanges, interval);
    
    // Return a function to stop watching
    return function stopWatching() {
      clearInterval(watcherId);
      console.log('[OCUS] Mission component watcher stopped');
    };
  };
  
  // Function to extract mission data from Vue components
  window.ocusVueSupport.extractMissionData = function(component) {
    if (!component) return null;
    
    try {
      const props = window.ocusVueSupport.getVueComponentProps(component);
      
      // Enhanced structure for mission data with additional fields
      const missionData = {
        id: null,
        title: null,
        url: null,
        type: null, // 'mission', 'project', 'assignment'
        status: null,
        extensions: null,
        reviews: null,
        priority: null,
        dueDate: null,
        element: component.$el,
        instance: component,
        componentName: (component.$options && 
                      (component.$options.name || 
                       component.$options._componentTag || 
                       component.$options.__file)) || null
      };
      
      // Extract data from props if available
      if (props) {
        // Direct mission/project/assignment objects
        if (props.mission) {
          missionData.type = 'mission';
          if (typeof props.mission === 'object') {
            missionData.id = props.mission.id || missionData.id;
            missionData.title = props.mission.title || props.mission.name || missionData.title;
            missionData.url = props.mission.url || props.mission.href || missionData.url;
            missionData.status = props.mission.status || missionData.status;
            missionData.priority = props.mission.priority || missionData.priority;
            missionData.dueDate = props.mission.dueDate || props.mission.due_date || missionData.dueDate;
            missionData.extensions = props.mission.extensions || props.mission.extensionCount || missionData.extensions;
            missionData.reviews = props.mission.reviews || props.mission.reviewCount || missionData.reviews;
          } else if (typeof props.mission === 'string') {
            // Handle case where mission is just an ID string
            missionData.id = props.mission;
          }
        } else if (props.project) {
          missionData.type = 'project';
          if (typeof props.project === 'object') {
            missionData.id = props.project.id || missionData.id;
            missionData.title = props.project.title || props.project.name || missionData.title;
            missionData.url = props.project.url || props.project.href || missionData.url;
            missionData.status = props.project.status || missionData.status;
          } else if (typeof props.project === 'string') {
            missionData.id = props.project;
          }
        } else if (props.assignment) {
          missionData.type = 'assignment';
          if (typeof props.assignment === 'object') {
            missionData.id = props.assignment.id || missionData.id;
            missionData.title = props.assignment.title || props.assignment.name || missionData.title;
            missionData.url = props.assignment.url || props.assignment.href || missionData.url;
            missionData.status = props.assignment.status || missionData.status;
          } else if (typeof props.assignment === 'string') {
            missionData.id = props.assignment;
          }
        }
        
        // Direct ID properties
        missionData.id = missionData.id || props.id || props.missionId || props.projectId || 
                         props.assignmentId || props.taskId || props._id;
        
        // Direct URL properties - both string and object formats
        if (!missionData.url) {
          if (props.to) {
            if (typeof props.to === 'string') {
              missionData.url = props.to;
            } else if (typeof props.to === 'object' && props.to.path) {
              missionData.url = props.to.path;
            }
          } else if (props.href) {
            missionData.url = props.href;
          } else if (props.url) {
            missionData.url = props.url;
          } else if (props.link) {
            missionData.url = props.link;
          }
        }
        
        // Direct title/name properties
        missionData.title = missionData.title || props.title || props.name || props.label;
        
        // Type detection from other properties if not already set
        if (!missionData.type) {
          if (props.type) {
            const type = props.type.toLowerCase();
            if (type.includes('mission')) missionData.type = 'mission';
            else if (type.includes('project')) missionData.type = 'project';
            else if (type.includes('assignment')) missionData.type = 'assignment';
          } else if (missionData.url) {
            // Try to determine type from URL
            if (missionData.url.includes('/mission/')) missionData.type = 'mission';
            else if (missionData.url.includes('/project/')) missionData.type = 'project';
            else if (missionData.url.includes('/assignment/')) missionData.type = 'assignment';
          }
        }
        
        // Other metadata
        missionData.status = missionData.status || props.status;
        missionData.priority = missionData.priority || props.priority;
        missionData.extensions = missionData.extensions || props.extensions || props.extensionCount;
        missionData.reviews = missionData.reviews || props.reviews || props.reviewCount;
        missionData.dueDate = missionData.dueDate || props.dueDate || props.due_date || props.deadline;
      }
      
      // Extract additional data from DOM element
      if (component.$el) {
        const el = component.$el;
        
        // If we don't have an ID yet, try to find one from attributes
        if (!missionData.id) {
          const idAttributes = ['data-id', 'data-mission-id', 'data-cy-id', 'data-test-id', 'id'];
          for (const attr of idAttributes) {
            const value = el.getAttribute(attr);
            if (value) {
              missionData.id = value;
              break;
            }
          }
          
          // Look for UUID patterns in attributes and classes
          if (!missionData.id) {
            // Check class names for embedded IDs
            if (el.className && typeof el.className === 'string') {
              const uuidMatch = el.className.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
              if (uuidMatch) {
                missionData.id = uuidMatch[0];
              }
            }
            
            // Check all attributes for UUIDs
            if (!missionData.id) {
              for (const attr of el.attributes) {
                const uuidMatch = attr.value.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
                if (uuidMatch) {
                  missionData.id = uuidMatch[0];
                  break;
                }
              }
            }
          }
        }
        
        // If we don't have a URL yet, try to find one from the element or children
        if (!missionData.url) {
          // Check if the element itself is a link
          if (el.tagName === 'A' && el.href) {
            missionData.url = el.href;
          } else {
            // Check for links inside the element
            const missionLinkPatterns = [
              'a[href*="/mission/"]',
              'a[href*="/missions/"]', 
              'a[href*="/project/"]',
              'a[href*="/projects/"]',
              'a[href*="/assignment/"]',
              'a[href*="/assignments/"]'
            ];
            
            for (const pattern of missionLinkPatterns) {
              const link = el.querySelector(pattern);
              if (link && link.href) {
                missionData.url = link.href;
                
                // Also try to determine type from URL if not set
                if (!missionData.type) {
                  if (link.href.includes('/mission/')) missionData.type = 'mission';
                  else if (link.href.includes('/project/')) missionData.type = 'project';
                  else if (link.href.includes('/assignment/')) missionData.type = 'assignment';
                }
                
                break;
              }
            }
          }
        }
        
        // If we don't have a title yet, try to extract one from element
        if (!missionData.title) {
          const titleSelectors = [
            '.title', '.mission-title', '.card-title', '.mission-card__title',
            '.v-card__title', 'h3', 'h4', '.font-weight-bold', '.v-list-item__title'
          ];
          
          for (const selector of titleSelectors) {
            const titleEl = el.querySelector(selector);
            if (titleEl && titleEl.textContent.trim()) {
              missionData.title = titleEl.textContent.trim();
              break;
            }
          }
          
          // If still no title but element has text, use first part as title
          if (!missionData.title && el.textContent) {
            const text = el.textContent.trim();
            // Use first line or first 50 chars, whichever is shorter
            const firstLine = text.split('\n')[0].trim();
            missionData.title = firstLine.length > 50 ? firstLine.substring(0, 47) + '...' : firstLine;
          }
        }
        
        // Extract extension count if not already set
        if (!missionData.extensions) {
          const extensionSelectors = [
            '.extension-number', '.extension-count', '.mission-card__extension-count',
            '[data-cy="extension-number"]', '[data-test="extension-number"]'
          ];
          
          for (const selector of extensionSelectors) {
            const extensionEl = el.querySelector(selector);
            if (extensionEl && extensionEl.textContent.trim()) {
              const match = extensionEl.textContent.trim().match(/\d+/);
              if (match) {
                missionData.extensions = parseInt(match[0], 10);
                break;
              }
            }
          }
        }
        
        // Extract review count if not already set
        if (!missionData.reviews) {
          const reviewSelectors = [
            '.review-count', '.review-number', '.mission-card__review-count',
            '[data-cy="review-count"]', '[data-test="review-count"]'
          ];
          
          for (const selector of reviewSelectors) {
            const reviewEl = el.querySelector(selector);
            if (reviewEl && reviewEl.textContent.trim()) {
              const match = reviewEl.textContent.trim().match(/\d+/);
              if (match) {
                missionData.reviews = parseInt(match[0], 10);
                break;
              }
            }
          }
        }
      }
      
      // Post-processing - ensure URL is absolute
      if (missionData.url && typeof missionData.url === 'string' && missionData.url.startsWith('/')) {
        missionData.url = window.location.origin + missionData.url;
      }
      
      // If we have ID but no URL, try to construct a URL
      if (missionData.id && !missionData.url) {
        const type = missionData.type || 'mission'; // Default to mission if type not set
        let basePath;
        
        switch (type) {
          case 'project':
            basePath = '/project/';
            break;
          case 'assignment':
            basePath = '/assignment/';
            break;
          default: // mission
            basePath = '/mission/';
        }
        
        missionData.url = window.location.origin + basePath + missionData.id;
      }
      
      // Only return if we have at least id or url (minimal viable data)
      if (missionData.id || missionData.url) {
        console.log('[OCUS] Extracted mission data:', missionData);
        return missionData;
      }
      
      return null;
    } catch (error) {
      console.error('[OCUS] Error extracting mission data:', error);
      return null;
    }
  };
  
  // Function to find a Vue component by its properties
  window.ocusVueSupport.findVueComponent = function(selector, propertyMatch) {
    const elements = document.querySelectorAll(selector);
    
    for (const element of elements) {
      // Try to access the Vue instance
      const vueInstance = getVueInstance(element);
      
      if (vueInstance && matchesProperties(vueInstance, propertyMatch)) {
        return { element, instance: vueInstance };
      }
    }
    
    return null;
  };
  
  // Function to detect when Vue has fully loaded and initialized
  window.ocusVueSupport.waitForVueReady = function(callback, timeout = 10000) {
    // Check if Vue is already available
    if (isVueReady()) {
      callback();
      return;
    }
    
    // Set timeout to avoid waiting forever
    const timeoutId = setTimeout(() => {
      clearInterval(checkInterval);
      console.log('[OCUS] Timeout waiting for Vue to initialize');
    }, timeout);
    
    // Periodically check for Vue
    const checkInterval = setInterval(() => {
      if (isVueReady()) {
        clearTimeout(timeoutId);
        clearInterval(checkInterval);
        callback();
      }
    }, 200);
  };
  
  // Promise-based version of waitForVueReady
  window.ocusVueSupport.waitForVueInitialization = function(timeout = 10000) {
    return new Promise((resolve, reject) => {
      window.ocusVueSupport.waitForVueReady(() => {
        resolve();
      }, timeout);
      
      // Reject the promise if timeout
      setTimeout(() => {
        reject(new Error('Vue initialization timeout'));
      }, timeout);
    });
  };
  
  // Setup Vue component observer
  window.ocusVueSupport.setupVueComponentObserver = function() {
    console.log('[OCUS] Setting up Vue component observer');
    
    // Create a specialized observer for Vue components
    const vueComponentObserver = new MutationObserver((mutations) => {
      // Check for Vue component-related mutations
      for (const mutation of mutations) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              // Check if this is a Vue component container
              if (node.hasAttribute && (
                  node.hasAttribute('data-v-') || 
                  node.querySelector('[data-v-]')
                )) {
                // Look for mission-related content within this Vue component
                if (isVueMissionComponent(node)) {
                  console.log('[OCUS] Detected mission-related Vue component:', node);
                  window.dispatchEvent(new CustomEvent('ocusVueMissionComponentFound', {
                    detail: { element: node }
                  }));
                }
              }
            }
          }
        }
      }
    });
    
    // Start observing Vue components
    vueComponentObserver.observe(document.body || document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['data-v-', 'class']
    });
    
    // Store reference to observer
    window.ocusVueSupport.vueComponentObserver = vueComponentObserver;
    
    return vueComponentObserver;
  };
  
  console.log('[OCUS] Vue helper functions initialized');
}

/**
 * Attempt to trigger a Vue-specific click by accessing the Vue component system
 * @param {HTMLElement} element - Element to click
 * @returns {boolean} - Whether a Vue-specific click was successfully triggered
 */
function tryVueClick(element) {
  // Try to find the Vue instance attached to this element
  const vueInstance = getVueInstance(element);
  
  if (!vueInstance) {
    return false;
  }
  
  try {
    // Look for click handlers in the Vue instance
    const clickHandler = 
      (vueInstance.$options && vueInstance.$options.methods && vueInstance.$options.methods.click) ||
      (vueInstance.$options && vueInstance.$options.methods && vueInstance.$options.methods.onClick) ||
      (vueInstance.$listeners && vueInstance.$listeners.click);
    
    if (clickHandler && typeof clickHandler === 'function') {
      // Call the click handler in the context of the Vue instance
      clickHandler.call(vueInstance);
      return true;
    }
    
    // Also try emitting a click event through the Vue event system
    if (vueInstance.$emit) {
      vueInstance.$emit('click');
      return true;
    }
  } catch (error) {
    console.error('[OCUS] Error during Vue click handling:', error);
  }
  
  return false;
}

/**
 * Get the Vue instance from a DOM element
 * @param {HTMLElement} element - DOM element that might have a Vue instance
 * @returns {Object|null} - Vue instance if found, null otherwise
 */
function getVueInstance(element) {
  if (!element) return null;
  
  // Different ways Vue instances might be attached to elements
  return element.__vue__ || 
         element.__vueParentComponent || 
         element.__proto__.__vue__ || 
         null;
}

/**
 * Check if a Vue instance matches the specified properties
 * @param {Object} instance - Vue instance
 * @param {Object} propertyMatch - Properties to match
 * @returns {boolean} - Whether the instance matches all properties
 */
function matchesProperties(instance, propertyMatch) {
  if (!instance || !propertyMatch) return false;
  
  for (const prop in propertyMatch) {
    // Handle nested properties with dot notation
    if (prop.includes('.')) {
      const parts = prop.split('.');
      let current = instance;
      
      // Navigate through the nested properties
      for (const part of parts) {
        if (current === undefined || current === null) return false;
        current = current[part];
      }
      
      if (current !== propertyMatch[prop]) return false;
    } 
    // Handle direct properties
    else if (instance[prop] !== propertyMatch[prop]) {
      return false;
    }
  }
  
  return true;
}

/**
 * Check if Vue has been initialized on the page
 * @returns {boolean} - Whether Vue is ready
 */
function isVueReady() {
  // Check for global Vue
  if (window.Vue) return true;
  
  // Check for Nuxt
  if (window.__NUXT__ || document.querySelector('#__nuxt')) {
    // Find any element with Vue instance
    const vueElements = document.querySelectorAll('[data-v-]');
    if (vueElements.length > 0) {
      return true;
    }
  }
  
  return false;
}

/**
 * Check if an element is a Vue component related to missions
 * @param {HTMLElement} element - Element to check
 * @returns {boolean} - Whether the element is a mission-related Vue component
 */
function isVueMissionComponent(element) {
  if (!element) return false;
  
  // Check the element's classes and content for mission-related indicators
  const missionRelatedClasses = [
    'mission-card',
    'mission-details',
    'mission-list',
    'mission-header',
    'mission-content',
    'v-mission',
    'mission-actions',
    'mission-button',
    'mission-info',
    'assignment-card',
    'project-card',
    'task-card',
    'accept-container',
    'task-details',
    'assignment-details',
    'project-details',
    'mission-container',
    'project-container'
  ];
  
  // Check if the element has any mission-related classes
  if (element.classList) {
    for (const className of missionRelatedClasses) {
      // Handle partial class matching (e.g., "v-card mission-card-item")
      if (element.className && typeof element.className === 'string' && 
          element.className.indexOf(className) !== -1) {
        return true;
      }
    }
  }
  
  // Check if the element contains any mission-related classes
  if (element.querySelector) {
    for (const className of missionRelatedClasses) {
      if (element.querySelector(`.${className}`) || 
          element.querySelector(`[class*="${className}"]`)) {
        return true;
      }
    }
  }
  
  // Check for OCUS-specific selectors
  const ocusSpecificSelectors = [
    '[data-cy-id="acceptMissionButton"]',
    '[data-cy="acceptMissionButton"]',
    '[data-cy-id="acceptProjectButton"]',
    '[data-cy="acceptProjectButton"]',
    '[data-test="accept-mission"]',
    '[data-test="accept-project"]',
    '[data-e2e="accept-button"]',
    '[data-cy*="mission"]',
    '[data-cy*="project"]',
    '[data-cy*="assignment"]',
    '[data-test*="mission"]',
    '[data-test*="project"]',
    '[data-test*="assignment"]'
  ];
  
  for (const selector of ocusSpecificSelectors) {
    if (element.querySelector && element.querySelector(selector)) {
      return true;
    }
    
    // Check if the element itself matches the selector
    if (element.matches && element.matches(selector)) {
      return true;
    }
  }
  
  // Check the text content for mission-related keywords
  const missionKeywords = [
    'mission', 
    'accept mission', 
    'accept assignment', 
    'accept project', 
    'accept task', 
    'accept this mission', 
    'assignment', 
    'project',
    'take mission'
  ];
  
  if (element.textContent) {
    const text = element.textContent.toLowerCase();
    for (const keyword of missionKeywords) {
      if (text.includes(keyword)) {
        // If we found a keyword, check if there's a button nearby
        if (element.querySelector('button') || 
            element.querySelector('[role="button"]') ||
            element.querySelector('.v-btn')) {
          return true;
        }
      }
    }
  }
  
  // Check for mission-related attributes
  if (element.hasAttribute && element.getAttribute) {
    const missionAttributes = [
      'data-mission-id',
      'data-mission',
      'mission-id',
      'data-project-id',
      'project-id',
      'data-assignment-id',
      'assignment-id',
      'data-task-id',
      'task-id'
    ];
    
    for (const attr of missionAttributes) {
      if (element.hasAttribute(attr)) {
        return true;
      }
    }
    
    // Check for data-cy/data-test attributes related to missions
    const dataAttributes = ['data-cy', 'data-test', 'data-e2e', 'data-cy-id'];
    const missionTerms = ['mission', 'project', 'assignment', 'task', 'accept'];
    
    for (const dataAttr of dataAttributes) {
      if (element.hasAttribute(dataAttr)) {
        const attrValue = element.getAttribute(dataAttr).toLowerCase();
        for (const term of missionTerms) {
          if (attrValue.includes(term)) {
            return true;
          }
        }
      }
    }
  }
  
  // Check for UUID pattern in URLs or attributes for mission IDs
  const uuidRegex = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i;
  
  // Check attributes for UUIDs
  if (element.attributes) {
    for (let i = 0; i < element.attributes.length; i++) {
      const attr = element.attributes[i];
      if (uuidRegex.test(attr.value)) {
        // UUID found in attribute, check if in mission context
        const attrName = attr.name.toLowerCase();
        if (attrName.includes('id') || attrName.includes('mission') || 
            attrName.includes('project') || attrName.includes('assignment')) {
          return true;
        }
      }
    }
  }
  
  // Check for a button with 'Accept' text
  const buttons = element.querySelectorAll ? 
    element.querySelectorAll('button, .v-btn, [role="button"]') : [];
  
  for (const button of buttons) {
    if (button.textContent && button.textContent.toLowerCase().includes('accept')) {
      return true;
    }
  }
  
  return false;
}

/**
 * Diagnose common Vue component issues and attempt self-repair
 * This helps identify and fix issues with the Vue components in the DOM
 * @param {boolean} deepScan - Whether to perform a more intensive scan
 * @returns {Object} Diagnostic results
 */
window.ocusVueSupport.diagnoseAndRepair = function(deepScan = false) {
  console.log('[OCUS] Diagnosing potential Vue component issues...');
  let repairsAttempted = false;
  
  // Check for broken render cycles
  const disconnectedNodes = findDisconnectedVueNodes();
  if (disconnectedNodes.length > 0) {
    console.warn('[OCUS] Found disconnected Vue nodes:', disconnectedNodes.length);
    // Attempt to trigger a re-render
    triggerVueRerender();
    repairsAttempted = true;
  }
  
  // Check for stalled data binding
  const stalledElements = document.querySelectorAll('[v-cloak]');
  if (stalledElements.length > 0) {
    console.warn('[OCUS] Found stalled Vue elements with v-cloak:', stalledElements.length);
    // Force remove v-cloak to make elements visible
    stalledElements.forEach(el => el.removeAttribute('v-cloak'));
    repairsAttempted = true;
  }
  
  // Check for any error states in Vue components
  const errorStates = document.querySelectorAll('.vue-error, .v-error, [data-error="true"]');
  if (errorStates.length > 0) {
    console.warn('[OCUS] Found Vue components in error state:', errorStates.length);
    // Log error details
    errorStates.forEach(el => {
      console.error('Vue component error:', {
        element: el,
        errorMessage: el.getAttribute('data-error-message') || 'Unknown error'
      });
    });
  }
  
  // Check for version-specific issues
  try {
    // Try to detect Vue version
    let vueVersion = 'unknown';
    if (window.Vue && window.Vue.version) {
      vueVersion = window.Vue.version;
    } else if (window.__NUXT__ && window.__NUXT__.serverRendered) {
      vueVersion = 'Nuxt SSR';
    }
    console.log(`[OCUS] Detected Vue version: ${vueVersion}`);
    
    // Apply version-specific fixes
    if (vueVersion.startsWith('2.')) {
      // Vue 2.x fixes
      if (window.Vue && window.Vue.nextTick) {
        window.Vue.nextTick(() => {
          console.log('[OCUS] Triggered Vue.nextTick for Vue 2.x');
        });
        repairsAttempted = true;
      }
    } else if (vueVersion.startsWith('3.')) {
      // Vue 3.x fixes
      setTimeout(() => {
        console.log('[OCUS] Waited for Vue 3.x render cycle');
      }, 0);
      repairsAttempted = true;
    }
  } catch (e) {
    console.error('[OCUS] Error detecting/fixing Vue version:', e);
  }
  
  // Check for Nuxt-specific issues
  if (document.querySelector('#__nuxt') || window.$nuxt) {
    console.log('[OCUS] Nuxt application detected, checking for hydration issues');
    
    // Nuxt sometimes gets into a state where hydration is incomplete
    try {
      // Force a small URL change to help trigger reactivity
      const url = new URL(window.location.href);
      const oldTime = url.searchParams.get('_t');
      const newTime = Date.now();
      
      // Only update if we haven't recently tried
      if (!oldTime || (newTime - parseInt(oldTime)) > 2000) {
        url.searchParams.set('_t', newTime);
        window.history.replaceState({}, '', url.toString());
        console.log('[OCUS] Triggered history update to fix potential Nuxt hydration issues');
        repairsAttempted = true;
      }
      
      // Try Nuxt-specific router refresh if available
      if (window.$nuxt && window.$nuxt.$router) {
        try {
          const currentRoute = window.$nuxt.$router.currentRoute;
          const routeObj = typeof currentRoute === 'object' ? currentRoute : {};
          const query = {...(routeObj.query || {}), _vt: Date.now()};
          
          // Only update if this is different
          if (!routeObj.query || routeObj.query._vt !== query._vt) {
            window.$nuxt.$router.replace({
              ...routeObj,
              query
            });
            console.log('[OCUS] Triggered Nuxt router refresh');
            repairsAttempted = true;
          }
        } catch (e) {
          console.error('[OCUS] Error attempting Nuxt router refresh:', e);
        }
      }
    } catch (e) {
      console.error('[OCUS] Error fixing Nuxt hydration:', e);
    }
  }
  
  // Specific scan for mission-related components
  if (deepScan) {
    console.log('[OCUS] Performing deep scan for mission components');
    
    // Try to find and activate mission buttons
    const missionButtons = document.querySelectorAll(
      '.v-btn:not([disabled]), [role="button"]:not([disabled]), .mission-action, .primary-action'
    );
    
    if (missionButtons.length > 0) {
      console.log(`[OCUS] Found ${missionButtons.length} potential mission buttons, attempting to activate`);
      
      missionButtons.forEach(button => {
        // Try to trigger reactivity on the button
        try {
          // Add a small animation to potentially trigger Vue reactivity
          button.style.transition = 'transform 0.1s ease';
          button.style.transform = 'scale(1.01)';
          setTimeout(() => {
            button.style.transform = 'scale(1)';
            // Dispatch a mouseover event
            button.dispatchEvent(new MouseEvent('mouseover', {
              view: window,
              bubbles: true,
              cancelable: true
            }));
          }, 50);
          repairsAttempted = true;
        } catch (e) {
          // Ignore errors from individual button animations
        }
      });
    }
    
    // Check for lazy-loaded components that might contain mission buttons
    const lazyComponents = document.querySelectorAll('[lazy],[lazy=true],[data-lazy]');
    if (lazyComponents.length > 0) {
      console.log(`[OCUS] Found ${lazyComponents.length} lazy-loaded components, attempting to activate`);
      try {
        // Scroll slightly to trigger lazy loading
        window.scrollBy({top: 1, behavior: 'smooth'});
        setTimeout(() => {
          window.scrollBy({top: -1, behavior: 'smooth'});
        }, 100);
        repairsAttempted = true;
      } catch (e) {
        console.error('[OCUS] Error attempting to activate lazy components:', e);
      }
    }
  }
  
  // Force a reflow/repaint of the page
  try {
    const forceReflow = document.body.offsetHeight;
    window.dispatchEvent(new Event('resize'));
    document.dispatchEvent(new CustomEvent('vue-updated'));
  } catch (e) {
    // Ignore errors from reflow
  }
  
  // Dispatch event for mission components to know repairs were attempted
  window.dispatchEvent(new CustomEvent('ocusVueDiagnosticComplete', {
    detail: { 
      timestamp: Date.now(),
      repairsAttempted: repairsAttempted,
      disconnectedNodes: disconnectedNodes.length
    }
  }));
  
  // Return diagnostic results
  return {
    disconnectedNodes: disconnectedNodes.length,
    stalledElements: stalledElements.length,
    errorStates: errorStates.length,
    repairsAttempted: repairsAttempted,
    healthy: disconnectedNodes.length === 0 && stalledElements.length === 0 && errorStates.length === 0
  };
};

/**
 * Find Vue nodes that may be disconnected from the reactive system
 * @returns {Array} - Array of potentially disconnected nodes
 */
function findDisconnectedVueNodes() {
  const vueNodes = document.querySelectorAll('[data-v-]');
  const disconnected = [];
  
  vueNodes.forEach(node => {
    // Check for Vue instance
    const hasInstance = getVueInstance(node);
    if (!hasInstance && node.getAttribute('data-v-')) {
      disconnected.push(node);
    }
  });
  
  return disconnected;
}

/**
 * Attempt to trigger a Vue rerender
 */
function triggerVueRerender() {
  // Try to find the Vue root instance
  const rootEl = document.querySelector('#app') || document.querySelector('#__nuxt');
  if (!rootEl) return;
  
  // Try to get the Vue instance
  const rootInstance = getVueInstance(rootEl);
  if (!rootInstance) return;
  
  // Try different methods to force a rerender
  try {
    // Method 1: Try to call $forceUpdate
    if (rootInstance.$forceUpdate) {
      console.log('[OCUS] Attempting to force update Vue root component');
      rootInstance.$forceUpdate();
    }
    
    // Method 2: Dispatch a window resize event (often causes rerenders)
    window.dispatchEvent(new Event('resize'));
    
    // Method 3: Add and remove a class from the root element
    rootEl.classList.add('ocus-trigger-rerender');
    setTimeout(() => rootEl.classList.remove('ocus-trigger-rerender'), 50);
  } catch (error) {
    console.error('[OCUS] Error attempting to trigger Vue rerender:', error);
  }
}

// Initialize when the DOM is fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initVueSupport);
} else {
  initVueSupport();
}
