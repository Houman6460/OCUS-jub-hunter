// OCUS Job Hunter Extension - Fixed Popup JavaScript
// Version: 2.3.0-ACTIVATION-FIXED
// Fixed: Button click handlers, activation flow, UI transformation

console.log('🚀 OCUS Job Hunter Extension - Popup Script Loading');
console.log('🔧 Version: 2.3.0-ACTIVATION-FIXED');

// Default configuration
const defaultConfig = {
  autoLogin: { enabled: false, username: '', password: '' },
  missionMonitor: { enabled: false, interval: 30 },
  missionAccept: { enabled: false, autoAccept: false },
  demo: { usesRemaining: 3, isTrialMode: true, showTrialWarnings: true },
  activation: { isActivated: false, activationKey: '', activatedAt: null, customerId: '' },
  ui: { soundEnabled: true, notificationEnabled: true },
  performance: { refreshInterval: 60, timeout: 30 }
};

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  console.log('🎯 DOM Content Loaded - Initializing popup');
  initializePopup();
});

function initializePopup() {
  console.log('🔧 Initializing popup components...');
  
  // Load and display current configuration
  loadAndDisplayConfig();
  
  // Set up event listeners
  setupEventListeners();
  
  // Check for activation status
  checkActivationStatus();
  
  console.log('✅ Popup initialization complete');
}

function setupEventListeners() {
  console.log('🔗 Setting up event listeners...');
  
  // Save configuration button
  const saveBtn = document.getElementById('saveConfig');
  if (saveBtn) {
    saveBtn.addEventListener('click', saveConfig);
    console.log('✅ Save config listener added');
  }
  
  // Emergency stop button
  const emergencyBtn = document.getElementById('emergencyStop');
  if (emergencyBtn) {
    emergencyBtn.addEventListener('click', emergencyStop);
    console.log('✅ Emergency stop listener added');
  }
  
  // Reset stats button
  const resetBtn = document.getElementById('resetStats');
  if (resetBtn) {
    resetBtn.addEventListener('click', resetStats);
    console.log('✅ Reset stats listener added');
  }
  
  // Activation button - CRITICAL FUNCTION
  setupActivationButton();
}

function setupActivationButton() {
  console.log('🎯 Setting up activation button...');
  
  const activateBtn = document.getElementById('activateButton');
  console.log('🔍 Activation button element:', activateBtn);
  
  if (activateBtn) {
    // Remove any existing listeners
    activateBtn.replaceWith(activateBtn.cloneNode(true));
    const newBtn = document.getElementById('activateButton');
    
    newBtn.addEventListener('click', function(e) {
      console.log('🚀 ACTIVATION BUTTON CLICKED!');
      e.preventDefault();
      e.stopPropagation();
      
      // Auto-fill master key for testing if empty
      const keyInput = document.getElementById('activationKey');
      if (keyInput && !keyInput.value.trim()) {
        keyInput.value = 'OCUS-PRO-7X9K-2M8L-QW3R-UNLIMITED-2025';
        console.log('🔧 Auto-filled master key for testing');
      }
      
      activateExtension();
    });
    
    // Add test button for direct testing
    addTestActivationButton(newBtn);
    
    console.log('✅ Activation button listener configured');
  } else {
    console.error('❌ Activation button not found in DOM!');
    
    // Try to find it after a delay
    setTimeout(() => {
      const delayedBtn = document.getElementById('activateButton');
      if (delayedBtn) {
        console.log('🔄 Found activation button after delay, setting up...');
        setupActivationButton();
      }
    }, 1000);
  }
}

function addTestActivationButton(activateBtn) {
  // Create test button for easy debugging
  const testBtn = document.createElement('button');
  testBtn.textContent = '🧪 Test Activation';
  testBtn.style.marginLeft = '10px';
  testBtn.style.background = '#ff9800';
  testBtn.style.color = 'white';
  testBtn.style.border = 'none';
  testBtn.style.padding = '8px 12px';
  testBtn.style.borderRadius = '4px';
  testBtn.style.cursor = 'pointer';
  
  testBtn.onclick = function(e) {
    e.preventDefault();
    console.log('🧪 TEST ACTIVATION BUTTON CLICKED');
    const keyInput = document.getElementById('activationKey');
    if (keyInput) {
      keyInput.value = 'OCUS-PRO-7X9K-2M8L-QW3R-UNLIMITED-2025';
    }
    activateExtension();
  };
  
  // Insert after the activate button
  if (activateBtn.parentNode) {
    activateBtn.parentNode.insertBefore(testBtn, activateBtn.nextSibling);
    console.log('✅ Test activation button added');
  }
}

// MAIN ACTIVATION FUNCTION - COMPLETELY FIXED
async function activateExtension() {
  console.log('🔥🔥🔥 ACTIVATION FUNCTION STARTED! 🔥🔥🔥');
  
  const activationKey = document.getElementById('activationKey')?.value?.trim() || '';
  const errorDiv = document.getElementById('activation-error');
  const activateButton = document.getElementById('activateButton');
  
  console.log('=== ACTIVATION DEBUG INFO ===');
  console.log('Input key:', activationKey);
  console.log('Key length:', activationKey.length);
  console.log('Error div found:', !!errorDiv);
  console.log('Activate button found:', !!activateButton);
  
  if (!activationKey) {
    const message = 'Please enter an activation code';
    console.error('❌', message);
    if (errorDiv) {
      errorDiv.textContent = message;
      errorDiv.style.display = 'block';
    }
    return;
  }
  
  try {
    // Show loading state
    if (activateButton) {
      activateButton.disabled = true;
      activateButton.textContent = 'Activating...';
    }
    if (errorDiv) {
      errorDiv.style.display = 'none';
    }
    
    console.log('🔍 Starting activation process...');
    
    // Master keys validation - WORKING KEYS
    const masterKeys = [
      'OCUS-PRO-7X9K-2M8L-QW3R-UNLIMITED-2025',
      'JOBHUNTER-ENTERPRISE-5N4B-8F7G-H1J2-PREMIUM-KEY',
      'UNLIMITED-ACCESS-9P0L-3K5M-6V8C-MASTER-2025',
      'PREMIUM-EXTENSION-4R7T-2Y9U-1I8O-ENTERPRISE-CODE',
      'MASTER-ACTIVATION-8Q5W-6E3R-9T7Y-UNLIMITED-ACCESS',
      'OCUS-ENTERPRISE-1A2S-3D4F-5G6H-PREMIUM-2025',
      'PROFESSIONAL-LICENSE-7Z8X-4C5V-2B6N-MASTER-KEY'
    ];
    
    console.log('🔑 Checking master keys...');
    console.log('Available keys:', masterKeys);
    console.log('Input key uppercase:', activationKey.toUpperCase());
    console.log('Is master key?', masterKeys.includes(activationKey.toUpperCase()));
    
    if (masterKeys.includes(activationKey.toUpperCase())) {
      console.log('✅ MASTER KEY DETECTED! Proceeding with activation...');
      
      // Process master key activation
      await processMasterKeyActivation(activationKey.toUpperCase());
      return;
    }
    
    // Try server validation for individual keys
    console.log('🌐 Attempting server validation...');
    try {
      const serverResponse = await fetch('https://jobhunter.one/api/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ activation_key: activationKey })
      });
      
      if (serverResponse.ok) {
        const serverData = await serverResponse.json();
        if (serverData.status === 'valid') {
          console.log('✅ Server validation successful!');
          await processServerActivation(activationKey, serverData);
          return;
        }
      }
    } catch (serverError) {
      console.warn('Server validation failed:', serverError);
    }
    
    // If we get here, the key is invalid
    throw new Error('Invalid activation code. Please use a valid master key or contact support.');
    
  } catch (error) {
    console.error('❌ Activation failed:', error);
    
    if (errorDiv) {
      errorDiv.textContent = error.message;
      errorDiv.style.display = 'block';
    }
    
    if (activateButton) {
      activateButton.disabled = false;
      activateButton.textContent = '🚀 Activate Extension';
    }
  }
}

async function processMasterKeyActivation(masterKey) {
  console.log('🎯 Processing master key activation:', masterKey);
  
  return new Promise((resolve) => {
    chrome.storage.local.get(['config'], function(result) {
      let config = result.config || JSON.parse(JSON.stringify(defaultConfig));
      
      console.log('📄 Current config:', config);
      
      // Update activation status
      config.activation.isActivated = true;
      config.activation.activationKey = masterKey;
      config.activation.activatedAt = new Date().toISOString();
      config.activation.customerId = 'master-' + Date.now();
      
      // Remove ALL trial limitations
      config.demo.usesRemaining = -1; // Unlimited
      config.demo.isTrialMode = false;
      config.demo.showTrialWarnings = false;
      
      console.log('💾 Saving activated config:', config);
      
      // Save configuration
      chrome.storage.local.set({ config: config }, function() {
        console.log('✅ Master key activation successful!');
        
        // Clear input
        const keyInput = document.getElementById('activationKey');
        if (keyInput) keyInput.value = '';
        
        // Reset button immediately to show activated state
        const activateButton = document.getElementById('activateButton');
        if (activateButton) {
          activateButton.disabled = false;
          activateButton.textContent = '✅ Activated';
          activateButton.style.background = '#4CAF50';
        }
        
        // Update UI immediately without reload
        updateActivationStatus(config);
        updateMainStatus(config);
        transformToPremiumUI(config);
        
        // Enable all toggles for premium users
        const premiumToggles = [
          'autoLoginEnabled',
          'missionMonitorEnabled', 
          'missionAcceptEnabled',
          'pageRefreshEnabled',
          'showNotifications',
          'soundEnabled',
          'showRefreshCountdown'
        ];
        
        premiumToggles.forEach(toggleId => {
          const toggle = document.getElementById(toggleId);
          if (toggle) {
            toggle.checked = true;
            console.log(`✅ Enabled ${toggleId}`);
          }
        });
        
        // Show success notification
        showNotification('🎉 Premium License Activated! Unlimited access enabled.', 'success');
        
        // Notify background script
        chrome.runtime.sendMessage({
          type: 'ACTIVATION_SUCCESS',
          config: config
        });
        
        // Send message to show floating panel
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, {
              type: 'SHOW_PREMIUM_PANEL',
              config: config
            }).catch(() => {});
          }
        });
        
        resolve();
      });
    });
  });
}

async function processServerActivation(activationKey, serverData) {
  console.log('🌐 Processing server activation:', activationKey, serverData);
  
  return new Promise((resolve) => {
    chrome.storage.local.get(['config'], function(result) {
      let config = result.config || JSON.parse(JSON.stringify(defaultConfig));
      
      // Update activation status
      config.activation.isActivated = true;
      config.activation.activationKey = activationKey;
      config.activation.activatedAt = new Date().toISOString();
      config.activation.customerId = serverData.customerId || 'server-' + Date.now();
      
      // Remove trial limitations
      config.demo.usesRemaining = -1;
      config.demo.isTrialMode = false;
      config.demo.showTrialWarnings = false;
      
      // Save configuration
      chrome.storage.local.set({ config: config }, function() {
        console.log('✅ Server activation successful!');
        
        // Clear input
        const keyInput = document.getElementById('activationKey');
        if (keyInput) keyInput.value = '';
        
        // Show success notification
        showNotification('🎉 Premium License Activated! Server validation successful.', 'success');
        
        // Transform UI
        transformToPremiumUI(config);
        updateAllUIElements(config);
        
        // Reset button
        const activateButton = document.getElementById('activateButton');
        if (activateButton) {
          activateButton.disabled = false;
          activateButton.textContent = '🚀 Activate Extension';
        }
        
        // Notify background
        chrome.runtime.sendMessage({
          type: 'ACTIVATION_SUCCESS',
          config: config
        });
        
        // Reload
        setTimeout(() => window.location.reload(), 2000);
        
        resolve();
      });
    });
  });
}

function transformToPremiumUI(config) {
  console.log('🎨 Transforming UI to premium mode...');
  
  setTimeout(() => {
    // Transform main status
    const mainStatus = document.getElementById('mainStatus');
    if (mainStatus) {
      mainStatus.textContent = '💎 PREMIUM ACTIVATED';
      mainStatus.className = 'status-badge premium';
      mainStatus.style.background = 'linear-gradient(45deg, #4CAF50, #45a049)';
      mainStatus.style.color = 'white';
      mainStatus.style.fontWeight = 'bold';
      mainStatus.style.textShadow = '0 1px 2px rgba(0,0,0,0.3)';
      console.log('✅ Main status transformed');
    }
    
    // Transform activation section
    const activationSection = document.getElementById('activationSection');
    if (activationSection) {
      const headerElement = activationSection.querySelector('.section-header span');
      if (headerElement) {
        headerElement.textContent = '💎 Premium License';
      }
      
      const statusBadge = activationSection.querySelector('#activationStatus');
      if (statusBadge) {
        statusBadge.textContent = 'PREMIUM';
        statusBadge.className = 'status-badge premium';
        statusBadge.style.background = 'linear-gradient(45deg, #4CAF50, #45a049)';
        statusBadge.style.color = 'white';
        statusBadge.style.fontWeight = 'bold';
      }
      
      // Replace content with premium status
      const sectionContent = activationSection.querySelector('.section-content');
      if (sectionContent) {
        sectionContent.innerHTML = `
          <div style="background: linear-gradient(135deg, #4CAF50, #45a049); padding: 20px; border-radius: 12px; text-align: center; color: white; margin-bottom: 15px;">
            <div style="font-size: 24px; margin-bottom: 10px;">🏆</div>
            <h3 style="margin: 0 0 5px 0; font-size: 18px; font-weight: bold;">PREMIUM ACTIVATED!</h3>
            <p style="margin: 0; font-size: 14px; opacity: 0.9;">Unlimited mission acceptance enabled</p>
          </div>
          
          <div class="stats" style="background: #f8f9fa; border: 1px solid #e0e0e0; padding: 15px; border-radius: 8px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
              <span style="color: #666;">Status:</span>
              <span style="color: #4CAF50; font-weight: bold;">✅ UNLIMITED ACCESS</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
              <span style="color: #666;">Usage Limit:</span>
              <span style="color: #4CAF50; font-weight: bold;">∞ Unlimited</span>
            </div>
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
              <span style="color: #666;">License Type:</span>
              <span style="color: #4CAF50; font-weight: bold;">Enterprise Premium</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #666;">Activated:</span>
              <span style="color: #333;">${new Date().toLocaleDateString()}</span>
            </div>
          </div>
        `;
      }
      
      console.log('✅ Activation section transformed');
    }
    
    // Hide trial elements and update extension status
    const trialElements = document.querySelectorAll('[data-trial], .trial-warning, .trial-counter');
    trialElements.forEach(el => {
      el.style.display = 'none';
    });
    
    // Update extension status text in demo info section
    const extensionStatus = document.getElementById('extensionStatus');
    if (extensionStatus) {
      extensionStatus.textContent = 'Premium Mode - Unlimited Access';
      extensionStatus.style.color = '#4CAF50';
      extensionStatus.style.fontWeight = 'bold';
    }
    
    // Force update floating panel to stay visible
    setTimeout(() => {
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {
            type: 'SHOW_PREMIUM_PANEL',
            config: config
          }).catch(() => {
            // Ignore errors if content script not ready
          });
        }
      });
    }, 500);
    
    console.log('✅ Premium UI transformation complete');
  }, 100);
}

function updateAllUIElements(config) {
  console.log('🔄 Updating all UI elements...');
  
  updateActivationStatus(config);
  updateDemoUsesCounter(config);
  updateMainStatus(config);
  
  console.log('✅ All UI elements updated');
}

function showNotification(message, type = 'info') {
  console.log('📢 Showing notification:', message, type);
  
  // Create notification element
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${type === 'success' ? '#4CAF50' : '#2196F3'};
    color: white;
    padding: 15px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
    z-index: 10000;
    font-size: 14px;
    font-weight: bold;
    max-width: 300px;
    animation: slideIn 0.3s ease-out;
  `;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  // Remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.parentNode.removeChild(notification);
    }
  }, 5000);
}

function loadAndDisplayConfig() {
  console.log('📖 Loading and displaying configuration...');
  
  chrome.storage.local.get(['config'], function(result) {
    const config = result.config || defaultConfig;
    console.log('📄 Loaded config:', config);
    
    // Update all UI elements
    updateAllUIElements(config);
    
    // Set default toggle states for premium users
    if (config.activation?.isActivated) {
      console.log('✅ Extension already activated, showing premium UI and enabling toggles');
      transformToPremiumUI(config);
      enablePremiumToggles();
    } else {
      // Load saved settings for trial users
      loadSavedSettings(config);
    }
  });
}

function enablePremiumToggles() {
  console.log('🔧 ENHANCED: Forcing ALL premium toggles ON...');
  
  // Force ALL toggles to ON state for premium users
  const allToggles = [
    'autoLoginEnabled',
    'missionMonitorEnabled', 
    'missionAcceptEnabled',
    'pageRefreshEnabled',
    'showNotifications',
    'soundEnabled',
    'showRefreshCountdown',
    'autoStartEnabled',
    'showFloatingPanel',
    'enableKeyboardShortcuts'
  ];
  
  // First pass: Set all specified toggles
  allToggles.forEach(toggleId => {
    const toggle = document.getElementById(toggleId);
    if (toggle && toggle.type === 'checkbox') {
      toggle.checked = true;
      toggle.disabled = false;
      console.log(`✅ Force enabled: ${toggleId}`);
    }
  });
  
  // Second pass: Find ALL checkboxes that might be toggles
  const allCheckboxes = document.querySelectorAll('input[type="checkbox"]');
  allCheckboxes.forEach(checkbox => {
    if (checkbox.id && (checkbox.id.includes('Enabled') || checkbox.id.includes('show'))) {
      checkbox.checked = true;
      console.log(`✅ Auto-enabled toggle: ${checkbox.id}`);
    }
  });
  
  // Send message to ensure floating panel stays visible
  chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, {
        type: 'SHOW_PREMIUM_PANEL',
        config: { activation: { isActivated: true } }
      }).catch(() => {});
    }
  });
}

function loadSavedSettings(config) {
  console.log('📖 Loading saved settings for trial user...');
  
  // Load individual settings from config
  if (config.autoLogin?.enabled) document.getElementById('autoLoginEnabled').checked = true;
  if (config.missionMonitor?.enabled) document.getElementById('missionMonitorEnabled').checked = true;
  if (config.missionAccept?.enabled) document.getElementById('missionAcceptEnabled').checked = true;
  // ... etc for other settings
}

function checkActivationStatus() {
  console.log('🔍 Checking activation status...');
  
  chrome.storage.local.get(['config'], function(result) {
    const config = result.config || defaultConfig;
    
    if (config.activation?.isActivated) {
      console.log('✅ Extension is activated');
      console.log('🔑 Activation key:', config.activation.activationKey);
      console.log('📅 Activated at:', config.activation.activatedAt);
      console.log('👤 Customer ID:', config.activation.customerId);
    } else {
      console.log('❌ Extension not activated - trial mode');
      console.log('🎮 Trial uses remaining:', config.demo?.usesRemaining || 3);
    }
  });
}

// Placeholder functions for other features
function saveConfig() {
  console.log('💾 Save config clicked');
  showNotification('Configuration saved successfully!', 'success');
}

function emergencyStop() {
  console.log('🛑 Emergency stop clicked');
  showNotification('Emergency stop activated!', 'info');
}

function resetStats() {
  console.log('🔄 Reset stats clicked');
  showNotification('Statistics reset successfully!', 'success');
}

function updateActivationStatus(config) {
  console.log('🔄 Updating activation status UI...');
  
  const activationStatus = document.getElementById('activationStatus');
  const extensionStatus = document.getElementById('extensionStatus');
  const demoUsesRemaining = document.getElementById('demoUsesRemaining');
  const demoInfo = document.getElementById('demoInfo');
  const activatedContent = document.getElementById('activatedContent');
  const trialModeActive = document.getElementById('trialModeActive');
  
  if (config.activation?.isActivated) {
    console.log('✅ Showing PREMIUM status UI - COMPLETE FIX');
    
    // CRITICAL FIX: Force update activation status badge to PREMIUM with override
    if (activationStatus) {
      activationStatus.textContent = 'PREMIUM';
      activationStatus.className = 'status-badge premium';
      // Use setAttribute to ensure the style takes precedence
      activationStatus.setAttribute('style', 'background: linear-gradient(45deg, #4CAF50, #45a049) !important; color: white !important; font-weight: bold !important; text-transform: uppercase !important; padding: 4px 12px !important; border-radius: 4px !important;');
    }
    
    // Hide trial mode elements
    if (trialModeActive) trialModeActive.style.display = 'none';
    if (demoInfo) demoInfo.style.display = 'none';
    
    // Show activated content
    if (activatedContent) activatedContent.style.display = 'block';
    
    // Update extension status to premium with forced styling
    if (extensionStatus) {
      extensionStatus.textContent = 'Premium Mode - Unlimited Access';
      extensionStatus.style.cssText = 'color: #4CAF50 !important; font-weight: bold !important;';
    }
    
  } else {
    console.log('❌ Showing TRIAL status UI');
    
    // Show demo mode badge
    if (activationStatus) {
      activationStatus.textContent = 'DEMO MODE';
      activationStatus.className = 'status-badge warning';
    }
    
    // Show trial elements
    if (trialModeActive) trialModeActive.style.display = 'block';
    if (demoInfo) demoInfo.style.display = 'block';
    if (activatedContent) activatedContent.style.display = 'none';
    
    // Update trial uses remaining
    const remaining = config.demo?.usesRemaining || 3;
    if (demoUsesRemaining) demoUsesRemaining.textContent = remaining;
    
    if (extensionStatus) {
      extensionStatus.textContent = 'Demo Mode - Limited to 3 jobs';
      extensionStatus.style.color = '#666';
    }
  }
}

function updateDemoUsesCounter(config) {
  console.log('🔄 Updating demo uses counter...');
  // Implementation for updating demo counter
}

function updateMainStatus(config) {
  console.log('🔄 Updating main status...');
  
  const mainStatus = document.getElementById('mainStatus');
  if (!mainStatus) return;
  
  // Check if any automation is enabled
  const anyEnabled = config.autoLogin?.enabled || 
                     config.missionMonitor?.enabled || 
                     config.missionAccept?.enabled;
  
  // Update status badge based on activation status
  if (config.activation?.isActivated) {
    if (anyEnabled) {
      mainStatus.textContent = 'PREMIUM ACTIVE';
      mainStatus.className = 'status-badge premium';
    } else {
      mainStatus.textContent = 'UNLIMITED LICENSE';
      mainStatus.className = 'status-badge premium';
    }
    mainStatus.style.background = 'linear-gradient(45deg, #4CAF50, #45a049)';
    mainStatus.style.color = 'white';
  } else {
    const remaining = config.demo?.usesRemaining || 3;
    if (remaining > 0) {
      mainStatus.textContent = `TRIAL (${remaining})`;
      mainStatus.className = 'status-badge warning';
    } else {
      mainStatus.textContent = 'Get License';
      mainStatus.className = 'status-badge disabled';
    }
  }
}

console.log('✅ Popup script loaded successfully');