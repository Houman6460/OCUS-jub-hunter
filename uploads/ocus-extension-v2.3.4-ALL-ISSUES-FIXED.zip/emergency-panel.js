/**
 * OCUS Unified Extension - Emergency Panel
 * 
 * Creates a panel for emergency controls and status information.
 * Runs at document_start to ensure it's available as soon as possible.
 */

(function() {
  // Create styles for the emergency panel
  const style = document.createElement('style');
  style.textContent = `
    #ocus-emergency-panel {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.8);
      color: white;
      border-radius: 8px;
      padding: 10px 15px;
      font-family: Arial, sans-serif;
      font-size: 12px;
      z-index: 999999;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
      transition: transform 0.3s, opacity 0.3s;
      transform: translateY(0);
      opacity: 0;
      pointer-events: none;
      max-width: 300px;
    }
    #ocus-emergency-panel.visible {
      opacity: 1;
      pointer-events: auto;
    }
    #ocus-emergency-panel.minimized {
      transform: translateY(calc(100% - 30px));
    }
    #ocus-emergency-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 8px;
      cursor: pointer;
    }
    #ocus-emergency-title {
      font-weight: bold;
      color: #ffeb3b;
    }
    #ocus-emergency-controls {
      display: flex;
    }
    #ocus-emergency-content {
      margin-top: 10px;
    }
    .ocus-emergency-status {
      margin: 5px 0;
      display: flex;
      justify-content: space-between;
    }
    .ocus-emergency-button {
      background: #2196F3;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 5px 8px;
      margin: 5px 3px;
      cursor: pointer;
      font-size: 11px;
      transition: background 0.2s;
    }
    .ocus-emergency-button:hover {
      background: #1976D2;
    }
    .ocus-emergency-button.danger {
      background: #F44336;
    }
    .ocus-emergency-button.danger:hover {
      background: #D32F2F;
    }
    .ocus-emergency-button.success {
      background: #4CAF50;
    }
    .ocus-emergency-button.success:hover {
      background: #388E3C;
    }
  `;
  
  // Add style to document head using ensureHead if available or with fallback
  if (window.ocusGlobals && typeof window.ocusGlobals.ensureHead === 'function') {
    // Use our document-head-fix.js utility if available
    const head = window.ocusGlobals.ensureHead();
    if (head) {
      head.appendChild(style);
    }
  } else if (document.head) {
    // Direct append if head is available
    document.head.appendChild(style);
  } else {
    console.warn('Emergency panel could not append style: document.head is null');
    // Set up a retry mechanism
    const appendStyleLater = function() {
      if (document.head) {
        document.head.appendChild(style);
        return true;
      }
      return false;
    };
    
    // Try a few times with increasing delays
    setTimeout(() => {
      if (!appendStyleLater()) {
        setTimeout(() => {
          if (!appendStyleLater()) {
            setTimeout(appendStyleLater, 500);
          }
        }, 250);
      }
    }, 100);
  }
  
  // Variables to track panel state
  let panelVisible = false;
  let panelMinimized = false;
  let panel = null;
  
  // Create the emergency panel
  function createEmergencyPanel() {
    if (panel) return;
    
    panel = document.createElement('div');
    panel.id = 'ocus-emergency-panel';
    
    // Header with title and controls
    const header = document.createElement('div');
    header.id = 'ocus-emergency-header';
    
    const title = document.createElement('div');
    title.id = 'ocus-emergency-title';
    title.textContent = 'OCUS Emergency Controls';
    
    const controls = document.createElement('div');
    controls.id = 'ocus-emergency-controls';
    
    header.appendChild(title);
    header.appendChild(controls);
    
    // Toggle minimize/maximize
    header.addEventListener('click', () => {
      panelMinimized = !panelMinimized;
      panel.classList.toggle('minimized', panelMinimized);
    });
    
    // Content area
    const content = document.createElement('div');
    content.id = 'ocus-emergency-content';
    
    // Status information
    const loginStatus = createStatusElement('Login', 'Unknown');
    const monitorStatus = createStatusElement('Mission Monitor', 'Unknown');
    const acceptStatus = createStatusElement('Auto Accept', 'Unknown');
    
    content.appendChild(loginStatus.container);
    content.appendChild(monitorStatus.container);
    content.appendChild(acceptStatus.container);
    
    // Control buttons
    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.justifyContent = 'space-between';
    buttonContainer.style.marginTop = '10px';
    
    // Toggle Auto Login button
    const toggleLoginButton = document.createElement('button');
    toggleLoginButton.className = 'ocus-emergency-button';
    toggleLoginButton.textContent = 'Toggle Login';
    toggleLoginButton.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleFeature('autoLogin');
    });
    
    // Toggle Mission Monitor button
    const toggleMonitorButton = document.createElement('button');
    toggleMonitorButton.className = 'ocus-emergency-button';
    toggleMonitorButton.textContent = 'Toggle Monitor';
    toggleMonitorButton.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleFeature('missionMonitor');
    });
    
    // Toggle Auto Accept button
    const toggleAcceptButton = document.createElement('button');
    toggleAcceptButton.className = 'ocus-emergency-button';
    toggleAcceptButton.textContent = 'Toggle Accept';
    toggleAcceptButton.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleFeature('missionAccept');
    });
    
    // Emergency stop button
    const stopAllButton = document.createElement('button');
    stopAllButton.className = 'ocus-emergency-button danger';
    stopAllButton.textContent = '⚠️ STOP ALL';
    stopAllButton.addEventListener('click', (e) => {
      e.stopPropagation();
      stopAllAutomation();
    });
    
    buttonContainer.appendChild(toggleLoginButton);
    buttonContainer.appendChild(toggleMonitorButton);
    buttonContainer.appendChild(toggleAcceptButton);
    buttonContainer.appendChild(stopAllButton);
    
    content.appendChild(buttonContainer);
    
    // Assemble panel
    panel.appendChild(header);
    panel.appendChild(content);
    
    // Add to document
    document.body.appendChild(panel);
    
    // Update status information
    updateStatusInformation();
    
    // Function to update status elements based on configuration
    function updateStatusInformation() {
      chrome.storage.local.get(['config'], (result) => {
        if (result && result.config) {
          const config = result.config;
          
          // Update status text and colors
          loginStatus.value.textContent = config.autoLogin?.enabled ? 'Enabled' : 'Disabled';
          loginStatus.value.style.color = config.autoLogin?.enabled ? '#4CAF50' : '#F44336';
          
          monitorStatus.value.textContent = config.missionMonitor?.enabled ? 'Enabled' : 'Disabled';
          monitorStatus.value.style.color = config.missionMonitor?.enabled ? '#4CAF50' : '#F44336';
          
          acceptStatus.value.textContent = config.missionAccept?.enabled ? 'Enabled' : 'Disabled';
          acceptStatus.value.style.color = config.missionAccept?.enabled ? '#4CAF50' : '#F44336';
        }
      });
    }
    
    // Listen for configuration updates
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'CONFIG_UPDATED') {
        updateStatusInformation();
      }
    });
    
    // Update status every 5 seconds
    setInterval(updateStatusInformation, 5000);
  }
  
  // Helper function to create a status element
  function createStatusElement(label, value) {
    const container = document.createElement('div');
    container.className = 'ocus-emergency-status';
    
    const labelElement = document.createElement('div');
    labelElement.textContent = label + ':';
    
    const valueElement = document.createElement('div');
    valueElement.textContent = value;
    
    container.appendChild(labelElement);
    container.appendChild(valueElement);
    
    return {
      container,
      label: labelElement,
      value: valueElement
    };
  }
  
  // Toggle a specific feature
  function toggleFeature(featureKey) {
    chrome.storage.local.get(['config'], (result) => {
      if (result && result.config) {
        const config = result.config;
        
        // Toggle the feature if it exists
        if (config[featureKey]) {
          config[featureKey].enabled = !config[featureKey].enabled;
          
          // Update configuration
          chrome.storage.local.set({ config }, () => {
            // Notify about configuration update
            chrome.runtime.sendMessage({
              type: 'UPDATE_CONFIG',
              config: config
            });
          });
        }
      }
    });
  }
  
  // Stop all automation features
  function stopAllAutomation() {
    chrome.storage.local.get(['config'], (result) => {
      if (result && result.config) {
        const config = result.config;
        
        // Disable all features
        if (config.autoLogin) config.autoLogin.enabled = false;
        if (config.missionMonitor) config.missionMonitor.enabled = false;
        if (config.missionAccept) config.missionAccept.enabled = false;
        
        // Update configuration
        chrome.storage.local.set({ config }, () => {
          // Notify about configuration update
          chrome.runtime.sendMessage({
            type: 'UPDATE_CONFIG',
            config: config
          });
          
          // Show notification
          chrome.runtime.sendMessage({
            type: 'SEND_NOTIFICATION',
            title: 'Emergency Stop',
            message: 'All automation features have been disabled',
            priority: 2
          });
        });
      }
    });
  }
  
  // Show/hide the emergency panel
  function toggleEmergencyPanel() {
    if (!panel) {
      createEmergencyPanel();
    }
    
    panelVisible = !panelVisible;
    panel.classList.toggle('visible', panelVisible);
  }
  
  // Create panel when DOM is ready and show immediately
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(() => {
        createEmergencyPanel();
        // Show panel immediately for premium users
        chrome.storage.local.get(['config'], (result) => {
          if (result?.config?.activation?.isActivated) {
            console.log('🎯 Premium user - showing emergency panel immediately');
            if (panel) {
              panelVisible = true;
              panel.classList.add('visible');
            }
          }
        });
      }, 500); // Reduced delay from 1000ms to 500ms
    });
  } else {
    setTimeout(() => {
      createEmergencyPanel();
      // Show panel immediately for premium users
      chrome.storage.local.get(['config'], (result) => {
        if (result?.config?.activation?.isActivated) {
          console.log('🎯 Premium user - showing emergency panel immediately');
          if (panel) {
            panelVisible = true;
            panel.classList.add('visible');
          }
        }
      });
    }, 500); // Reduced delay from 1000ms to 500ms
  }
  
  // Add keyboard shortcut to show/hide panel (Alt+E)
  document.addEventListener('keydown', function(e) {
    if (e.altKey && e.key.toLowerCase() === 'e') {
      toggleEmergencyPanel();
      e.preventDefault();
    }
  });
})();
