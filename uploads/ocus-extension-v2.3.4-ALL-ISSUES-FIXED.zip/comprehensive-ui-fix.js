// COMPREHENSIVE UI FIX FOR OCUS EXTENSION
// This file contains all the fixes needed to properly transform UI from trial to premium mode

// 1. Fix the processMasterKeyActivation to update UI immediately without reload
function fixProcessMasterKeyActivation() {
  // Find and replace the existing processMasterKeyActivation function
  const originalCode = `
        // Reload popup to show premium UI
        setTimeout(() => {
          console.log('🔄 Reloading popup to show premium UI...');
          window.location.reload();
        }, 2000);
  `;
  
  const fixedCode = `
        // Update UI immediately without reload
        updateActivationStatus(config);
        updateMainStatus(config);
        transformToPremiumUI(config);
        enablePremiumToggles();
        
        // Show success message
        const activateButton = document.getElementById('activateButton');
        if (activateButton) {
          activateButton.textContent = '✅ Premium Activated!';
          activateButton.style.background = '#4CAF50';
        }
  `;
}

// 2. Enhanced updateActivationStatus that forces PREMIUM badge
function enhancedUpdateActivationStatus(config) {
  console.log('🔄 ENHANCED: Updating activation status UI...');
  
  const activationStatus = document.getElementById('activationStatus');
  const extensionStatus = document.getElementById('extensionStatus');
  const trialModeActive = document.getElementById('trialModeActive');
  const trialMode = document.getElementById('trialMode');
  const activationForm = document.getElementById('activationForm');
  const demoInfo = document.getElementById('demoInfo');
  const activatedContent = document.getElementById('activatedContent');
  
  if (config.activation?.isActivated) {
    console.log('✅ PREMIUM MODE ACTIVE - Forcing all UI updates');
    
    // CRITICAL: Force PREMIUM badge with highest priority styling
    if (activationStatus) {
      activationStatus.textContent = 'PREMIUM';
      activationStatus.className = 'status-badge premium';
      activationStatus.setAttribute('style', 'background: linear-gradient(45deg, #4CAF50, #45a049) !important; color: white !important; font-weight: bold !important; text-transform: uppercase !important;');
    }
    
    // Hide ALL trial-related elements
    const trialElements = [trialModeActive, trialMode, activationForm, demoInfo];
    trialElements.forEach(el => {
      if (el) {
        el.style.display = 'none !important';
        el.style.visibility = 'hidden !important';
      }
    });
    
    // Show premium content
    if (activatedContent) {
      activatedContent.style.display = 'block !important';
    }
    
    // Force extension status to premium
    if (extensionStatus) {
      extensionStatus.textContent = 'Premium Mode - Unlimited Access';
      extensionStatus.setAttribute('style', 'color: #4CAF50 !important; font-weight: bold !important;');
    }
    
    // Transform entire activation section
    const activationSection = document.getElementById('activationSection');
    if (activationSection) {
      const sectionContent = activationSection.querySelector('.section-content');
      if (sectionContent) {
        sectionContent.innerHTML = `
          <div style="background: linear-gradient(135deg, #4CAF50, #45a049); padding: 20px; border-radius: 12px; text-align: center; color: white;">
            <div style="font-size: 36px; margin-bottom: 10px;">🏆</div>
            <h3 style="margin: 0 0 5px 0; font-size: 20px; font-weight: bold;">PREMIUM ACTIVATED!</h3>
            <p style="margin: 0; font-size: 14px; opacity: 0.9;">Unlimited mission acceptance enabled</p>
            <div style="margin-top: 15px; padding: 10px; background: rgba(255,255,255,0.2); border-radius: 8px;">
              <div style="font-size: 12px; margin-bottom: 5px;">License Type: Enterprise Premium</div>
              <div style="font-size: 12px;">Activated: ${new Date().toLocaleDateString()}</div>
            </div>
          </div>
        `;
      }
    }
    
  } else {
    // Trial mode display
    if (activationStatus) {
      activationStatus.textContent = 'DEMO MODE';
      activationStatus.className = 'status-badge warning';
      activationStatus.removeAttribute('style');
    }
    
    // Show trial elements
    if (trialModeActive) trialModeActive.style.display = 'block';
    if (trialMode) trialMode.style.display = 'block';
    if (activationForm) activationForm.style.display = 'block';
    if (demoInfo) demoInfo.style.display = 'block';
    if (activatedContent) activatedContent.style.display = 'none';
    
    if (extensionStatus) {
      extensionStatus.textContent = 'Demo Mode - Limited to 3 jobs';
      extensionStatus.removeAttribute('style');
    }
  }
}

// 3. Enhanced enablePremiumToggles that forces all toggles ON
function enhancedEnablePremiumToggles() {
  console.log('🔧 ENHANCED: Forcing all premium toggles ON...');
  
  // All possible toggle IDs
  const allToggles = [
    'autoLoginEnabled',
    'missionMonitorEnabled', 
    'missionAcceptEnabled',
    'pageRefreshEnabled',
    'showNotifications',
    'soundEnabled',
    'showRefreshCountdown',
    'autoStartEnabled',
    'showFloatingPanel',
    'enableKeyboardShortcuts'
  ];
  
  allToggles.forEach(toggleId => {
    const toggle = document.getElementById(toggleId);
    if (toggle && toggle.type === 'checkbox') {
      toggle.checked = true;
      toggle.disabled = false; // Ensure toggle is not disabled
      console.log(`✅ Force enabled: ${toggleId}`);
      
      // Trigger change event to update any listeners
      toggle.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });
  
  // Also ensure any toggle switches in the UI are visually ON
  const allSwitches = document.querySelectorAll('input[type="checkbox"]');
  allSwitches.forEach(switchEl => {
    if (switchEl.id && switchEl.id.includes('Enabled')) {
      switchEl.checked = true;
    }
  });
}

// 4. Export the enhanced functions to be used in popup.js
window.ocusUIFixes = {
  updateActivationStatus: enhancedUpdateActivationStatus,
  enablePremiumToggles: enhancedEnablePremiumToggles
};