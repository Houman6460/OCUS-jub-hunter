/**
 * OCUS Unified Extension - Configuration
 * 
 * Central configuration file for API endpoints and settings
 */

const EXTENSION_CONFIG = {
  // API Configuration
  API: {
    BASE_URL: 'http://localhost:5000/api', // Will be updated for production
    ENDPOINTS: {
      ACTIVATE: '/activate',
      CHECK_DEMO: '/check-demo'
    },
    TIMEOUT: 5000 // 5 second timeout
  },

  // Demo Configuration
  DEMO: {
    MAX_USES: 3,
    STORAGE_KEY: 'demo_usage_data'
  },

  // Activation Configuration
  ACTIVATION: {
    STORAGE_KEY: 'activation_key_data'
  },

  // User ID Configuration
  USER_ID: {
    STORAGE_KEY: 'extension_user_id'
  },

  // Extension Status
  STATUS: {
    STORAGE_KEY: 'extension_status'
  }
};

// Make config available globally
if (typeof window !== 'undefined') {
  window.EXTENSION_CONFIG = EXTENSION_CONFIG;
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = EXTENSION_CONFIG;
}