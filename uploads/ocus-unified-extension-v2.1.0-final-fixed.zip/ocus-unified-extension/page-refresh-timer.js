/**
 * OCUS Unified Extension - Page Refresh Timer
 * 
 * Adds an automatic page refresh timer with a countdown panel to the OCUS website.
 * The timer refreshes the page at intervals set by the user in the extension popup.
 */

(function() {
  'use strict';
  
  // Configuration defaults
  let config = {
    enabled: false,
    intervalSeconds: 30,
    showCountdown: true
  };
  
  // Timer variables
  let refreshTimer = null;
  let countdownTimer = null;
  let secondsLeft = 0;
  let countdownPanel = null;
  let statsPanel = null;
  let isPaused = false;
  
  // Stats variables
  let stats = {
    missionsFound: 0,
    missionsOpened: 0,
    missionsAccepted: 0,
    loginAttempts: 0,
    lastRefreshTime: null,
    totalRefreshes: 0
  };
  
  // Drag state variables
  let isDragging = false;
  let currentDragElement = null;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  
  // Panel position defaults (will be overridden by stored values if available)
  let panelPositions = {
    countdownPanel: { right: '20px', bottom: '20px' },
    statsPanel: { right: '210px', bottom: '20px' }
  };
  
  // Debug mode for easier troubleshooting
  const DEBUG = true;
  
  // Log function that only outputs when debug is enabled
  function log(...args) {
    if (DEBUG) {
      console.log('[OCUS Refresh Timer]', ...args);
    }
  }
  
  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
  
  // Load statistics from storage every minute
  setInterval(loadStats, 60000);
  
  // Initialize the refresh timer functionality
  function init() {
    log('Initializing...');
    
    // Load saved panel positions first
    loadPanelPositions(() => {
      // Create the countdown panel
      createCountdownPanel();
      
      // Create the statistics panel
      createStatsPanel();
      
      // Set up global drag event handlers
      setupDragHandlers();
      
      // Load initial stats
      loadStats();
    });
    
    // Load configuration from storage
    try {
      chrome.storage.local.get(['config'], function(result) {
        log('Configuration loaded from storage:', result);
        
        if (result.config && result.config.pageRefresh) {
          config = result.config.pageRefresh;
          log('Page Refresh Timer configuration:', config);
          
          // Initialize the timer if enabled
          if (config.enabled) {
            log('Auto-refresh is enabled, starting timer');
            startRefreshTimer();
          } else {
            log('Auto-refresh is disabled');
            hideCountdownPanel();
          }
        } else {
          log('No page refresh configuration found in storage');
        }
      });
    } catch (error) {
      console.error('[OCUS Refresh Timer] Error loading configuration:', error);
    }
    
    // Listen for configuration updates
    try {
      chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
        log('Message received:', message);
        
        if (message.type === 'UPDATE_CONFIG' && message.config && message.config.pageRefresh) {
          const newConfig = message.config.pageRefresh;
          log('New refresh configuration:', newConfig);
          
          // Check if enabled state changed
          if (newConfig.enabled !== config.enabled) {
            if (newConfig.enabled) {
              // Start timer if newly enabled
              log('Timer enabled, starting...');
              config = newConfig;
              startRefreshTimer();
            } else {
              // Stop timer if newly disabled
              log('Timer disabled, stopping...');
              stopRefreshTimer();
              hideCountdownPanel();
            }
          } 
          // Check if interval changed
          else if (newConfig.enabled && newConfig.intervalSeconds !== config.intervalSeconds) {
            // Restart timer with new interval
            log('Refresh interval changed, restarting timer...');
            config = newConfig;
            restartRefreshTimer();
          }
          // Check if countdown visibility changed
          else if (newConfig.showCountdown !== config.showCountdown) {
            config = newConfig;
            if (config.showCountdown) {
              log('Showing countdown panel');
              showCountdownPanel();
            } else {
              log('Hiding countdown panel');
              hideCountdownPanel();
            }
          }
          
          config = newConfig;
          
          // Send response to confirm receipt
          if (sendResponse) {
            sendResponse({success: true});
          }
          
          return true; // Keep channel open for async response
        }
      });
      
      // Send a ready message to the background script
      chrome.runtime.sendMessage({type: 'PAGE_REFRESH_READY'}, function(response) {
        log('Sent ready message, response:', response);
      });
    } catch (error) {
      console.error('[OCUS Refresh Timer] Error setting up message listener:', error);
    }
  }
  
  // Create the countdown panel element
  function createCountdownPanel() {
    // Check if panel already exists
    if (document.getElementById('ocus-refresh-countdown')) {
      return;
    }
    
    // Create panel elements
    countdownPanel = document.createElement('div');
    countdownPanel.id = 'ocus-refresh-countdown';
    countdownPanel.className = 'ocus-refresh-countdown';
    
    // Create panel content
    countdownPanel.innerHTML = `
      <div class="ocus-countdown-header" draggable="true">
        <span>Page Refresh</span>
        <button class="ocus-countdown-close" title="Close">&times;</button>
      </div>
      <div class="ocus-countdown-body">
        <div class="ocus-countdown-timer">
          <span id="ocus-seconds-left">0</span>s
        </div>
        <div class="ocus-countdown-controls">
          <button id="ocus-pause-refresh" class="ocus-btn">Pause</button>
          <button id="ocus-refresh-now" class="ocus-btn">Refresh Now</button>
        </div>
      </div>
    `;
    
    // Apply saved position if available
    if (panelPositions.countdownPanel) {
      Object.keys(panelPositions.countdownPanel).forEach(prop => {
        countdownPanel.style[prop] = panelPositions.countdownPanel[prop];
      });
    }
    
    // Add styles
    const style = document.createElement('style');
    style.textContent = `
      .ocus-refresh-countdown {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 180px;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        z-index: 9999;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        transition: opacity 0.3s ease;
      }
      
      .ocus-countdown-header,
      .ocus-stats-header {
        cursor: move;
        user-select: none;
      }
      
      .ocus-countdown-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 12px;
        background: #2196F3;
        color: white;
        border-radius: 5px 5px 0 0;
        font-weight: 500;
        font-size: 14px;
      }
      
      .ocus-countdown-close {
        background: none;
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
        padding: 0;
        line-height: 1;
      }
      
      .ocus-countdown-body {
        padding: 12px;
      }
      
      .ocus-countdown-timer {
        text-align: center;
        font-size: 24px;
        font-weight: bold;
        margin-bottom: 10px;
      }
      
      .ocus-countdown-controls {
        display: flex;
        gap: 5px;
      }
      
      .ocus-btn {
        flex: 1;
        padding: 5px;
        border: 1px solid #ddd;
        background: #f5f5f5;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
        transition: background 0.2s;
      }
      
      .ocus-btn:hover {
        background: #e0e0e0;
      }
      
      .ocus-hidden {
        opacity: 0;
        pointer-events: none;
      }
      
      /* Stats Panel Styles */
      .ocus-stats-panel {
        position: fixed;
        bottom: 20px;
        right: 210px;
        width: 220px;
        background: #fff;
        border: 1px solid #ddd;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        z-index: 9999;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        transition: opacity 0.3s ease;
      }
      
      .ocus-stats-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px 12px;
        background: #4CAF50;
        color: white;
        border-radius: 5px 5px 0 0;
        font-weight: 500;
        font-size: 14px;
      }
      
      .ocus-stats-close {
        background: none;
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
        padding: 0;
        line-height: 1;
      }
      
      .ocus-stats-body {
        padding: 12px;
      }
      
      .ocus-stats-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        font-size: 13px;
      }
      
      .ocus-stats-label {
        color: #555;
      }
      
      .ocus-stats-value {
        font-weight: bold;
        color: #333;
      }
      
      .ocus-stats-footer {
        display: flex;
        justify-content: center;
        padding: 8px 0 0;
        font-size: 11px;
        color: #777;
        border-top: 1px solid #eee;
        margin-top: 4px;
      }
    `;
    
    // Add to document
    document.head.appendChild(style);
    document.body.appendChild(countdownPanel);
    
    // Add event listeners
    document.getElementById('ocus-pause-refresh').addEventListener('click', togglePauseRefresh);
    document.getElementById('ocus-refresh-now').addEventListener('click', refreshNow);
    document.querySelector('.ocus-countdown-close').addEventListener('click', function() {
      hideCountdownPanel();
    });
    
    // Hide by default
    hideCountdownPanel();
  }
  
  // Start the refresh timer
  function startRefreshTimer() {
    // Clear any existing timer
    stopRefreshTimer();
    
    // Reset pause state
    isPaused = false;
    const pauseButton = document.getElementById('ocus-pause-refresh');
    if (pauseButton) {
      pauseButton.textContent = 'Pause';
    }
    
    log(`Starting page refresh timer with interval of ${config.intervalSeconds} seconds`);
    
    // Initialize countdown
    secondsLeft = config.intervalSeconds;
    updateCountdown();
    
    // Show the countdown panel if enabled
    if (config.showCountdown) {
      showCountdownPanel();
    }
    
    // Set up the refresh timer
    refreshTimer = setTimeout(function() {
      log('Refresh timer triggered');
      refreshPage();
    }, config.intervalSeconds * 1000);
    
    // Set up the countdown timer
    countdownTimer = setInterval(function() {
      secondsLeft--;
      updateCountdown();
      
      if (secondsLeft <= 0) {
        log('Countdown reached zero');
        clearInterval(countdownTimer);
      }
    }, 1000);
  }
  
  // Stop the refresh timer
  function stopRefreshTimer() {
    log('Stopping refresh timer');
    
    if (refreshTimer) {
      clearTimeout(refreshTimer);
      refreshTimer = null;
    }
    
    if (countdownTimer) {
      clearInterval(countdownTimer);
      countdownTimer = null;
    }
  }
  
  // Restart the refresh timer
  function restartRefreshTimer() {
    stopRefreshTimer();
    startRefreshTimer();
  }
  
  // Update the countdown display
  function updateCountdown() {
    const secondsElement = document.getElementById('ocus-seconds-left');
    if (secondsElement) {
      secondsElement.textContent = secondsLeft;
    }
  }
  
  // Show the countdown panel
  function showCountdownPanel() {
    if (countdownPanel && config.enabled) {
      countdownPanel.classList.remove('ocus-hidden');
    }
  }
  
  // Hide the countdown panel
  function hideCountdownPanel() {
    if (countdownPanel) {
      countdownPanel.classList.add('ocus-hidden');
    }
  }
  
  // Toggle pause/resume of the refresh timer
  function togglePauseRefresh() {
    const pauseButton = document.getElementById('ocus-pause-refresh');
    
    isPaused = !isPaused;
    
    if (isPaused) {
      // Pause the timer
      log('Pausing refresh timer');
      stopRefreshTimer();
      pauseButton.textContent = 'Resume';
    } else {
      // Resume the timer
      log('Resuming refresh timer');
      startRefreshTimer();
      pauseButton.textContent = 'Pause';
    }
  }
  
  // Refresh the page immediately
  function refreshNow() {
    console.log('[OCUS] Manual page refresh triggered.');
    refreshPage();
  }
  
  // Perform the page refresh
  function refreshPage() {
    log('Refreshing page now');
    
    // Update refresh statistics
    chrome.storage.local.get(['stats'], (result) => {
      const currentStats = result.stats || {
        totalClicks: 0, 
        missionsFound: 0,
        missionsOpened: 0,
        missionsAccepted: 0,
        totalRefreshes: 0,
        lastLoginTime: null,
        lastRefreshTime: null
      };
      
      currentStats.totalRefreshes = (currentStats.totalRefreshes || 0) + 1;
      currentStats.lastRefreshTime = Date.now();
      
      chrome.storage.local.set({ stats: currentStats }, () => {
        log('Updated refresh statistics');
      });
    });
    
    try {
      // Force reload from server, not from cache
      window.location.reload(true);
    } catch (error) {
      console.error('[OCUS Refresh Timer] Error refreshing page:', error);
      // Fallback method
      window.location = window.location.href;
    }
  }
  
  // Create the statistics panel element
  function createStatsPanel() {
    // Check if panel already exists
    if (document.getElementById('ocus-stats-panel')) {
      return;
    }
    
    // Create panel elements
    statsPanel = document.createElement('div');
    statsPanel.id = 'ocus-stats-panel';
    statsPanel.className = 'ocus-stats-panel';
    
    // Create panel content
    statsPanel.innerHTML = `
      <div class="ocus-stats-header" draggable="true">
        <span>OCUS Statistics</span>
        <button class="ocus-stats-close" title="Close">&times;</button>
      </div>
      <div class="ocus-stats-body">
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Missions Found:</span>
          <span class="ocus-stats-value" id="ocus-stats-found">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Missions Opened:</span>
          <span class="ocus-stats-value" id="ocus-stats-opened">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Missions Accepted:</span>
          <span class="ocus-stats-value" id="ocus-stats-accepted">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Total Refreshes:</span>
          <span class="ocus-stats-value" id="ocus-stats-refreshes">0</span>
        </div>
        <div class="ocus-stats-item">
          <span class="ocus-stats-label">Login Attempts:</span>
          <span class="ocus-stats-value" id="ocus-stats-logins">0</span>
        </div>
        <div class="ocus-stats-footer" id="ocus-stats-last-refresh">
          Last refresh: Never
        </div>
      </div>
    `;
    
    // Apply saved position if available
    if (panelPositions.statsPanel) {
      Object.keys(panelPositions.statsPanel).forEach(prop => {
        statsPanel.style[prop] = panelPositions.statsPanel[prop];
      });
    }
    
    // Add to document body
    document.body.appendChild(statsPanel);
    
    // Add event listener for close button
    document.querySelector('.ocus-stats-close').addEventListener('click', function() {
      hideStatsPanel();
    });
    
    // Add toggle button to countdown panel
    const countdownControls = document.querySelector('.ocus-countdown-controls');
    if (countdownControls) {
      const statsToggleBtn = document.createElement('button');
      statsToggleBtn.id = 'ocus-toggle-stats';
      statsToggleBtn.className = 'ocus-btn';
      statsToggleBtn.textContent = 'Stats';
      statsToggleBtn.addEventListener('click', toggleStatsPanel);
      countdownControls.appendChild(statsToggleBtn);
    }
    
    // Show by default alongside countdown
    showStatsPanel();
  }
  
  // Load statistics from storage
  function loadStats() {
    chrome.storage.local.get(['stats'], function(result) {
      if (result.stats) {
        stats = result.stats;
        updateStatsDisplay();
      }
    });
  }
  
  // Update the statistics display
  function updateStatsDisplay() {
    if (!statsPanel) return;
    
    // Update stats values
    document.getElementById('ocus-stats-found').textContent = stats.missionsFound || 0;
    document.getElementById('ocus-stats-opened').textContent = stats.missionsOpened || 0;
    document.getElementById('ocus-stats-accepted').textContent = stats.missionsAccepted || 0;
    document.getElementById('ocus-stats-refreshes').textContent = stats.totalRefreshes || 0;
    document.getElementById('ocus-stats-logins').textContent = stats.loginAttempts || 0;
    
    // Update last refresh time
    const lastRefreshEl = document.getElementById('ocus-stats-last-refresh');
    if (stats.lastRefreshTime) {
      const lastRefreshDate = new Date(stats.lastRefreshTime);
      const hours = lastRefreshDate.getHours().toString().padStart(2, '0');
      const minutes = lastRefreshDate.getMinutes().toString().padStart(2, '0');
      const seconds = lastRefreshDate.getSeconds().toString().padStart(2, '0');
      lastRefreshEl.textContent = `Last refresh: ${hours}:${minutes}:${seconds}`;
    } else {
      lastRefreshEl.textContent = 'Last refresh: Never';
    }
  }
  
  // Show statistics panel
  function showStatsPanel() {
    if (statsPanel) {
      statsPanel.classList.remove('ocus-hidden');
    }
  }
  
  // Hide statistics panel
  function hideStatsPanel() {
    if (statsPanel) {
      statsPanel.classList.add('ocus-hidden');
    }
  }
  
  // Toggle statistics panel visibility
  function toggleStatsPanel() {
    if (statsPanel) {
      if (statsPanel.classList.contains('ocus-hidden')) {
        showStatsPanel();
      } else {
        hideStatsPanel();
      }
    }
  }
  
  // Load saved panel positions from storage
  function loadPanelPositions(callback) {
    chrome.storage.local.get(['panelPositions'], function(result) {
      if (result.panelPositions) {
        panelPositions = result.panelPositions;
        log('Loaded saved panel positions:', panelPositions);
      }
      if (callback) callback();
    });
  }
  
  // Save panel positions to storage
  function savePanelPositions() {
    chrome.storage.local.set({ panelPositions }, function() {
      log('Saved panel positions:', panelPositions);
    });
  }
  
  // Setup global drag event handlers
  function setupDragHandlers() {
    // Prevent native draggable behavior which causes issues
    document.addEventListener('dragstart', function(e) {
      if (e.target.matches('.ocus-countdown-header, .ocus-stats-header')) {
        e.preventDefault();
      }
    });
    
    // Mouse down event for starting drag
    document.addEventListener('mousedown', function(e) {
      // Only handle drag on headers and not on buttons within headers
      if ((e.target.matches('.ocus-countdown-header, .ocus-stats-header') || 
           e.target.matches('.ocus-countdown-header span, .ocus-stats-header span')) && 
          !e.target.matches('button')) {
        
        // Determine which panel we're dragging
        const panel = e.target.closest('.ocus-refresh-countdown, .ocus-stats-panel');
        if (!panel) return;
        
        isDragging = true;
        currentDragElement = panel;
        
        // Calculate offset from where the mouse clicked relative to panel top-left
        const rect = panel.getBoundingClientRect();
        dragOffsetX = e.clientX - rect.left;
        dragOffsetY = e.clientY - rect.top;
        
        // Add a class to indicate dragging
        panel.classList.add('ocus-dragging');
        
        log('Started dragging panel:', panel.id);
        
        // Prevent text selection during drag
        e.preventDefault();
      }
    });
    
    // Mouse move event for dragging
    document.addEventListener('mousemove', function(e) {
      if (isDragging && currentDragElement) {
        // Calculate new position
        const newLeft = e.clientX - dragOffsetX;
        const newTop = e.clientY - dragOffsetY;
        
        // Apply new position
        currentDragElement.style.right = 'auto';
        currentDragElement.style.bottom = 'auto';
        currentDragElement.style.left = newLeft + 'px';
        currentDragElement.style.top = newTop + 'px';
        
        // Prevent text selection during drag
        e.preventDefault();
      }
    });
    
    // Mouse up event for ending drag
    document.addEventListener('mouseup', function() {
      if (isDragging && currentDragElement) {
        // Save the final positions
        const panelId = currentDragElement.id === 'ocus-refresh-countdown' ? 'countdownPanel' : 'statsPanel';
        panelPositions[panelId] = {
          left: currentDragElement.style.left,
          top: currentDragElement.style.top,
          right: 'auto',
          bottom: 'auto'
        };
        
        // Remove dragging class
        currentDragElement.classList.remove('ocus-dragging');
        
        // Save positions to storage
        savePanelPositions();
        
        log('Saved new position for', panelId);
        
        // Reset drag state
        isDragging = false;
        currentDragElement = null;
      }
    });
    
    // Add a small amount of CSS for the dragging state
    const dragStyle = document.createElement('style');
    dragStyle.textContent = `
      .ocus-dragging {
        opacity: 0.8;
        transition: none !important;
        z-index: 10000;
      }
    `;
    document.head.appendChild(dragStyle);
  }
})();
