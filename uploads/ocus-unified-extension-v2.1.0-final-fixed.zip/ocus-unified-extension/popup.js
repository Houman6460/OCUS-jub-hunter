/**
 * OCUS Unified Extension - Popup Script
 * 
 * Manages the configuration UI and provides controls for the extension.
 */

// Default configuration
const defaultConfig = {
  autoLogin: {
    enabled: false,
    username: '',
    password: '',
    maxLoginAttempts: 5
  },
  missionMonitor: {
    enabled: false,
    refreshInterval: 30000, // 30 seconds
    showNotifications: true,
    maxSimultaneousMissions: 3,
    openInNewTab: true
  },
  missionAccept: {
    enabled: false,
    autoClose: true,
    closeDelay: 2000 // 2 seconds
  },
  pageRefresh: {
    enabled: false,
    intervalSeconds: 30,
    showCountdown: true
  },
  processedMissions: []
};

// Default statistics
const defaultStats = {
  missionsFound: 0,
  missionsOpened: 0,
  missionsAccepted: 0,
  loginAttempts: 0,
  successfulLogins: 0
};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  // Load configuration and stats from storage
  loadConfigAndStats();
  
  // Set up event listeners
  document.getElementById('saveConfig').addEventListener('click', saveConfig);
  document.getElementById('emergencyStop').addEventListener('click', emergencyStop);
  document.getElementById('resetStats').addEventListener('click', resetStats);
  
  // Add event listeners for refresh timer buttons
  const refreshButtons = document.querySelectorAll('.refresh-option');
  refreshButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Get the value from the button's data attribute
      const seconds = parseInt(this.getAttribute('data-value'));
      // Set the value to the custom refresh time input
      document.getElementById('customRefreshTime').value = seconds;
    });
  });
  
  // Custom refresh time button
  document.getElementById('setCustomRefresh').addEventListener('click', function() {
    // Highlight the custom value and ensure it's valid
    const customInput = document.getElementById('customRefreshTime');
    if (customInput.value && parseInt(customInput.value) > 0) {
      // Deselect any selected refresh option buttons
      refreshButtons.forEach(btn => btn.classList.remove('selected'));
    }
  });
});

// Load configuration and stats from storage
function loadConfigAndStats() {
  // Get configuration from storage
  chrome.storage.local.get(['config', 'stats'], function(result) {
    const config = result.config || defaultConfig;
    const stats = result.stats || defaultStats;
    
    // Auto Login Configuration
    document.getElementById('autoLoginEnabled').checked = config.autoLogin?.enabled || false;
    document.getElementById('username').value = config.autoLogin?.username || '';
    document.getElementById('password').value = config.autoLogin?.password || '';
    document.getElementById('maxLoginAttempts').value = config.autoLogin?.maxLoginAttempts || 5;
    
    // Mission Monitor Configuration
    document.getElementById('missionMonitorEnabled').checked = config.missionMonitor?.enabled || false;
    document.getElementById('refreshInterval').value = (config.missionMonitor?.refreshInterval || 30000) / 1000; // Convert to seconds
    document.getElementById('showNotifications').checked = config.missionMonitor?.showNotifications || true;
    document.getElementById('maxSimultaneousMissions').value = config.missionMonitor?.maxSimultaneousMissions || 3;
    
    // Mission Acceptor Configuration
    document.getElementById('missionAcceptEnabled').checked = config.missionAccept?.enabled || false;
    document.getElementById('autoCloseTab').checked = config.missionAccept?.autoClose || true;
    document.getElementById('closeDelay').value = (config.missionAccept?.closeDelay || 2000) / 1000; // Convert to seconds
    
    // Page Refresh Timer Configuration
    document.getElementById('pageRefreshEnabled').checked = config.pageRefresh?.enabled || false;
    document.getElementById('customRefreshTime').value = config.pageRefresh?.intervalSeconds || 30;
    document.getElementById('showRefreshCountdown').checked = config.pageRefresh?.showCountdown || true;
    
    // Highlight the selected refresh time button if it matches a preset
    const presetValues = [5, 10, 20, 30];
    const refreshTime = config.pageRefresh?.intervalSeconds || 30;
    if (presetValues.includes(refreshTime)) {
      const buttons = document.querySelectorAll('.refresh-option');
      buttons.forEach(button => {
        if (parseInt(button.getAttribute('data-value')) === refreshTime) {
          button.classList.add('selected');
        }
      });
    }
    
    // Update statistics display
    document.getElementById('missionsFound').textContent = stats.missionsFound || 0;
    document.getElementById('missionsOpened').textContent = stats.missionsOpened || 0;
    document.getElementById('missionsAccepted').textContent = stats.missionsAccepted || 0;
    document.getElementById('loginAttempts').textContent = stats.loginAttempts || 0;
    document.getElementById('successfulLogins').textContent = stats.successfulLogins || 0;
    
    // Update main status badge
    updateMainStatus(config);
  });
}

// Save configuration to storage
function saveConfig() {
  // Get configuration from storage
  chrome.storage.local.get(['config'], function(result) {
    let config = result.config || defaultConfig;
    
    // Update Auto Login Configuration
    config.autoLogin = config.autoLogin || {};
    config.autoLogin.enabled = document.getElementById('autoLoginEnabled').checked;
    config.autoLogin.username = document.getElementById('username').value;
    config.autoLogin.password = document.getElementById('password').value;
    config.autoLogin.maxLoginAttempts = parseInt(document.getElementById('maxLoginAttempts').value) || 5;
    
    // Update Mission Monitor Configuration
    config.missionMonitor = config.missionMonitor || {};
    config.missionMonitor.enabled = document.getElementById('missionMonitorEnabled').checked;
    config.missionMonitor.refreshInterval = (parseInt(document.getElementById('refreshInterval').value) || 30) * 1000; // Convert to milliseconds
    config.missionMonitor.showNotifications = document.getElementById('showNotifications').checked;
    config.missionMonitor.maxSimultaneousMissions = parseInt(document.getElementById('maxSimultaneousMissions').value) || 3;
    
    // Update Mission Acceptor Configuration
    config.missionAccept = config.missionAccept || {};
    config.missionAccept.enabled = document.getElementById('missionAcceptEnabled').checked;
    config.missionAccept.autoClose = document.getElementById('autoCloseTab').checked;
    config.missionAccept.closeDelay = (parseInt(document.getElementById('closeDelay').value) || 2) * 1000; // Convert to milliseconds
    
    // Update Page Refresh Timer Configuration
    config.pageRefresh = config.pageRefresh || {};
    config.pageRefresh.enabled = document.getElementById('pageRefreshEnabled').checked;
    config.pageRefresh.intervalSeconds = parseInt(document.getElementById('customRefreshTime').value) || 30;
    config.pageRefresh.showCountdown = document.getElementById('showRefreshCountdown').checked;
    
    // Save configuration to storage
    chrome.storage.local.set({ config: config }, function() {
      // Show success notification
      showNotification('Configuration saved successfully!', 'success');
      
      // Update main status badge
      updateMainStatus(config);
      
      // Notify background script of configuration update
      chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        config: config
      });
      
      // Send message directly to the active tab
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs && tabs.length > 0) {
          console.log('Sending config update to active tab:', tabs[0].id);
          chrome.tabs.sendMessage(tabs[0].id, {
            type: 'UPDATE_CONFIG',
            config: config
          }, function(response) {
            console.log('Active tab response:', response);
          });
        }
      });
      
      // Also broadcast to all OCUS domain tabs
      chrome.tabs.query({url: ["*://app.ocus.com/*", "*://*.ocus.work/*"]}, function(tabs) {
        if (tabs && tabs.length > 0) {
          console.log('Broadcasting config update to', tabs.length, 'OCUS tabs');
          tabs.forEach(function(tab) {
            chrome.tabs.sendMessage(tab.id, {
              type: 'UPDATE_CONFIG',
              config: config
            });
          });
        } else {
          console.log('No OCUS tabs found to send configuration');
        }
      });
    });
  });
}

// Emergency stop all automation
function emergencyStop() {
  // Get configuration from storage
  chrome.storage.local.get(['config'], function(result) {
    let config = result.config || defaultConfig;
    
    // Disable all automation
    if (config.autoLogin) config.autoLogin.enabled = false;
    if (config.missionMonitor) config.missionMonitor.enabled = false;
    if (config.missionAccept) config.missionAccept.enabled = false;
    
    // Save configuration to storage
    chrome.storage.local.set({ config: config }, function() {
      // Update UI
      document.getElementById('autoLoginEnabled').checked = false;
      document.getElementById('missionMonitorEnabled').checked = false;
      document.getElementById('missionAcceptEnabled').checked = false;
      
      // Show success notification
      showNotification('All automation has been disabled!', 'error');
      
      // Update main status badge
      updateMainStatus(config);
      
      // Notify background script of configuration update
      chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        config: config
      });
      
      // Send emergency stop notification
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Emergency Stop',
        message: 'All automation has been disabled!',
        priority: 2
      });
    });
  });
}

// Reset statistics
function resetStats() {
  // Save default statistics to storage
  chrome.storage.local.set({ stats: defaultStats }, function() {
    // Update statistics display
    document.getElementById('missionsFound').textContent = 0;
    document.getElementById('missionsOpened').textContent = 0;
    document.getElementById('missionsAccepted').textContent = 0;
    document.getElementById('loginAttempts').textContent = 0;
    document.getElementById('successfulLogins').textContent = 0;
    
    // Show success notification
    showNotification('Statistics have been reset!', 'success');
  });
}

// Show notification in the popup
function showNotification(message, type) {
  const notification = document.getElementById('notification');
  notification.textContent = message;
  notification.className = 'notification ' + type;
  
  // Hide notification after 3 seconds
  setTimeout(function() {
    notification.className = 'notification';
  }, 3000);
}

// Update main status badge
function updateMainStatus(config) {
  const mainStatus = document.getElementById('mainStatus');
  
  // Check if any automation is enabled
  const anyEnabled = (config.autoLogin?.enabled || 
                     config.missionMonitor?.enabled || 
                     config.missionAccept?.enabled) || false;
  
  // Update status badge
  if (anyEnabled) {
    mainStatus.textContent = 'Active';
    mainStatus.className = 'status-badge';
  } else {
    mainStatus.textContent = 'Inactive';
    mainStatus.className = 'status-badge disabled';
  }
}
