/**
 * OCUS Unified Extension - Mission Acceptor (DEPRECATED)
 * 
 * This file has been replaced by new-mission-acceptor.js which provides
 * a more reliable implementation for accepting missions.
 * 
 * DO NOT USE OR MODIFY THIS FILE!
 * 
 * The manifest.json has been updated to reference the new implementation.
 * All functionality has been moved to new-mission-acceptor.js
 */

(function() {
  'use strict';
  
  // Warning about deprecated usage
  console.log('[OCUS] WARNING: mission-acceptor.js is deprecated, using new-mission-acceptor.js instead');
  
  // Redirect any calls to old functions to console warnings
  if (typeof window !== 'undefined') {
    // Create a proxy that warns about deprecated usage
    window.OCUS_DEPRECATED_MISSION_ACCEPTOR = {
      init: function() { 
        console.warn('[OCUS] Using deprecated mission-acceptor.js. Please update your code to use new-mission-acceptor.js');
        return false;
      },
      attemptAcceptMission: function() {
        console.warn('[OCUS] Using deprecated mission-acceptor.js. Please update your code to use new-mission-acceptor.js');
        return false;
      },
      isMissionPage: function() {
        console.warn('[OCUS] Using deprecated mission-acceptor.js. Please update your code to use new-mission-acceptor.js');
        return false; 
      }
    };
  }
})();
