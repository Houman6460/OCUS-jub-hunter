/**
 * OCUS Unified Extension - New Mission Acceptor
 * 
 * A clean implementation focused exclusively on reliably accepting missions
 * when opened in a mission page.
 */

// Configuration
const CONFIG = {
  enabled: true,
  autoRedirect: true,
  redirectDelay: 5000, // 5 seconds - as requested by user
  maxAttempts: 20,
  attemptInterval: 800, // Faster interval to ensure we catch the button quickly
  debug: true, // Set to true for detailed logging
  homepage: 'https://app.ocus.com/' // Homepage URL to redirect to after acceptance
};

// State tracking
let missionAccepted = false;
let attemptCount = 0;
let attemptTimer = null;

/**
 * Initialize the mission acceptor
 */
function init() {
  log('Mission acceptor initializing...');
  
  // Only run on mission pages
  if (!isMissionPage()) {
    log('Not a mission page, skipping initialization');
    return;
  }
  
  // Show status
  showStatus('Looking for Accept button...', 'info');
  
  // Start looking for the accept button
  startAcceptProcess();
  
  // Set up a mutation observer to detect DOM changes
  setupMutationObserver();
  
  log('Mission acceptor initialized successfully');
}

/**
 * Check if the current page is a mission page
 * @returns {boolean} True if the current page appears to be a mission page
 */
function isMissionPage() {
  // Check URL pattern - with updated pattern to match both mission and missions URLs
  const url = window.location.href;
  
  // Explicit check for the URL pattern the user specified
  if (url.includes('app.ocus.com/missions/')) {
    log('Detected mission page from exact URL pattern: app.ocus.com/missions/');
    return true;
  }
  
  // Also check other common patterns as fallback
  if (url.includes('/mission/') || 
      url.includes('/assignments/') || 
      url.includes('ocus.com/assignment')) {
    log('Detected mission page from URL pattern');
    return true;
  }
  
  // Check for the exact button the user specified
  try {
    const exactButton = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (exactButton) {
      const buttonText = (exactButton.innerText || exactButton.textContent || '').trim();
      if (buttonText === 'Accept assignment') {
        log('Detected mission page from exact button match');
        return true;
      }
    }
  } catch (error) {
    log('Error checking for button', error);
  }
  
  // Check for other mission-specific elements
  const missionIndicators = [
    'div[data-test="mission-details"]',
    '.mission-details',
    '.mission-header'
  ];
  
  for (const selector of missionIndicators) {
    try {
      const elements = document.querySelectorAll(selector);
      if (elements && elements.length > 0) {
        log(`Detected mission page from element: ${selector}`);
        return true;
      }
    } catch (error) {
      // Some selectors might not work in all browsers
    }
  }
  
  return false;
}

/**
 * Start the process of finding and clicking the accept button
 */
function startAcceptProcess() {
  attemptCount = 0;
  attemptAcceptMission();
}

/**
 * Attempt to find and click the accept button
 */
function attemptAcceptMission() {
  // Don't proceed if mission is already accepted or disabled
  if (missionAccepted || !CONFIG.enabled) {
    return;
  }
  
  attemptCount++;
  log(`Attempting to accept mission (${attemptCount}/${CONFIG.maxAttempts})`);
  
  // Find the accept button
  const acceptButton = findAcceptButton();
  
  if (acceptButton) {
    log('Found accept button! Attempting to click it...');
    logButtonDetails(acceptButton);
    
    // Make sure button is visible
    scrollButtonIntoView(acceptButton);
    
    // Click with delay to ensure UI is stable
    setTimeout(() => {
      if (clickAcceptButton(acceptButton)) {
        handleAcceptSuccess();
      } else {
        scheduleNextAttempt();
      }
    }, 500);
  } else {
    log('Accept button not found in this attempt');
    scheduleNextAttempt();
  }
}

/**
 * Schedule the next attempt to find and click the accept button
 */
function scheduleNextAttempt() {
  // Stop after max attempts
  if (attemptCount >= CONFIG.maxAttempts) {
    showStatus('Failed to accept mission after multiple attempts', 'error');
    log('Maximum attempts reached, giving up');
    return;
  }
  
  // Schedule next attempt
  log(`Scheduling next attempt in ${CONFIG.attemptInterval}ms`);
  clearTimeout(attemptTimer);
  attemptTimer = setTimeout(attemptAcceptMission, CONFIG.attemptInterval);
}

/**
 * Find the accept assignment button using multiple strategies with exact focus on the user-specified button
 * @returns {Element|null} The accept button element or null if not found
 */
function findAcceptButton() {
  // EXACT MATCH STRATEGY:
  // Targeting the exact button described by the user: 
  // <button data-v-1d1d488e="" data-v-c6eed17c="" class="button my-4" data-test="accept-assignment-btn" data-v-34497fa4="">
  
  // Debug logging - print the total number of buttons on the page
  const allPageButtons = document.querySelectorAll('button');
  log(`Scanning ${allPageButtons.length} buttons on the page for Accept assignment button`);
  
  // Strategy 1: Find by specific data-test attribute (most reliable)
  const dataTestButton = document.querySelector('button[data-test="accept-assignment-btn"]');
  if (dataTestButton && isVisible(dataTestButton)) {
    log('Found accept button by data-test attribute');
    logButtonDetails(dataTestButton);
    return dataTestButton;
  }
  
  // Strategy 2: Find by the exact class combination from user example
  const exactClassButton = document.querySelector('button.button.my-4[data-test="accept-assignment-btn"]');
  if (exactClassButton && isVisible(exactClassButton)) {
    log('Found accept button by exact class combination');
    logButtonDetails(exactClassButton);
    return exactClassButton;
  }
  
  // Strategy 3: Try even more specific attributes from user example
  try {
    const vueButtons = document.querySelectorAll('button[data-v-1d1d488e][data-v-c6eed17c]');
    log(`Found ${vueButtons.length} buttons with Vue-specific data attributes`);
    
    for (const btn of vueButtons) {
      if (isVisible(btn) && (btn.innerText || btn.textContent || '').trim() === 'Accept assignment') {
        log('Found accept button by Vue data attributes');
        logButtonDetails(btn);
        return btn;
      }
    }
  } catch (error) {
    // Vue attributes might not be consistent across versions
    log('Error searching for Vue buttons:', error.message);
  }
  
  // Strategy 4: Find by exact text content
  const allButtons = Array.from(document.querySelectorAll('button'));
  const textMatchButton = allButtons.find(btn => {
    const text = btn.innerText || btn.textContent || '';
    return text.trim() === 'Accept assignment' && isVisible(btn);
  });
  
  if (textMatchButton) {
    log('Found accept button by exact text match');
    logButtonDetails(textMatchButton);
    return textMatchButton;
  }
  
  // Strategy 5: Combination approach - prioritize buttons with certain classes
  const classMatchButtons = allButtons.filter(btn => {
    const classes = btn.className || '';
    return classes.includes('button') && classes.includes('my-4') && isVisible(btn);
  });
  
  log(`Found ${classMatchButtons.length} buttons with class 'button' and 'my-4'`);
  
  for (const btn of classMatchButtons) {
    const text = (btn.innerText || btn.textContent || '').trim();
    if (text === 'Accept assignment' || text.toLowerCase().includes('accept')) {
      log('Found accept button by class and text combination');
      logButtonDetails(btn);
      return btn;
    }
  }
  
  // Strategy 6: Try partial text matching on all buttons as a last resort
  log('Trying partial text matching as last resort...');
  for (const btn of allButtons) {
    if (!isVisible(btn)) continue;
    
    const text = (btn.innerText || btn.textContent || '').trim().toLowerCase();
    if (text.includes('accept') && (text.includes('assignment') || text.includes('mission'))) {
      log('Found button with accept + assignment/mission text');
      logButtonDetails(btn);
      return btn;
    }
  }
  
  // Strategy 7: Look for buttons within forms or specific containers
  const missionForms = document.querySelectorAll('form, div[class*="mission"], div[class*="assignment"]');
  log(`Looking in ${missionForms.length} potential mission forms/containers`);
  
  for (const container of missionForms) {
    const containerButtons = container.querySelectorAll('button');
    for (const btn of containerButtons) {
      if (!isVisible(btn)) continue;
      
      const text = (btn.innerText || btn.textContent || '').trim().toLowerCase();
      if (text.includes('accept')) {
        log('Found accept button within mission container');
        logButtonDetails(btn);
        return btn;
      }
    }
  }
  
  log('No accept button found after trying all detection strategies');
  return null;
}

/**
 * Scroll the button into view
 * @param {Element} button - The button to scroll into view
 */
function scrollButtonIntoView(button) {
  if (!button || !button.scrollIntoView) return;
  
  try {
    button.scrollIntoView({ behavior: 'auto', block: 'center' });
    log('Scrolled button into view');
  } catch (error) {
    log('Failed to scroll button into view', error);
  }
}

/**
 * Click the accept button using multiple reliable methods
 * @param {Element} button - The button to click
 * @returns {boolean} True if at least one click method succeeded
 */
function clickAcceptButton(button) {
  if (!button) return false;
  
  let clickSucceeded = false;
  
  // Before attempting to click, ensure the button is in view
  scrollButtonIntoView(button);
  
  // Check if the button is actually clickable before proceeding
  const buttonState = checkButtonState(button);
  log('Button state before clicking:', buttonState);
  
  if (buttonState.disabled) {
    log('Warning: Button appears to be disabled, may not respond to clicks');
  }
  
  // Method 1: Native click (most reliable)
  try {
    log('Attempting native click method');
    button.click();
    clickSucceeded = true;
    log('Native click succeeded');
  } catch (error) {
    log('Native click failed', error);
  }
  
  // Method 2: Enhanced MouseEvent click sequence
  if (!clickSucceeded || CONFIG.debug) { // Always try in debug mode
    try {
      log('Attempting enhanced MouseEvent click method');
      const rect = button.getBoundingClientRect();
      const centerX = Math.floor(rect.left + rect.width/2);
      const centerY = Math.floor(rect.top + rect.height/2);
      
      const eventParams = {
        bubbles: true,
        cancelable: true,
        view: window,
        detail: 1,
        screenX: centerX,
        screenY: centerY,
        clientX: centerX,
        clientY: centerY
      };
      
      // More complete event sequence for better reliability
      button.dispatchEvent(new MouseEvent('mouseover', eventParams));
      button.dispatchEvent(new MouseEvent('mouseenter', eventParams));
      button.dispatchEvent(new MouseEvent('mousedown', eventParams));
      button.dispatchEvent(new MouseEvent('focus', eventParams));
      button.dispatchEvent(new MouseEvent('mouseup', eventParams));
      button.dispatchEvent(new MouseEvent('click', eventParams));
      
      // Modern pointer events for better compatibility
      try {
        button.dispatchEvent(new PointerEvent('pointerover', eventParams));
        button.dispatchEvent(new PointerEvent('pointerenter', eventParams));
        button.dispatchEvent(new PointerEvent('pointerdown', eventParams));
        button.dispatchEvent(new PointerEvent('pointerup', eventParams));
        button.dispatchEvent(new PointerEvent('click', eventParams));
        log('Added pointer events for modern browsers');
      } catch (pointerError) {
        log('Pointer events not supported, continuing with mouse events only');
      }
      
      clickSucceeded = true;
      log('Enhanced MouseEvent click sequence succeeded');
    } catch (error) {
      log('Enhanced MouseEvent click failed', error);
    }
  }
  
  // Method 3: Vue/Nuxt/React specific approaches
  if (!clickSucceeded || CONFIG.debug) { // Always try in debug mode
    try {
      log('Attempting modern framework-specific click approaches');
      
      // Try to detect framework-specific properties
      const hasVueAttrs = button.hasAttribute('data-v-') || 
                        Array.from(button.attributes).some(attr => attr.name.startsWith('data-v'));
                        
      const hasReactAttrs = button.hasAttribute('data-reactid') || 
                          button.hasAttribute('data-react');
      
      log(`Button framework detection: Vue=${hasVueAttrs}, React=${hasReactAttrs}`);
      
      // For framework buttons specifically
      if (hasVueAttrs || button.hasAttribute('data-test')) {
        // Create and dispatch a more detailed click event
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window,
          detail: 1
        });
        
        // Try accessing Vue event handler properties directly
        const vueClickHandler = findVueClickHandler(button);
        if (vueClickHandler && typeof vueClickHandler === 'function') {
          try {
            log('Found Vue click handler, attempting to call directly');
            vueClickHandler.call(button, new MouseEvent('click'));
          } catch (handlerError) {
            log('Error calling Vue handler directly:', handlerError);
          }
        }
        
        button.dispatchEvent(clickEvent);
        
        // Vue often needs multiple attempts
        setTimeout(() => button.click(), 100);
        setTimeout(() => button.dispatchEvent(new MouseEvent('click', {bubbles: true})), 200);
        
        clickSucceeded = true;
        log('Modern framework click approach succeeded');
      }
    } catch (error) {
      log('Framework-specific click approach failed', error);
    }
  }
  
  // Method 4: Keyboard events for accessibility-ready buttons
  if (!clickSucceeded || CONFIG.debug) { // Always try in debug mode
    try {
      log('Attempting keyboard event simulation');
      button.focus();
      
      // Dispatch enter key events
      const keyEventInit = { bubbles: true, cancelable: true, key: 'Enter', code: 'Enter', keyCode: 13 };
      button.dispatchEvent(new KeyboardEvent('keydown', keyEventInit));
      button.dispatchEvent(new KeyboardEvent('keypress', keyEventInit));
      button.dispatchEvent(new KeyboardEvent('keyup', keyEventInit));
      
      // Dispatch space key events (some buttons respond to space)
      const spaceEventInit = { bubbles: true, cancelable: true, key: ' ', code: 'Space', keyCode: 32 };
      button.dispatchEvent(new KeyboardEvent('keydown', spaceEventInit));
      button.dispatchEvent(new KeyboardEvent('keypress', spaceEventInit));
      button.dispatchEvent(new KeyboardEvent('keyup', spaceEventInit));
      
      clickSucceeded = true;
      log('Keyboard event simulation succeeded');
    } catch (error) {
      log('Keyboard event simulation failed', error);
    }
  }
  
  // Check for success indicators after attempting clicks
  schedulePostClickChecks(button);
  
  return clickSucceeded;
}

/**
 * Check the state of the button to determine if it's clickable
 * @param {Element} button - The button to check
 * @returns {Object} Button state information
 */
function checkButtonState(button) {
  try {
    const computedStyle = window.getComputedStyle(button);
    return {
      visible: isVisible(button),
      disabled: button.disabled === true,
      ariaDisabled: button.getAttribute('aria-disabled') === 'true',
      display: computedStyle.display,
      visibility: computedStyle.visibility,
      opacity: computedStyle.opacity,
      pointerEvents: computedStyle.pointerEvents,
      hasClickListener: typeof button.onclick === 'function' || button.getAttribute('v-on:click') !== null
    };
  } catch (error) {
    log('Error checking button state:', error);
    return { visible: true, error: error.message };
  }
}

/**
 * Try to find Vue click handler on a button
 * @param {Element} button - The button to check
 * @returns {Function|null} Click handler if found
 */
function findVueClickHandler(button) {
  // Look for common Vue property patterns
  for (const key of Object.keys(button)) {
    if (key.startsWith('__vue') || key.includes('Vue')) {
      try {
        const vueInstance = button[key];
        if (vueInstance && typeof vueInstance === 'object') {
          // Look for event handlers in common locations
          if (vueInstance.listeners && vueInstance.listeners.click) {
            return vueInstance.listeners.click;
          } else if (vueInstance.events && vueInstance.events.click) {
            return vueInstance.events.click;
          } else if (vueInstance.$options && vueInstance.$options.methods) {
            // Try to find methods that might be click handlers
            const methods = vueInstance.$options.methods;
            for (const method in methods) {
              if (method.toLowerCase().includes('click') || 
                  method.toLowerCase().includes('tap') || 
                  method.toLowerCase().includes('press') || 
                  method.toLowerCase().includes('accept')) {
                return methods[method].bind(vueInstance);
              }
            }
          }
        }
      } catch (error) {
        log(`Error accessing Vue property ${key}:`, error);
      }
    }
  }
  return null;
}

/**
 * Schedule post-click checks to verify if the click was successful
 * @param {Element} button - The button that was clicked
 */
function schedulePostClickChecks(button) {
  // Perform immediate check
  setTimeout(() => {
    // Check if button is still visible and in the DOM
    try {
      const buttonStillVisible = document.body.contains(button) && isVisible(button);
      log('Button still visible after click:', buttonStillVisible);
      
      // Check for typical post-click UI changes
      checkForSuccessIndicators();
      
      // If the button is still there, we might need another attempt
      if (buttonStillVisible && attemptCount < CONFIG.maxAttempts) {
        log('Button still visible - might need another click attempt');
      }
    } catch (error) {
      // If we get an error here, the button might have been removed from the DOM
      log('Error checking button state after click - button might be gone from DOM:', error);
    }
  }, 300);
}

/**
 * Check for success indicators on the page
 */
function checkForSuccessIndicators() {
  // Check for success notifications
  const possibleNotifications = document.querySelectorAll(
    '.toast, .notification, .alert, [role="alert"], .feedback-message, .success-message'
  );
  
  log(`Checking ${possibleNotifications.length} possible notification elements for success messages`);
  
  for (const notification of possibleNotifications) {
    const text = (notification.innerText || notification.textContent || '').toLowerCase();
    if (text.includes('success') || text.includes('accepted') || text.includes('confirmed')) {
      log('Found success notification:', text);
      handleAcceptSuccess();
      return true;
    }
  }
  
  // Check URL changes that might indicate success
  const currentUrl = window.location.href;
  log('Current URL after click:', currentUrl);
  
  return false;
}

/**
 * Handle successful mission acceptance
 */
function handleAcceptSuccess() {
  // Prevent duplicate handling
  if (missionAccepted) return;
  
  missionAccepted = true;
  clearTimeout(attemptTimer);
  
  log('Mission accepted successfully!');
  showStatus('Mission accepted successfully! Redirecting in ' + (CONFIG.redirectDelay / 1000) + ' seconds...', 'success');
  
  // Update statistics for mission acceptance
  chrome.runtime.sendMessage({ type: 'MISSION_ACCEPTED' }, (response) => {
    log('Mission acceptance statistics updated:', response);
  });
  
  // Play sound alert for successful mission acceptance
  if (window.ocusSoundManager) {
    log('Playing mission accepted sound');
    window.ocusSoundManager.playSound('missionAccepted').catch(error => {
      log('Error playing mission accepted sound:', error);
    });
  }
  
  // Save mission data if needed for future reference
  try {
    const missionId = extractMissionIdFromUrl();
    if (missionId) {
      log(`Saving accepted mission ID: ${missionId}`);
      localStorage.setItem('ocus_last_accepted_mission', missionId);
      localStorage.setItem('ocus_mission_accept_time', Date.now());
    }
  } catch (error) {
    log('Error saving mission data:', error);
  }
  
  // Handle redirection after successful acceptance
  scheduleRedirection();
  
  // Send a status update to background script if needed
  try {
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: 'missionAccepted',
        timestamp: new Date().getTime(),
        missionId: extractMissionIdFromUrl() || null,
        url: window.location.href
      });
      log('Sent mission accepted status to background script');
    }
  } catch (error) {
    log('Error sending status update', error);
  }
  
  // The schedule redirection function will handle the redirection logic
}

/**
 * Extract mission ID from URL using various patterns
 * @returns {string|null} - Mission ID if found, null otherwise
 */
function extractMissionIdFromUrl() {
  const url = window.location.href;
  
  // Common URL patterns for mission IDs
  const patterns = [
    // UUID pattern (most common)
    /\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i,
    // Numeric ID pattern
    /\/mission(?:s)?\/([0-9]+)/i,
    /\/assignment(?:s)?\/([0-9]+)/i,
    // Path segment pattern (check for segment after missions or assignments)
    /\/(mission|assignment|project)\/([^/?&#]+)/i
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) {
      // For multi-capture patterns, prefer the last capture group
      const id = match[match.length - 1];
      log(`Extracted mission ID from URL: ${id}`);
      return id;
    }
  }
  
  log('Could not extract mission ID from URL');
  return null;
}

/**
 * Schedule redirection after successful mission acceptance
 */
function scheduleRedirection() {
  if (!CONFIG.autoRedirect) {
    log('Auto-redirect is disabled');
    return;
  }
  
  showStatus(`Mission accepted! Redirecting in ${CONFIG.redirectDelay/1000} seconds...`, 'success');
  
  // First try to find a "next mission" link if available
  const nextMissionTarget = findNextMissionTarget();
  
  setTimeout(() => {
    if (nextMissionTarget) {
      log(`Redirecting to next mission: ${nextMissionTarget}`);
      window.location.href = nextMissionTarget;
    } else {
      log(`Redirecting to configured homepage: ${CONFIG.homepage}`);
      window.location.href = CONFIG.homepage;
    }
  }, CONFIG.redirectDelay);
}

/**
 * Find a potential "next mission" target to redirect to
 * @returns {string|null} - URL to redirect to, or null if not found
 */
function findNextMissionTarget() {
  // Common patterns for "next mission" or "dashboard" links
  const nextPatterns = [
    // Text patterns
    { selector: 'a', textContent: ['next mission', 'next assignment', 'continue', 'dashboard', 'queue'] },
    // Common selectors
    { selector: 'a[href*="/next"]' },
    { selector: 'a[href*="/queue"]' },
    { selector: 'a[href*="/dashboard"]' },
    { selector: '.next-mission-link' },
    { selector: '.mission-queue-link' },
    { selector: '.dashboard-link' }
  ];
  
  for (const pattern of nextPatterns) {
    const elements = document.querySelectorAll(pattern.selector);
    
    for (const element of elements) {
      // If we're looking for specific text content
      if (pattern.textContent && element.innerText) {
        const text = element.innerText.toLowerCase().trim();
        if (pattern.textContent.some(p => text.includes(p.toLowerCase()))) {
          log(`Found next mission link by text match: ${element.getAttribute('href')}`);
          return element.href;
        }
      } else if (!pattern.textContent) {
        // If we're just using the selector
        log(`Found next mission link by selector: ${element.getAttribute('href')}`);
        return element.href;
      }
    }
  }
  
  return null;
}

/**
 * Set up mutation observer to detect when accept button appears
 */
function setupMutationObserver() {
  // Don't set up observer if already active
  if (window.ocusMutationObserver) return;
  
  try {
    // Create new observer
    const observer = new MutationObserver((mutations) => {
      // Only process if we haven't accepted yet
      if (missionAccepted) return;
      
      let buttonFound = false;
      
      // Check for button in mutations
      mutations.forEach(mutation => {
        if (mutation.type === 'childList' && mutation.addedNodes.length) {
          // Check if any added nodes contain our button
          for (let i = 0; i < mutation.addedNodes.length; i++) {
            const node = mutation.addedNodes[i];
            
            // Check if the node itself is a button or contains buttons
            if (node.nodeType === Node.ELEMENT_NODE) {
              // If node is a button, check if it's our target
              if (node.tagName === 'BUTTON') {
                const text = node.innerText || node.textContent || '';
                if (text.includes('Accept assignment')) {
                  buttonFound = true;
                  break;
                }
              }
              
              // If node contains buttons, check them
              const buttons = node.querySelectorAll('button');
              for (let j = 0; j < buttons.length; j++) {
                const text = buttons[j].innerText || buttons[j].textContent || '';
                if (text.includes('Accept assignment')) {
                  buttonFound = true;
                  break;
                }
              }
              
              if (buttonFound) break;
            }
          }
        }
      });
      
      // If button was found in mutations, try to accept mission
      if (buttonFound) {
        log('MutationObserver detected potential accept button');
        attemptAcceptMission();
      }
    });
    
    // Start observing
    observer.observe(document.body, { 
      childList: true, 
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class', 'data-test'] 
    });
    
    // Store observer reference
    window.ocusMutationObserver = observer;
    
    log('MutationObserver set up successfully');
  } catch (error) {
    log('Error setting up MutationObserver', error);
  }
}

/**
 * Check if an element is visible in the DOM
 * @param {Element} element - The element to check for visibility
 * @returns {boolean} True if the element is visible
 */
function isVisible(element) {
  if (!element) return false;
  
  // Check if element exists in DOM
  if (!element.isConnected) return false;
  
  // Check computed styles
  const computedStyle = window.getComputedStyle(element);
  if (computedStyle.display === 'none' || 
      computedStyle.visibility === 'hidden' || 
      computedStyle.opacity === '0') {
    return false;
  }
  
  // Check dimensions
  const rect = element.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) {
    return false;
  }
  
  // Check if element is detached
  return !!element.offsetParent;
}

/**
 * Log button details for debugging
 * @param {Element} button - Button element to log details for
 */
function logButtonDetails(button) {
  if (!CONFIG.debug || !button) return;
  
  log('Button details:', {
    text: (button.innerText || button.textContent || '').trim(),
    tagName: button.tagName,
    className: button.className,
    id: button.id || '(no id)',
    attributes: Array.from(button.attributes || [])
      .map(attr => `${attr.name}="${attr.value}"`)
      .join(' '),
    visible: isVisible(button),
    rect: button.getBoundingClientRect ? {
      top: Math.round(button.getBoundingClientRect().top),
      left: Math.round(button.getBoundingClientRect().left),
      width: Math.round(button.getBoundingClientRect().width),
      height: Math.round(button.getBoundingClientRect().height)
    } : 'unavailable'
  });
}

/**
 * Show status message to the user
 * @param {string} message - The message to show
 * @param {string} type - The type of message: 'info', 'success', or 'error'
 */
function showStatus(message, type = 'info') {
  log(`Status: ${message} (${type})`);
  
  // Create status container if it doesn't exist
  let statusContainer = document.getElementById('ocus-status-container');
  if (!statusContainer) {
    statusContainer = document.createElement('div');
    statusContainer.id = 'ocus-status-container';
    statusContainer.style.cssText = 'position:fixed;top:10px;right:10px;z-index:10000;max-width:400px;';
    document.body.appendChild(statusContainer);
  }
  
  // Create status element
  const statusElement = document.createElement('div');
  statusElement.style.cssText = 'margin-bottom:10px;padding:10px;border-radius:4px;box-shadow:0 2px 5px rgba(0,0,0,0.2);font-family:Arial,sans-serif;transition:opacity 0.3s ease;';
  
  // Set status color based on type
  switch (type) {
    case 'success':
      statusElement.style.backgroundColor = '#4CAF50';
      statusElement.style.color = 'white';
      break;
    case 'error':
      statusElement.style.backgroundColor = '#F44336';
      statusElement.style.color = 'white';
      break;
    case 'info':
    default:
      statusElement.style.backgroundColor = '#2196F3';
      statusElement.style.color = 'white';
  }
  
  statusElement.textContent = message;
  statusContainer.appendChild(statusElement);
  
  // Remove after 5 seconds
  setTimeout(() => {
    statusElement.style.opacity = '0';
    setTimeout(() => {
      if (statusElement.parentNode) {
        statusElement.parentNode.removeChild(statusElement);
      }
    }, 300);
  }, 5000);
}

/**
 * Logging utility function
 * @param {string} message - The message to log
 * @param {*} [data] - Optional data to log with the message
 */
function log(message, data) {
  if (!CONFIG.debug) return;
  
  const prefix = '[OCUS]';
  if (data !== undefined) {
    console.log(`${prefix} ${message}`, data);
  } else {
    console.log(`${prefix} ${message}`);
  }
}

// Immediately check if we need to run on this page
function checkAndInit() {
  // Check if we're on a mission page by URL first (faster than waiting for full DOM)
  const url = window.location.href;
  if (url.includes('app.ocus.com/missions/') || url.includes('app.ocus.com/mission/')) {
    log('URL match detected, preparing to initialize...');
    
    // Run initialization when DOM is ready
    if (document.readyState === 'loading') {
      log('DOM still loading, waiting for DOMContentLoaded...');
      document.addEventListener('DOMContentLoaded', init);
      
      // Also set a backup timer in case DOMContentLoaded doesn't fire
      setTimeout(() => {
        if (!missionAccepted) {
          log('Backup timer triggered init');
          init();
        }
      }, 1000);
    } else {
      // DOM already loaded, initialize immediately
      log('DOM already loaded, initializing immediately');
      init();
    }
  } else {
    log('Not on a mission page, skipping initialization');
  }
}

// Start checking as soon as the script loads
checkAndInit();

// Also listen for navigation events in case URL changes without page reload
if (typeof window !== 'undefined') {
  window.addEventListener('popstate', checkAndInit);
  
  // Set up a periodic check to ensure functionality even if navigation events don't fire correctly
  setInterval(() => {
    if (!missionAccepted && window.location.href.includes('/missions/')) {
      log('Periodic check detected mission page');
      checkAndInit();
    }
  }, 2000);
}
