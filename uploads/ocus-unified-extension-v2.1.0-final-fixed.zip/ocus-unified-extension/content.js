/**
 * OCUS Unified Extension - Content Script
 * 
 * Main content script that integrates all functionality:
 * - Auto login
 * - Mission monitoring
 * - Mission accepting
 * 
 * Enhanced with improved Nuxt.js detection and support for OCUS app structure
 */

// Log initialization
console.log('OCUS Unified Extension - Content Script Initializing');

// Configuration state
let config = {
  autoLogin: {
    enabled: true,
    username: '',
    password: '',
    maxLoginAttempts: 5
  },
  missionMonitor: {
    enabled: true,
    refreshInterval: 30000,
    showNotifications: true,
    maxSimultaneousMissions: 3
  },
  missionAccept: {
    enabled: true,
    autoClose: true,
    closeDelay: 2000
  },
  processedMissions: []
};

// Initialize when the DOM is fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialize);
} else {
  initialize();
}

// Main initialization function
function initialize() {
  console.log('OCUS Unified Extension - Content Script Initialized');
  
  // Get configuration from storage
  chrome.storage.local.get(['config'], (result) => {
    if (result && result.config) {
      // Update configuration
      config = result.config;
      console.log('Configuration loaded from storage');
    } else {
      // Save default configuration to storage
      chrome.storage.local.set({ config });
      console.log('Default configuration saved to storage');
    }
    
    // Initialize features based on current URL
    initializeFeatures();
  });
  
  // Listen for configuration updates and other messages
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('Message received in content.js:', message.type);
    
    if (message.type === 'CONFIG_UPDATED' && message.config) {
      // Update configuration
      config = message.config;
      console.log('Configuration updated');
      
      // Re-initialize features
      initializeFeatures();
    } else if (message.type === 'FORCE_LOGIN_CHECK') {
      console.log('Forced login check requested');
      // Check if we're on a login page
      if (isLoginPage(window.location.href.toLowerCase())) {
        console.log('On login page, will attempt login');
        attemptLogin();
      }
    } else if (message.type === 'FORCE_LOGIN') {
      console.log('Forced login attempt requested');
      attemptLogin();
    }
    
    // Always send a response (even if empty) to unblock the sender
    sendResponse({});
  });
}

// Initialize appropriate features based on current URL
function initializeFeatures() {
  const currentUrl = window.location.href.toLowerCase();
  
  console.log('Initializing features for URL:', currentUrl);
  
  // Check if the page is using Nuxt.js (typical for OCUS)
  const isNuxtjsApp = checkIfNuxtApp();
  if (isNuxtjsApp) {
    console.log('Detected Nuxt.js application, enabling enhanced Vue support');
    // Make sure vue-support.js has initialized
    if (typeof window.ocusVueSupport === 'undefined') {
      console.warn('Vue support not yet initialized, will wait for it');
      // Set a flag for future initialization
      window._needsVueSupport = true;
    }
  }
  
  // Set up the home redirection timer to prevent getting stuck on subpages
  setupHomeRedirectTimer();
  
  // Immediately request a forced login check - this coordinates with login-functions.js
  // which has the actual login implementation
  if (isLoginPage(currentUrl)) {
    console.log('Login page detected in content.js');
    
    // Ensure we have valid credentials before attempting login
    chrome.runtime.sendMessage({ type: 'CHECK_LOGIN_CREDENTIALS' }, (response) => {
      if (response && response.success && response.credentials) {
        console.log('Login credentials verified, triggering login attempt');
        
        // Update local config with valid credentials
        if (config.autoLogin) {
          config.autoLogin.username = response.credentials.username;
          config.autoLogin.password = response.credentials.password;
          config.autoLogin.enabled = response.credentials.enabled;
        }
        
        // Small delay to ensure the page is fully loaded
        setTimeout(() => {
          // Use the window.debugOCUSLogin hooks from login-functions.js if available
          if (window.debugOCUSLogin && typeof window.debugOCUSLogin.forceLogin === 'function') {
            console.log('Using debug hooks to force login');
            window.debugOCUSLogin.forceLogin();
          } else {
            // Fallback to local attempt
            attemptLogin();
          }
        }, 1500);
      } else {
        console.warn('Could not verify login credentials');
      }
    });
  }
  
  // Check if we're on a mission list page
  if (isMissionListPage(currentUrl)) {
    console.log('Mission list page detected');
    
    // Initialize mission monitor if enabled
    if (config.missionMonitor && config.missionMonitor.enabled) {
      // Mission monitoring is initialized by mission-monitor.js
      console.log('Mission monitoring is enabled');
      
      // For app.ocus.com, we need special handling because it uses Nuxt.js
      if (currentUrl.includes('app.ocus.com')) {
        // Dispatch a custom event that mission-monitor.js will listen for
        window.dispatchEvent(new CustomEvent('ocusAppPageDetected', { detail: { url: currentUrl } }));
        
        // Set a short timeout to ensure the page has loaded more completely
        setTimeout(() => {
          // Trigger a manual scan for mission cards
          window.dispatchEvent(new CustomEvent('ocusScanForMissions'));
        }, 2000);
      }
    }
  }
  
  // Check if we're on a mission details page
  if (isMissionDetailsPage(currentUrl)) {
    console.log('Mission details page detected');
    
    // Initialize mission acceptor if enabled
    if (config.missionAccept && config.missionAccept.enabled) {
      // Mission acceptance is initialized by mission-acceptor.js
      console.log('Mission auto-acceptance is enabled');
      
      // For app.ocus.com missions, we need special handling because it uses Nuxt.js
      if (currentUrl.includes('app.ocus.com/missions/')) {
        // Extract the mission ID from the URL
        const missionId = extractMissionIdFromUrl(currentUrl);
        if (missionId) {
          console.log(`Detected mission ID: ${missionId}`);
          
          // Dispatch a custom event for mission-acceptor.js
          window.dispatchEvent(new CustomEvent('ocusMissionPageDetected', { 
            detail: { 
              url: currentUrl, 
              missionId: missionId 
            }
          }));
          
          // Set a short timeout to ensure the page has loaded more completely
          setTimeout(() => {
            // Trigger a direct attempt to accept the mission
            window.dispatchEvent(new CustomEvent('ocusTryAcceptMission', {
              detail: { missionId: missionId }
            }));
          }, 2000);
        }
      }
    }
  }
}

// Check if the current URL is a login page
function isLoginPage(url) {
  url = url || window.location.href.toLowerCase();
  
  // Check for login page patterns
  const loginPatterns = [
    '/login',
    '/auth',
    '/sign-in',
    '/signin',
    '/connexion',  // French
    '/acceso',     // Spanish
    'authenticate'
  ];
  
  // Check URL against patterns
  for (const pattern of loginPatterns) {
    if (url.includes(pattern)) {
      console.log(`Login page detected (pattern: ${pattern})`);
      return true;
    }
  }
  
  // Also check for login form elements in the DOM
  if (document.querySelector('input[type="password"]') && 
      (document.querySelector('input[type="email"]') || document.querySelector('input[name="email"]'))) {
    console.log('Login page detected (form elements found)');
    return true;
  }
  
  return false;
}

// Check if the current URL is a mission list page
function isMissionListPage(url) {
  url = url || window.location.href.toLowerCase();
  
  // Enhanced detection for mission list pages based on source code analysis
  return url.includes('app.ocus.com') || 
         url.includes('ocus.work') ||
         url.includes('dashboard') ||
         url.includes('missions') ||
         url.includes('projects') ||
         // Catch all potential mission listing URLs
         (url.includes('ocus.com') && !url.includes('missions/')) ||
         // The main app page is always a mission list page
         url === 'https://app.ocus.com/' ||
         url === 'https://app.ocus.com';
}

// Check if the current URL is a mission details page
function isMissionDetailsPage(url) {
  url = url || window.location.href.toLowerCase();
  
  // Enhanced detection for mission details pages based on source code analysis
  
  // Check mission details patterns - improved to match source code structure
  // Exact pattern matching for mission URLs in the form https://app.ocus.com/missions/ID
  return (url.includes('/mission/') && url.split('/mission/')[1]?.length > 5) || 
         (url.includes('/missions/') && url.split('/missions/')[1]?.length > 5) ||
         // Project URLs
         (url.includes('/project/') && url.split('/project/')[1]?.length > 5) ||
         (url.includes('/projects/') && url.split('/projects/')[1]?.length > 5) ||
         // Assignment URLs
         (url.includes('/assignment/') && url.split('/assignment/')[1]?.length > 5) ||
         // Match UUIDs in URLs (common pattern for mission IDs in OCUS)
         /\/[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}/.test(url);
}

// Attempt to log in using stored credentials
function attemptLogin() {
  // Only proceed if auto-login is enabled
  if (!config.autoLogin.enabled) {
    console.log('Auto-login is disabled, skipping login attempt');
    return;
  }
  
  console.log('Attempting to log in with stored credentials...');
  
  // Find login form elements with more comprehensive selectors
  const emailInput = document.querySelector('input[type="email"], input[name="email"], input[id*="email"], input[placeholder*="email"], input[name="username"]');
  const passwordInput = document.querySelector('input[type="password"], input[name="password"], input[id*="password"]');
  
  // Find submit button using multiple methods
  let submitButton = document.querySelector('button[type="submit"], input[type="submit"]');
  
  // If no submit button found using standard selectors, try finding by text
  if (!submitButton) {
    submitButton = findButtonByText('Login') || 
                 findButtonByText('Sign in') || 
                 findButtonByText('Log in') ||
                 findButtonByText('Submit') ||
                 findButtonByText('Connecter') || // French
                 findButtonByText('Ingresar'); // Spanish
  }
  
  // Check if elements exist
  if (!emailInput || !passwordInput || !submitButton) {
    console.warn('Login form elements not found, details:', {
      emailInput: emailInput ? 'Found' : 'Not found',
      passwordInput: passwordInput ? 'Found' : 'Not found',
      submitButton: submitButton ? 'Found' : 'Not found'
    });
    
    // Try again after a short delay (page might still be loading)
    setTimeout(attemptLogin, 2000);
    return;
  }
  
  console.log('Login form elements found:', {
    emailInput: emailInput ? 'Found' : 'Not found',
    passwordInput: passwordInput ? 'Found' : 'Not found',
    submitButton: submitButton ? 'Found' : 'Not found'
  });
  
  // Use credentials from config
  if (config.autoLogin.username && config.autoLogin.password) {
    console.log('Using credentials from config');
    
    // Fill in the login form
    emailInput.value = config.autoLogin.username;
    passwordInput.value = config.autoLogin.password;
    
    // Dispatch input events to trigger any validation
    emailInput.dispatchEvent(new Event('input', { bubbles: true }));
    passwordInput.dispatchEvent(new Event('input', { bubbles: true }));
    emailInput.dispatchEvent(new Event('change', { bubbles: true }));
    passwordInput.dispatchEvent(new Event('change', { bubbles: true }));
    
    // Give time for the event to be processed
    setTimeout(() => {
      console.log('Clicking submit button...');
      // Click the submit button
      submitButton.click();
      
      // Send notification to background
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Login Attempt',
        message: 'Attempting to log in to OCUS platform',
        priority: 1
      });
      
      // Wait a moment to check if we successfully logged in
      setTimeout(() => {
        // If we're still on a login page, report failure
        if (isLoginPage(window.location.href.toLowerCase())) {
          console.error('Login failed, still on login page');
          chrome.runtime.sendMessage({
            type: 'LOGIN_FAILED',
            reason: 'Login attempt did not redirect away from login page'
          });
        } else {
          console.log('Login successful, no longer on login page');
          // Send message to background script
          chrome.runtime.sendMessage({
            type: 'LOGIN_COMPLETED'
          });
        }
      }, 5000);
    }, 500);
    
    return true;
  } else {
    console.error('Missing login credentials');
    
    // Request credentials from background script
    chrome.runtime.sendMessage({ type: 'CHECK_LOGIN_CREDENTIALS' }, (response) => {
      if (response && response.success && response.credentials) {
        console.log('Retrieved credentials from background script');
        
        // Update local config with valid credentials
        if (config.autoLogin) {
          config.autoLogin.username = response.credentials.username;
          config.autoLogin.password = response.credentials.password;
          config.autoLogin.enabled = response.credentials.enabled;
          
          // Try login again
          setTimeout(attemptLogin, 500);
        }
      } else {
        chrome.runtime.sendMessage({
          type: 'LOGIN_FAILED',
          reason: 'No valid credentials available'
        });
      }
    });
    
    return false;
  }
}

// Find an input field by type or name
function findInputField(type) {
  // First, try to find by ID, name, or placeholder
  const selectors = [
    `input[id*="${type}"]`,
    `input[name*="${type}"]`,
    `input[placeholder*="${type}"]`,
    `input[type="${type}"]`,
    `input[id*="${type}" i]`,  // Case-insensitive
    `input[name*="${type}" i]`, // Case-insensitive
    `input[placeholder*="${type}" i]` // Case-insensitive
  ];
  
  // Try each selector
  for (const selector of selectors) {
    const field = document.querySelector(selector);
    if (field) {
      return field;
    }
  }
  
  // If not found, try more generic approach
  const inputFields = document.querySelectorAll('input');
  
  for (const field of inputFields) {
    const fieldId = field.id?.toLowerCase() || '';
    const fieldName = field.name?.toLowerCase() || '';
    const fieldPlaceholder = field.placeholder?.toLowerCase() || '';
    const fieldType = field.type?.toLowerCase() || '';
    
    // Check if the field matches the expected type
    if (fieldId.includes(type) || 
        fieldName.includes(type) || 
        fieldPlaceholder.includes(type) || 
        fieldType === type) {
      return field;
    }
  }
  
  return null;
}

// Enhanced function to find button by text content
function findButtonByText(text) {
  const lowerText = text.toLowerCase();
  console.log(`[OCUS] Looking for button with text containing: ${text}`);
  
  // Use the helper function if available
  if (window.ocusHelpers && typeof window.ocusHelpers.isVisibleElement === 'function') {
    const isVisibleElement = window.ocusHelpers.isVisibleElement;
    
    // Try buttons first (most common elements)
    const buttons = Array.from(document.querySelectorAll('button, input[type="button"], input[type="submit"]'));
    const buttonMatch = buttons.find(button => {
      const buttonText = button.textContent || button.value || button.innerText || '';
      return buttonText.trim().toLowerCase().includes(lowerText) && isVisibleElement(button);
    });
    
    if (buttonMatch) {
      console.log(`[OCUS] Found visible button with text: ${buttonMatch.textContent || buttonMatch.value || ''}`);
      return buttonMatch;
    }
    
    // Try any element with role="button"
    const roleButtons = Array.from(document.querySelectorAll('[role="button"]'));
    const roleMatch = roleButtons.find(element => {
      const elemText = element.textContent || element.value || element.innerText || '';
      return elemText.trim().toLowerCase().includes(lowerText) && isVisibleElement(element);
    });
    
    if (roleMatch) {
      console.log(`[OCUS] Found visible role=button with text: ${roleMatch.textContent || roleMatch.value || ''}`);
      return roleMatch;
    }
    
    // Try spans within buttons
    const buttonSpans = Array.from(document.querySelectorAll('button span'));
    for (const span of buttonSpans) {
      if (span.textContent.trim().toLowerCase().includes(lowerText) && 
          isVisibleElement(span.closest('button'))) {
        console.log(`[OCUS] Found button with span containing text: ${span.textContent.trim()}`);
        return span.closest('button');
      }
    }
    
    // Try any clickable element with the text
    const allElements = Array.from(document.querySelectorAll('a.btn, div.btn, div.button, .v-btn, .button'));
    const elementMatch = allElements.find(element => {
      const elemText = element.textContent || element.value || element.innerText || '';
      return elemText.trim().toLowerCase().includes(lowerText) && isVisibleElement(element);
    });
    
    if (elementMatch) {
      console.log(`[OCUS] Found clickable element with text: ${elementMatch.textContent || elementMatch.value || ''}`);
      return elementMatch;
    }
  } else {
    // Fallback to original implementation if helper not available
    const buttons = Array.from(document.querySelectorAll('button, input[type="button"], input[type="submit"], a.btn, .v-btn, .button'));
    
    for (const button of buttons) {
      const buttonText = button.textContent || button.value || button.innerText || '';
      if (buttonText.trim().toLowerCase().includes(lowerText)) {
        console.log(`[OCUS] Found button with text: ${buttonText}`);
        return button;
      }
    }
    
    // Also check for elements with specific classes that might be buttons
    const possibleButtons = Array.from(document.querySelectorAll('.btn, .v-btn, .button, [role="button"]'));
    for (const button of possibleButtons) {
      const buttonText = button.textContent || button.value || button.innerText || '';
      if (buttonText.trim().toLowerCase().includes(lowerText)) {
        console.log(`[OCUS] Found possible button with text: ${buttonText}`);
        return button;
      }
    }
  }
  
  console.log(`[OCUS] Button with text not found: ${text}`);
  return null;
}

// Find the login submit button
function findLoginButton() {
  // List of selectors to try
  const buttonSelectors = [
    'button[type="submit"]',
    'input[type="submit"]',
    'button.login-button',
    'button.submit-button',
    'button.sign-in-button',
    '.login-button',
    '.submit-button',
    '.sign-in-button'
  ];
  
  // Look for buttons with login-related text
  const loginKeywords = ['login', 'log in', 'sign in', 'signin', 'submit', 'continue'];
  
  // Try each selector
  for (const selector of buttonSelectors) {
    const button = document.querySelector(selector);
    if (button) {
      return button;
    }
  }
  
  // Try to find button by text content
  const buttons = document.querySelectorAll('button');
  
  for (const button of buttons) {
    const buttonText = button.textContent.trim().toLowerCase();
    
    // Check if the button text contains any login keywords
    if (loginKeywords.some(keyword => buttonText.includes(keyword))) {
      return button;
    }
  }
  
  // Look for submit inputs
  const submitInputs = document.querySelectorAll('input[type="submit"]');
  if (submitInputs.length > 0) {
    return submitInputs[0];
  }
  
  // If all else fails, look for a form and return its submit function
  const form = document.querySelector('form');
  if (form) {
    // Create a virtual button that will submit the form when clicked
    const virtualButton = document.createElement('button');
    virtualButton.type = 'button';
    virtualButton.style.display = 'none';
    virtualButton.addEventListener('click', () => {
      form.submit();
    });
    document.body.appendChild(virtualButton);
    return virtualButton;
  }
  
  return null;
}

// Trigger an input event to simulate user typing
function triggerInputEvent(element) {
  if (!element) return;
  
  // Create and dispatch input event
  const inputEvent = new Event('input', { bubbles: true });
  element.dispatchEvent(inputEvent);
  
  // Create and dispatch change event
  const changeEvent = new Event('change', { bubbles: true });
  element.dispatchEvent(changeEvent);
}

// Check if login was successful
function checkLoginSuccess() {
  // Wait a bit to check for success
  setTimeout(() => {
    // Check if we're still on the login page
    if (!isLoginPage()) {
      console.log('Login successful!');
      
      // Track successful login
      updateLoginStats('success');
      
      // Send notification
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Login Successful',
        message: 'Successfully logged in to OCUS',
        priority: 1
      });
    } else {
      console.log('Still on login page, login may have failed');
      
      // Check for error messages
      const errorMessages = document.querySelectorAll('.error, .alert, .notification, .message');
      let hasError = false;
      
      for (const errorMessage of errorMessages) {
        if (errorMessage.offsetParent !== null) { // Check if visible
          const text = errorMessage.textContent.trim().toLowerCase();
          if (text.includes('invalid') || 
              text.includes('incorrect') || 
              text.includes('failed') || 
              text.includes('error')) {
            hasError = true;
            break;
          }
        }
      }
      
      if (hasError) {
        console.log('Login error detected');
        
        // Send notification
        chrome.runtime.sendMessage({
          type: 'SEND_NOTIFICATION',
          title: 'Login Failed',
          message: 'Failed to log in to OCUS',
          priority: 1
        });
      } else {
        console.log('No login error detected, waiting for navigation...');
        
        // Check again after another delay
        setTimeout(() => {
          if (!isLoginPage()) {
            console.log('Delayed login success detected!');
            
            // Track successful login
            updateLoginStats('success');
            
            // Send notification
            chrome.runtime.sendMessage({
              type: 'SEND_NOTIFICATION',
              title: 'Login Successful',
              message: 'Successfully logged in to OCUS',
              priority: 1
            });
          }
        }, 5000);
      }
    }
  }, 2000);
}

// Update login statistics
function updateLoginStats(type) {
  chrome.storage.local.get(['stats'], (result) => {
    const stats = result.stats || {
      loginAttempts: 0,
      successfulLogins: 0,
      missionsFound: 0,
      missionsOpened: 0,
      missionsAccepted: 0
    };
    
    if (type === 'attempt') {
      stats.loginAttempts++;
    } else if (type === 'success') {
      stats.successfulLogins++;
    }
    
    chrome.storage.local.set({ stats });
  });
}

// Add a console log to show extension activation
console.log('OCUS Unified Extension activated on:', window.location.href);

// Create a debug object on window for troubleshooting
window.ocusDebug = {
  config: config,
  isLoginPage: isLoginPage,
  attemptLogin: attemptLogin,
  findButtonByText: findButtonByText,
  forceLogin: () => {
    console.log('Manual login trigger from debug console');
    attemptLogin();
    return 'Login attempt triggered. Check console for results.';
  },
  detectNuxt: () => {
    return checkIfNuxtApp();
  },
  extractMissionId: (url) => {
    return extractMissionIdFromUrl(url || window.location.href);
  }
};

// Check if the page is using Nuxt.js
function checkIfNuxtApp() {
  // Look for Nuxt.js specific elements in the DOM
  return !!document.getElementById('__nuxt') || 
         !!document.getElementById('nuxt-loading') || 
         !!document.querySelector('[data-n-head]') ||
         (typeof window.__NUXT__ !== 'undefined');
}

/**
 * Sets up a timer to redirect back to the OCUS homepage after 10 seconds
 * This prevents the extension from getting stuck on subpages
 */
function setupHomeRedirectTimer() {
  // Skip if we're already on the homepage
  const currentUrl = window.location.href.toLowerCase();
  if (currentUrl === 'https://app.ocus.com/' || 
      currentUrl === 'https://app.ocus.com' || 
      currentUrl === 'https://app.ocus.work/' || 
      currentUrl === 'https://app.ocus.work') {
    console.log('Already on homepage, not setting up redirect timer');
    return;
  }
  
  console.log('Setting up 10-second homepage redirect timer');
  
  setTimeout(() => {
    // If we're on a mission acceptance page, check if the mission was accepted
    // We can access window.missionAccepted if the mission-acceptor script has run
    if (typeof window.missionAccepted !== 'undefined' && window.missionAccepted === true) {
      console.log('Mission was accepted, cancelling homepage redirect');
      return;
    }
    
    // Check if we're still on a subpage
    const currentUrl = window.location.href.toLowerCase();
    if (currentUrl !== 'https://app.ocus.com/' && 
        currentUrl !== 'https://app.ocus.com' && 
        currentUrl !== 'https://app.ocus.work/' && 
        currentUrl !== 'https://app.ocus.work') {
      console.log('Redirecting to OCUS homepage after 10-second timeout');
      window.location.href = 'https://app.ocus.com/';
    }
  }, 10000); // 10 seconds
}

// Extract mission ID from URL
function extractMissionIdFromUrl(url) {
  // Try to extract UUID-like mission ID
  const uuidMatch = url.match(/\/missions\/([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})/);
  if (uuidMatch && uuidMatch[1]) {
    return uuidMatch[1];
  }
  
  // Fallback to general ID extraction
  if (url.includes('/missions/')) {
    return url.split('/missions/')[1]?.split('/')[0];
  }
  
  if (url.includes('/mission/')) {
    return url.split('/mission/')[1]?.split('/')[0];
  }
  
  return null;
}

// Force login check when script is loaded
setTimeout(() => {
  console.log('Running initial login check...');
  if (isLoginPage(window.location.href.toLowerCase())) {
    console.log('On login page, will attempt login');
    attemptLogin();
  } else if (isMissionListPage(window.location.href.toLowerCase())) {
    // If we're on a mission list page, explicitly trigger a scan
    console.log('On mission list page, triggering initial scan...');
    window.dispatchEvent(new CustomEvent('ocusScanForMissions'));
  } else if (isMissionDetailsPage(window.location.href.toLowerCase())) {
    // If we're on a mission details page, explicitly trigger acceptance attempt
    console.log('On mission details page, triggering initial acceptance...');
    const missionId = extractMissionIdFromUrl(window.location.href.toLowerCase());
    if (missionId) {
      window.dispatchEvent(new CustomEvent('ocusTryAcceptMission', {
        detail: { missionId: missionId }
      }));
    }
  }
}, 1500);

// Listen for DOM content loaded to ensure proper initialization
document.addEventListener('DOMContentLoaded', () => {
  // Setup special event listeners for mission-monitor.js and mission-acceptor.js
  window.addEventListener('ocusScanForMissions', () => {
    if (typeof window.scanForMissionCards === 'function') {
      console.log('Manually triggering mission scan...');
      window.scanForMissionCards();
    }
  });
  
  window.addEventListener('ocusTryAcceptMission', (event) => {
    if (typeof window.tryAcceptWithVueSupport === 'function') {
      console.log('Manually triggering mission acceptance for ID:', event.detail?.missionId);
      window.tryAcceptWithVueSupport(event.detail?.missionId);
    }
  });
  
  // Check for Nuxt.js app structure every second for the first 10 seconds
  let nuxtCheckCount = 0;
  const nuxtCheckInterval = setInterval(() => {
    if (checkIfNuxtApp()) {
      console.log('Nuxt.js app structure detected');
      clearInterval(nuxtCheckInterval);
      
      // Dispatch event for Vue support initialization
      window.dispatchEvent(new CustomEvent('ocusNuxtDetected'));
    }
    
    nuxtCheckCount++;
    if (nuxtCheckCount >= 10) {
      clearInterval(nuxtCheckInterval);
    }
  }, 1000);
});
