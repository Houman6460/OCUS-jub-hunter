/**
 * OCUS Unified Extension - Dropdown Stabilizer
 * 
 * Prevents dropdown menu issues on the OCUS platform by applying fixes
 * to Vue.js based dropdown components.
 * 
 * This script runs at document_start to ensure it's applied early.
 */

(function() {
  // Create a style element to inject CSS fixes
  const style = document.createElement('style');
  
  // CSS fixes for dropdown menus
  style.textContent = `
    /* Fix for dropdown menus getting stuck open */
    .v-menu__content {
      z-index: 9999 !important;
    }
    
    /* Fix for dropdown backdrop issues */
    .v-overlay {
      z-index: 9998 !important;
    }
    
    /* Ensure dropdowns are visible */
    .v-select__selections,
    .v-select__selection,
    .v-select__selection--comma {
      max-width: 100%;
      overflow: visible;
    }
    
    /* Fix for dropdown positioning */
    .v-menu__content--fixed {
      position: fixed !important;
    }
    
    /* Fix for dropdown selection highlighting */
    .v-list-item--active {
      background-color: rgba(33, 150, 243, 0.15) !important;
    }
  `;
  
  // Add style to document head using ensureHead if available or with fallback
  if (window.ocusGlobals && typeof window.ocusGlobals.ensureHead === 'function') {
    // Use our document-head-fix.js utility if available
    const head = window.ocusGlobals.ensureHead();
    if (head) {
      head.appendChild(style);
    }
  } else if (document.head) {
    // Direct append if head is available
    document.head.appendChild(style);
  } else {
    console.warn('Dropdown stabilizer could not append style: document.head is null');
    // Wait for document.head to be available
    const checkForHead = setInterval(() => {
      if (document.head) {
        document.head.appendChild(style);
        clearInterval(checkForHead);
      }
    }, 100);
  }
  
  // Create a MutationObserver to fix dropdown issues as they appear
  const observer = new MutationObserver((mutations) => {
    // Look for dropdown elements that might be problematic
    const dropdowns = document.querySelectorAll('.v-menu__content, .dropdown-menu, .select-menu');
    
    dropdowns.forEach(dropdown => {
      // Ensure proper positioning
      if (dropdown.style.position === 'absolute') {
        dropdown.style.position = 'fixed';
      }
      
      // Ensure dropdowns are visible and have proper z-index
      if (parseInt(dropdown.style.zIndex) < 9000) {
        dropdown.style.zIndex = '9999';
      }
    });
  });
  
  // Start observing the document for dropdown issues once DOM is loaded
  window.addEventListener('DOMContentLoaded', () => {
    observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class']
    });
    
    // Apply initial fixes
    fixInitialDropdowns();
  });
  
  // Fix initial dropdowns when the page loads
  function fixInitialDropdowns() {
    // Patch Vue.js dropdown components if Vue is detected
    if (window.__VUE__ || document.querySelector('[data-v-app]')) {
      patchVueDropdowns();
    }
    
    // Fix any initial dropdown elements
    const dropdowns = document.querySelectorAll('.v-menu__content, .dropdown-menu, .select-menu');
    
    dropdowns.forEach(dropdown => {
      dropdown.style.position = 'fixed';
      dropdown.style.zIndex = '9999';
    });
  }
  
  // Patch Vue.js dropdown components
  function patchVueDropdowns() {
    // Wait for Vue to be fully initialized
    setTimeout(() => {
      // Find all Vue dropdown components
      const vueDropdowns = document.querySelectorAll('.v-menu, .v-select');
      
      vueDropdowns.forEach(dropdown => {
        // Mark dropdown as patched
        dropdown.setAttribute('data-ocus-patched', 'true');
        
        // Ensure dropdown content is properly positioned
        const content = dropdown.querySelector('.v-menu__content');
        if (content) {
          content.style.position = 'fixed';
          content.style.zIndex = '9999';
        }
      });
    }, 1000);
  }
})();
