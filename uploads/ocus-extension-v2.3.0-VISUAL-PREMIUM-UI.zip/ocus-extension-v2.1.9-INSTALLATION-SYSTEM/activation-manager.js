/**
 * OCUS Unified Extension - Activation Manager (Fixed)
 * 
 * Manages license activation and demo usage tracking with improved error handling
 */

class ActivationManager {
  constructor() {
    this.config = window.EXTENSION_CONFIG || {};
    this.userId = null;
    this.isActivated = false;
    this.demoUsesRemaining = 3;
    this.initialized = false;
  }

  /**
   * Initialize the activation manager
   */
  async initialize() {
    if (this.initialized) return;

    try {
      // Get or create user ID
      this.userId = await this.getOrCreateUserId();
      
      // Check activation status first
      await this.checkActivationStatus();
      
      // If not activated, check demo status with fallback
      if (!this.isActivated) {
        await this.checkDemoStatusSafely();
      }
      
      this.initialized = true;
      console.log('Activation Manager initialized:', {
        userId: this.userId,
        isActivated: this.isActivated,
        demoUsesRemaining: this.demoUsesRemaining
      });
    } catch (error) {
      console.error('Failed to initialize activation manager:', error);
      // Continue with demo mode as fallback
      this.demoUsesRemaining = 3;
      this.initialized = true;
    }
  }

  /**
   * Get or create a unique user ID
   */
  async getOrCreateUserId() {
    return new Promise((resolve) => {
      const storageKey = this.config.USER_ID?.STORAGE_KEY || 'extension_user_id';
      chrome.storage.local.get([storageKey], (result) => {
        let userId = result[storageKey];
        
        if (!userId) {
          // Generate UUID-like ID
          userId = this.generateUUID();
          chrome.storage.local.set({ [storageKey]: userId });
        }
        
        resolve(userId);
      });
    });
  }

  /**
   * Generate a UUID-like identifier
   */
  generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }

  /**
   * Check activation status from stored key
   */
  async checkActivationStatus() {
    return new Promise((resolve) => {
      const storageKey = this.config.ACTIVATION?.STORAGE_KEY || 'activation_key_data';
      chrome.storage.local.get([storageKey], async (result) => {
        const activationData = result[storageKey];
        
        if (activationData && activationData.key) {
          try {
            const isValid = await this.validateActivationKey(activationData.key);
            this.isActivated = isValid;
            
            if (!isValid) {
              // Remove invalid key
              chrome.storage.local.remove([storageKey]);
            }
          } catch (error) {
            console.warn('Could not validate activation key:', error);
            this.isActivated = false;
          }
        }
        
        resolve(this.isActivated);
      });
    });
  }

  /**
   * Validate activation key with master keys and demo keys
   */
  async validateActivationKey(activationKey) {
    // Check for complex master keys first - enterprise level
    const masterKeys = [
      'OCUS-PRO-7X9K-2M8L-QW3R-UNLIMITED-2025',
      'JOBHUNTER-ENTERPRISE-5N4B-8F7G-H1J2-PREMIUM-KEY', 
      'UNLIMITED-ACCESS-9P0L-3K5M-6V8C-MASTER-2025',
      'PREMIUM-EXTENSION-4R7T-2Y9U-1I8O-ENTERPRISE-CODE',
      'MASTER-ACTIVATION-8Q5W-6E3R-9T7Y-UNLIMITED-ACCESS',
      'OCUS-ENTERPRISE-1A2S-3D4F-5G6H-PREMIUM-2025',
      'PROFESSIONAL-LICENSE-7Z8X-4C5V-2B6N-MASTER-KEY'
    ];
    
    if (masterKeys.includes(activationKey.toUpperCase())) {
      console.log('✅ Master activation key accepted:', activationKey);
      return true;
    }
    
    // Check for demo keys
    const demoKeys = [
      'OCUS-2024-DEMO-KEY',
      'OCUS-TRIAL-2024-EXT',
      'OCUS-UNLIMITED-2024'
    ];
    
    if (demoKeys.includes(activationKey)) {
      console.log('Demo activation key accepted:', activationKey);
      return true;
    }

    // For production keys, try server validation
    try {
      const apiUrl = 'https://jobhunter.one/api/activation/validate';
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          activation_key: activationKey,
          version_token: 'b7d3f8e2-4a1b-4c7d-9e2f-3d8a5c9e7f1b'
        }),
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const result = await response.json();
      return result.status === 'valid' || result.valid === true;
    } catch (error) {
      console.warn('Activation validation failed:', error);
      // Return false but don't throw - allow extension to continue in demo mode
      return false;
    }
  }

  /**
   * Safely check demo usage status with improved error handling
   */
  async checkDemoStatusSafely() {
    if (this.isActivated) {
      this.demoUsesRemaining = -1; // Unlimited when activated
      return;
    }

    try {
      // Try local check first for immediate response
      await this.checkLocalDemoStatus();
      
      // Then try server sync in background (non-blocking)
      this.syncWithServerInBackground();
    } catch (error) {
      console.warn('Demo status check failed, using fallback:', error);
      // Ensure we have at least 3 demo uses if nothing is stored
      if (this.demoUsesRemaining === undefined || this.demoUsesRemaining === null) {
        this.demoUsesRemaining = 3;
      }
    }
  }

  /**
   * Sync with server in background without blocking
   */
  async syncWithServerInBackground() {
    try {
      const response = await fetch('https://jobhunter.one/api/extension/check/1', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.canUse !== undefined) {
          this.demoUsesRemaining = data.trialUsed ? Math.max(0, 3 - data.trialUsed) : 3;
          this.updateLocalDemoCount();
        }
      }
    } catch (error) {
      // Silent fail - background sync
      console.log('Background server sync failed (non-critical):', error);
    }
  }

  /**
   * Check demo status using local storage
   */
  async checkLocalDemoStatus() {
    return new Promise((resolve) => {
      const storageKey = this.config.DEMO?.STORAGE_KEY || 'demo_usage_data';
      chrome.storage.local.get([storageKey], (result) => {
        const demoData = result[storageKey] || { used: 0, maxUses: 3 };
        this.demoUsesRemaining = Math.max(0, demoData.maxUses - demoData.used);
        resolve(this.demoUsesRemaining);
      });
    });
  }

  /**
   * Check if extension can be used (either activated or demo uses remaining)
   */
  async canUseExtension() {
    // If activated, always allow
    if (this.isActivated) {
      return true;
    }

    // Update demo status
    await this.checkLocalDemoStatus();
    
    // Allow if demo uses remaining
    return this.demoUsesRemaining > 0;
  }

  /**
   * Use one demo attempt with local storage update
   */
  async useDemoAttempt(missionId = null) {
    if (this.isActivated) {
      return { success: true, remaining: 'unlimited' };
    }
    
    if (this.demoUsesRemaining <= 0) {
      return { success: false, remaining: 0, message: 'Trial limit exceeded' };
    }
    
    // Update local storage
    const storageKey = this.config.DEMO?.STORAGE_KEY || 'demo_usage_data';
    
    return new Promise((resolve) => {
      chrome.storage.local.get([storageKey], (result) => {
        const demoData = result[storageKey] || { used: 0, maxUses: 3 };
        demoData.used = Math.min(demoData.used + 1, demoData.maxUses);
        
        chrome.storage.local.set({ [storageKey]: demoData }, () => {
          this.demoUsesRemaining = Math.max(0, demoData.maxUses - demoData.used);
          
          console.log(`Demo attempt used. Remaining: ${this.demoUsesRemaining}`);
          
          // Try to sync with server in background
          this.syncDemoUsageWithServer(missionId);
          
          resolve({ 
            success: true, 
            remaining: this.demoUsesRemaining,
            used: demoData.used,
            maxUses: demoData.maxUses
          });
        });
      });
    });
  }

  /**
   * Sync demo usage with server (non-blocking)
   */
  async syncDemoUsageWithServer(missionId = null) {
    try {
      const response = await fetch('https://jobhunter.one/api/extension/use-trial', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
          userId: this.userId || 'anonymous',
          missionId: missionId
        })
      });
      
      if (response.ok) {
        console.log('Demo usage synced with server');
      }
    } catch (error) {
      // Silent fail - server sync is not critical
      console.log('Server sync failed (non-critical):', error);
    }
  }

  /**
   * Update local demo count
   */
  updateLocalDemoCount() {
    const storageKey = this.config.DEMO?.STORAGE_KEY || 'demo_usage_data';
    const maxUses = this.config.DEMO?.MAX_USES || 3;
    const used = Math.max(0, maxUses - this.demoUsesRemaining);
    
    chrome.storage.local.set({ 
      [storageKey]: { 
        used: used, 
        maxUses: maxUses,
        lastUpdated: Date.now()
      } 
    });
  }

  /**
   * Activate extension with a key
   */
  async activateExtension(activationKey) {
    try {
      const isValid = await this.validateActivationKey(activationKey);
      
      if (isValid) {
        // Store activation data
        const storageKey = this.config.ACTIVATION?.STORAGE_KEY || 'activation_key_data';
        chrome.storage.local.set({ 
          [storageKey]: { 
            key: activationKey, 
            activated: true,
            activatedAt: Date.now()
          } 
        });
        
        this.isActivated = true;
        this.demoUsesRemaining = -1; // Unlimited
        
        return { success: true, message: 'Extension activated successfully!' };
      } else {
        return { success: false, message: 'Invalid activation key' };
      }
    } catch (error) {
      console.error('Activation failed:', error);
      return { success: false, message: 'Activation failed: ' + error.message };
    }
  }

  /**
   * Get status for UI display
   */
  getStatus() {
    return {
      isActivated: this.isActivated,
      demoUsesRemaining: this.demoUsesRemaining,
      canUse: this.isActivated || this.demoUsesRemaining > 0,
      userId: this.userId
    };
  }
}

// Initialize global instance
if (typeof window !== 'undefined') {
  window.activationManager = new ActivationManager();
}