/**
 * OCUS Extension Conflict Resolution
 * 
 * This script ensures that all three OCUS extensions work without conflicts.
 * It handles namespace isolation and prevents variable collisions.
 */

// Create an isolated namespace for the unified extension
if (typeof window.ocusExtensions === 'undefined') {
    window.ocusExtensions = {
        // Track which extensions are loaded
        loaded: {
            unifiedExtension: true,
            autoClicker: false,
            actionClicker: false
        },
        // Shared configuration that can be used across extensions
        sharedConfig: {},
        // Helper functions
        utils: {
            isLoginPage: function() {
                const url = window.location.href.toLowerCase();
                // Only consider the specific login URL
                return url.includes('/auth/login');
            },
            logDebug: function(message) {
                console.log('[OCUS Extensions] ' + message);
            }
        }
    };
}

// Make login functionality only activate on the login page
document.addEventListener('DOMContentLoaded', function() {
    // Only run login checks on the login page
    if (window.ocusExtensions.utils.isLoginPage()) {
        console.log('On login page - login functionality active');
    } else {
        console.log('Not on login page - login functionality inactive');
        // Disable any potential login check intervals
        if (window.loginCheckInterval) {
            clearInterval(window.loginCheckInterval);
            window.loginCheckInterval = null;
        }
    }
});

// Prevent cross-extension conflicts for element selectors
const preventSelectorConflicts = function() {
    // Add data attributes to elements to identify which extension is targeting them
    const markElementsForExtension = function(elements, extensionName) {
        elements.forEach(el => {
            if (el) el.setAttribute('data-ocus-extension', extensionName);
        });
    };
    
    // Run once DOM is loaded
    if (document.readyState !== 'loading') {
        markElementsForExtension(document.querySelectorAll('.mission-card'), 'autoClicker');
        markElementsForExtension(document.querySelectorAll('[role="button"]'), 'actionClicker');
    } else {
        document.addEventListener('DOMContentLoaded', function() {
            markElementsForExtension(document.querySelectorAll('.mission-card'), 'autoClicker');
            markElementsForExtension(document.querySelectorAll('[role="button"]'), 'actionClicker');
        });
    }
};

// Execute the conflict prevention
preventSelectorConflicts();

// Export the conflict resolution API
window.ocusConflictResolver = {
    refreshPreventionMeasures: preventSelectorConflicts
};
