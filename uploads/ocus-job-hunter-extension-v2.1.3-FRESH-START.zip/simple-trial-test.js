/**
 * MINIMAL TRIAL TEST - Completely isolated simple counting
 * This version bypasses ALL existing logic for pure testing
 */

console.log('🧪 SIMPLE TRIAL TEST LOADED');

// Initialize storage with 0
chrome.storage.local.set({ simple_trial_count: 0 }, () => {
  console.log('✅ Simple trial initialized to 0');
});

// Simple function to test trial counting
function testSimpleTrialCount() {
  chrome.storage.local.get(['simple_trial_count'], (result) => {
    const current = result.simple_trial_count || 0;
    const next = current + 1;
    
    console.log(`🔢 Simple count: ${current} → ${next}`);
    
    chrome.storage.local.set({ simple_trial_count: next }, () => {
      if (next === 1) {
        console.log('✨ Mission 1/3 - 2 remaining');
        alert('Mission 1/3 completed! 2 more remaining.');
      } else if (next === 2) {
        console.log('✨ Mission 2/3 - 1 remaining');
        alert('Mission 2/3 completed! 1 more remaining.');
      } else if (next === 3) {
        console.log('🏁 Mission 3/3 - Trial complete');
        alert('All 3 missions completed! Trial finished.');
      } else {
        console.log(`⚠️ Unexpected count: ${next}`);
      }
    });
  });
}

// Expose function globally for testing
window.testSimpleTrialCount = testSimpleTrialCount;

console.log('🧪 Simple trial test ready. Call testSimpleTrialCount() to test.');