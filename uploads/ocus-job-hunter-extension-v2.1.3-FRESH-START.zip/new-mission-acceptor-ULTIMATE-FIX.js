/**
 * OCUS Unified Extension - New Mission Acceptor (ULTIMATE FIX)
 * 
 * ULTIMATE BUG FIX: Complete reset of trial system with bulletproof logic
 * This version clears ALL old storage data and uses ultra-simple counting
 */

// Configuration
const CONFIG = {
  enabled: true,
  autoRedirect: true,
  redirectDelay: 3000,
  maxAttempts: 20,
  attemptInterval: 800,
  debug: true,
  homepage: 'https://app.ocus.com/'
};

/**
 * ULTIMATE FIX: Clear all old storage data and reset trial system
 */
async function resetTrialSystemCompletely() {
  return new Promise((resolve) => {
    // List all possible old storage keys that might interfere
    const keysToCheck = [
      'ocus_trial_count',
      'session_initialized', 
      'trial_system_ever_initialized',
      'trialUsed',
      'demo_usage_data',
      'activation_key_data',
      'isActivated',
      'mission_count',
      'trial_missions_used',
      'processedMissions',
      'config'
    ];
    
    chrome.storage.local.get(keysToCheck, (result) => {
      console.log('🔍 CURRENT STORAGE BEFORE RESET:', result);
      
      // Check if we need to do a complete reset
      const needsReset = !result.ultimate_fix_applied;
      
      if (needsReset) {
        console.log('🧹 APPLYING ULTIMATE FIX - CLEARING ALL OLD DATA');
        
        // Clear ALL potentially conflicting data
        chrome.storage.local.clear(() => {
          // Set only the essential data with our new system
          chrome.storage.local.set({
            ocus_mission_count: 0,  // Use new key name to avoid conflicts
            ultimate_fix_applied: true,
            system_version: '2.1.2-ultimate',
            reset_timestamp: Date.now()
          }, () => {
            console.log('✅ ULTIMATE FIX APPLIED - STORAGE RESET COMPLETE');
            resolve();
          });
        });
      } else {
        console.log('✅ ULTIMATE FIX ALREADY APPLIED - USING CLEAN SYSTEM');
        resolve();
      }
    });
  });
}

/**
 * Check trial status - returns whether user can accept missions
 */
async function checkTrialStatus() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(['isActivated', 'activation_key_data', 'ocus_mission_count'], (result) => {
        if (chrome.runtime.lastError) {
          console.log('Chrome storage error, assuming trial active');
          resolve({ canAccept: true, remaining: 3, used: 0 });
          return;
        }
        
        // Check if user is activated
        const isActivated = result.isActivated || 
                           (result.activation_key_data && result.activation_key_data.isActivated);
        
        if (isActivated) {
          console.log('✅ USER IS ACTIVATED - UNLIMITED USAGE');
          resolve({ canAccept: true, remaining: 'unlimited', used: 0 });
          return;
        }
        
        // Use our clean mission counter
        const missionsUsed = result.ocus_mission_count || 0;
        const remaining = Math.max(0, 3 - missionsUsed);
        
        console.log(`📊 TRIAL STATUS: ${missionsUsed}/3 missions used, ${remaining} remaining`);
        
        resolve({ 
          canAccept: remaining > 0, 
          remaining: remaining,
          used: missionsUsed
        });
      });
    } catch (error) {
      console.log('❌ Error checking trial status:', error);
      resolve({ canAccept: true, remaining: 3, used: 0 });
    }
  });
}

// State tracking
let missionAccepted = false;
let attemptCount = 0;
let attemptTimer = null;
let updateInProgress = false;

/**
 * Initialize the mission acceptor
 */
async function init() {
  console.log('🚀 MISSION ACCEPTOR INITIALIZING (ULTIMATE FIX VERSION)');
  
  // STEP 1: Apply ultimate fix if needed
  await resetTrialSystemCompletely();
  
  // STEP 2: Check trial status
  const trialStatus = await checkTrialStatus();
  if (!trialStatus.canAccept) {
    console.log('❌ TRIAL EXHAUSTED - MISSION ACCEPTOR DISABLED');
    showStatus('Trial exhausted! Activate to continue accepting missions.', 'error');
    return;
  }
  
  console.log(`✅ TRIAL ACTIVE: ${trialStatus.used}/3 used, ${trialStatus.remaining} remaining`);
  
  // STEP 3: Only run on mission pages
  if (!isMissionPage()) {
    console.log('ℹ️ Not a mission page, skipping initialization');
    return;
  }
  
  // STEP 4: Start the acceptance process
  showStatus('Looking for Accept button...', 'info');
  startAcceptProcess();
  setupMutationObserver();
  
  console.log('✅ MISSION ACCEPTOR INITIALIZED SUCCESSFULLY');
}

/**
 * Check if the current page is a mission page
 */
function isMissionPage() {
  const url = window.location.href;
  
  if (url.includes('app.ocus.com/missions/')) {
    console.log('✅ Mission page detected from URL pattern');
    return true;
  }
  
  if (url.includes('/mission/') || url.includes('/assignments/') || url.includes('ocus.com/assignment')) {
    console.log('✅ Mission page detected from URL pattern');
    return true;
  }
  
  // Check for accept button
  try {
    const exactButton = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (exactButton) {
      const buttonText = (exactButton.innerText || exactButton.textContent || '').trim();
      if (buttonText === 'Accept assignment') {
        console.log('✅ Mission page detected from accept button');
        return true;
      }
    }
  } catch (error) {
    console.log('Error checking for button', error);
  }
  
  console.log('❌ Not a mission page');
  return false;
}

/**
 * Start the accept process
 */
function startAcceptProcess() {
  if (missionAccepted) return;
  attemptAccept();
}

/**
 * Attempt to find and click the accept button
 */
async function attemptAccept() {
  if (missionAccepted) {
    console.log('Mission already accepted, skipping attempt');
    return;
  }
  
  // Check trial status before each attempt
  const trialStatus = await checkTrialStatus();
  if (!trialStatus.canAccept) {
    console.log('❌ Trial exhausted during attempt, stopping');
    showStatus('Trial exhausted! Activate to continue.', 'error');
    return;
  }
  
  attemptCount++;
  console.log(`🔄 Accept attempt ${attemptCount}/${CONFIG.maxAttempts}`);
  
  if (attemptCount > CONFIG.maxAttempts) {
    console.log('❌ Max attempts reached, giving up');
    showStatus('Could not find Accept button after maximum attempts', 'error');
    return;
  }
  
  const button = findAcceptButton();
  
  if (button) {
    console.log('✅ Accept button found, attempting to click');
    
    if (clickAcceptButton(button)) {
      await handleAcceptSuccess();
      return;
    } else {
      console.log('❌ Click failed, will retry');
    }
  } else {
    console.log(`⏳ Accept button not found (attempt ${attemptCount})`);
  }
  
  // Schedule next attempt
  attemptTimer = setTimeout(attemptAccept, CONFIG.attemptInterval);
}

/**
 * Find the accept button
 */
function findAcceptButton() {
  // Primary selector
  const primarySelectors = [
    'button[data-test="accept-assignment-btn"]'
  ];
  
  for (const selector of primarySelectors) {
    try {
      const buttons = document.querySelectorAll(selector);
      for (const button of buttons) {
        const buttonText = (button.innerText || button.textContent || '').trim();
        if (buttonText === 'Accept assignment') {
          console.log(`✅ Found accept button: ${selector}`);
          return button;
        }
      }
    } catch (error) {
      console.log(`❌ Error with selector ${selector}:`, error);
    }
  }
  
  // Fallback: search all buttons
  try {
    const allButtons = document.querySelectorAll('button');
    for (const button of allButtons) {
      const buttonText = (button.innerText || button.textContent || '').trim();
      if (buttonText === 'Accept assignment' || buttonText === 'Accept') {
        console.log(`✅ Found accept button by text: "${buttonText}"`);
        return button;
      }
    }
  } catch (error) {
    console.log('❌ Error in button search:', error);
  }
  
  return null;
}

/**
 * Click the accept button
 */
function clickAcceptButton(button) {
  if (!button) return false;
  
  try {
    button.scrollIntoView({ behavior: 'smooth', block: 'center' });
    console.log('📍 Scrolled button into view');
    
    button.click();
    console.log('✅ Button clicked successfully');
    return true;
  } catch (error) {
    console.log('❌ Click failed:', error);
    return false;
  }
}

/**
 * Handle successful mission acceptance
 */
async function handleAcceptSuccess() {
  console.log('🎉 MISSION ACCEPTED SUCCESSFULLY!');
  missionAccepted = true;
  showStatus('Mission accepted! Updating counter...', 'success');
  
  // Clear any pending attempts
  clearTimeout(attemptTimer);
  
  // Update trial counter
  await updateMissionCounter();
  
  // Redirect after delay
  if (CONFIG.autoRedirect) {
    setTimeout(() => {
      console.log('🏠 Redirecting to homepage');
      window.location.href = CONFIG.homepage;
    }, CONFIG.redirectDelay);
  }
}

/**
 * ULTIMATE FIX: Ultra-simple mission counter update
 */
async function updateMissionCounter() {
  // Prevent double execution
  if (updateInProgress) {
    console.log('🚫 UPDATE ALREADY IN PROGRESS - SKIPPING');
    return;
  }
  
  updateInProgress = true;
  console.log('📊 === MISSION COUNTER UPDATE START ===');
  
  return new Promise((resolve) => {
    chrome.storage.local.get(['ocus_mission_count'], (result) => {
      const currentCount = result.ocus_mission_count || 0;
      const newCount = currentCount + 1;
      
      console.log(`📈 MISSION COUNT: ${currentCount} → ${newCount}`);
      
      chrome.storage.local.set({ ocus_mission_count: newCount }, () => {
        console.log(`✅ MISSION COUNT SAVED: ${newCount}`);
        
        // Show appropriate message
        if (newCount === 1) {
          console.log('🎯 MISSION 1/3 COMPLETED');
          showStatus('Mission 1/3 completed! 2 more trial missions remaining.', 'success');
          showTrialCounter(newCount, 2);
        } else if (newCount === 2) {
          console.log('🎯 MISSION 2/3 COMPLETED');
          showStatus('Mission 2/3 completed! 1 more trial mission remaining.', 'success');
          showTrialCounter(newCount, 1);
        } else if (newCount === 3) {
          console.log('🏁 MISSION 3/3 COMPLETED - TRIAL FINISHED');
          showStatus('All 3 trial missions completed! Time to activate.', 'info');
          showTrialCounter(newCount, 0);
          setTimeout(() => {
            if (confirm('You have completed all 3 free trial missions! Ready to unlock unlimited mission acceptance?')) {
              window.open('https://jobhunter.one/', '_blank');
            }
          }, 2000);
        } else if (newCount > 3) {
          console.log('⚠️ COUNT EXCEEDED 3 - THIS SHOULD NOT HAPPEN');
          showStatus('Trial system error - please contact support.', 'error');
        }
        
        updateInProgress = false;
        resolve();
      });
    });
  });
}

/**
 * Show trial counter
 */
function showTrialCounter(used, remaining) {
  let counterElement = document.querySelector('#ocus-trial-counter');
  
  if (!counterElement) {
    counterElement = document.createElement('div');
    counterElement.id = 'ocus-trial-counter';
    counterElement.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.9);
      color: white;
      padding: 12px 16px;
      border-radius: 20px;
      font-family: Arial, sans-serif;
      font-size: 13px;
      font-weight: bold;
      z-index: 10000;
      border: 2px solid #007bff;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(counterElement);
  }
  
  if (remaining > 0) {
    counterElement.textContent = `OCUS Trial: ${used}/3 used (${remaining} left)`;
    counterElement.style.borderColor = '#007bff';
  } else {
    counterElement.textContent = `OCUS Trial: Complete (3/3)`;
    counterElement.style.borderColor = '#dc3545';
    counterElement.style.background = 'rgba(220, 53, 69, 0.9)';
  }
  
  console.log(`📊 Updated counter: ${used}/3 used, ${remaining} remaining`);
}

/**
 * Set up mutation observer
 */
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    if (missionAccepted) return;
    
    let shouldCheck = false;
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        shouldCheck = true;
      }
    });
    
    if (shouldCheck) {
      const button = findAcceptButton();
      if (button && !missionAccepted) {
        console.log('✅ Button found after DOM change');
        if (clickAcceptButton(button)) {
          handleAcceptSuccess();
        }
      }
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  console.log('👁️ Mutation observer set up');
}

/**
 * Show status to user
 */
function showStatus(message, type = 'info') {
  console.log(`📢 Status (${type}): ${message}`);
  
  let statusElement = document.getElementById('ocus-status');
  
  if (!statusElement) {
    statusElement = document.createElement('div');
    statusElement.id = 'ocus-status';
    statusElement.style.cssText = `
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      padding: 12px 24px;
      border-radius: 25px;
      font-family: Arial, sans-serif;
      font-size: 14px;
      font-weight: bold;
      z-index: 10001;
      max-width: 400px;
      text-align: center;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(statusElement);
  }
  
  statusElement.textContent = message;
  
  switch (type) {
    case 'success':
      statusElement.style.background = 'linear-gradient(135deg, #28a745 0%, #20c997 100%)';
      statusElement.style.color = 'white';
      break;
    case 'error':
      statusElement.style.background = 'linear-gradient(135deg, #dc3545 0%, #fd7e14 100%)';
      statusElement.style.color = 'white';
      break;
    default:
      statusElement.style.background = 'linear-gradient(135deg, #007bff 0%, #6f42c1 100%)';
      statusElement.style.color = 'white';
  }
  
  // Auto-hide
  setTimeout(() => {
    if (statusElement && statusElement.parentNode) {
      statusElement.style.opacity = '0';
      setTimeout(() => {
        if (statusElement.parentNode) {
          statusElement.parentNode.removeChild(statusElement);
        }
      }, 300);
    }
  }, type === 'error' ? 8000 : 5000);
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Also initialize on page focus
window.addEventListener('focus', () => {
  if (!missionAccepted && isMissionPage()) {
    console.log('🔄 Page focused, checking if reinit needed');
    setTimeout(init, 1000);
  }
});

console.log('🔧 OCUS Mission Acceptor (ULTIMATE FIX) loaded');