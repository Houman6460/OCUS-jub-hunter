/**
 * FORCE RESET SCRIPT - Clears ALL extension data on version change
 * This runs on extension startup and clears any cached trial data
 */

console.log('🔄 FORCE RESET SCRIPT STARTING');

const CURRENT_VERSION = '2.1.3';
const VERSION_KEY = 'extension_version';

// Check if this is a new version or first install
chrome.storage.local.get([VERSION_KEY], (result) => {
  const storedVersion = result[VERSION_KEY];
  
  if (!storedVersion || storedVersion !== CURRENT_VERSION) {
    console.log(`🧹 VERSION CHANGE DETECTED: ${storedVersion || 'none'} → ${CURRENT_VERSION}`);
    console.log('🔥 CLEARING ALL CACHED DATA');
    
    // Clear ALL extension storage
    chrome.storage.local.clear(() => {
      console.log('✅ ALL STORAGE CLEARED');
      
      // Set fresh version and initialize clean trial system
      chrome.storage.local.set({
        [VERSION_KEY]: CURRENT_VERSION,
        trial_missions_completed: 0,
        unified_trial_system_v3: true,
        system_initialized_at: Date.now(),
        force_reset_applied: true
      }, () => {
        console.log(`✅ FRESH SYSTEM INITIALIZED (v${CURRENT_VERSION})`);
        console.log('🎯 TRIAL: 0/3 missions completed - READY FOR USE');
      });
    });
  } else {
    console.log(`✅ VERSION ${CURRENT_VERSION} ALREADY ACTIVE`);
  }
});

console.log('🔧 Force reset script loaded');