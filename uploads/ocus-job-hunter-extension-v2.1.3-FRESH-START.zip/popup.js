/**
 * OCUS Unified Extension - Popup Script
 * 
 * Manages the configuration UI and provides controls for the extension.
 */

// Default configuration
const defaultConfig = {
  activation: {
    isActivated: false,
    activationKey: '',
    activatedAt: null
  },
  demo: {
    usesRemaining: 3,
    maxUses: 3,
    lastUsed: null
  },
  autoLogin: {
    enabled: false,
    username: '',
    password: ''
  },
  missionMonitor: {
    enabled: false,
    refreshInterval: 30000, // 30 seconds
    showNotifications: true,
    openInNewTab: true
  },
  missionAccept: {
    enabled: false,
    autoClose: true,
    closeDelay: 2000 // 2 seconds
  },
  sounds: {
    enabled: true,
    missionAccepted: true
  },
  pageRefresh: {
    enabled: false,
    intervalSeconds: 30,
    showCountdown: true
  },
  processedMissions: []
};

// Default statistics
const defaultStats = {
  missionsRefreshing: 0,
  missionsOpened: 0,
  missionsAccepted: 0,
  loginAttempts: 0,
  successfulLogins: 0
};

// Function to reset localStorage counters
function resetLocalStorageCounters() {
  localStorage.setItem('ocus_missions_opened', '0');
  console.log('Reset localStorage counters');
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  // Load configuration and stats from storage
  loadConfigAndStats();
  
  // Set up event listeners
  document.getElementById('saveConfig').addEventListener('click', saveConfig);
  document.getElementById('emergencyStop').addEventListener('click', emergencyStop);
  document.getElementById('resetStats').addEventListener('click', resetStats);
  document.getElementById('activateButton').addEventListener('click', activateExtension);
  
  // Add event listeners for refresh timer buttons
  const refreshButtons = document.querySelectorAll('.refresh-option');
  refreshButtons.forEach(button => {
    button.addEventListener('click', function() {
      // Get the value from the button's data attribute
      const seconds = parseInt(this.getAttribute('data-value'));
      // Set the value to the custom refresh time input
      document.getElementById('customRefreshTime').value = seconds;
    });
  });
  
  // Custom refresh time button
  document.getElementById('setCustomRefresh').addEventListener('click', function() {
    // Highlight the custom value and ensure it's valid
    const customInput = document.getElementById('customRefreshTime');
    if (customInput.value && parseInt(customInput.value) > 0) {
      // Deselect any selected refresh option buttons
      refreshButtons.forEach(btn => btn.classList.remove('selected'));
    }
  });
});

// Load configuration and stats from storage
function loadConfigAndStats() {
  // Get configuration from storage
  chrome.storage.local.get(['config', 'stats'], function(result) {
    const config = result.config || defaultConfig;
    const stats = result.stats || defaultStats;
    
    // Auto Login Configuration
    document.getElementById('autoLoginEnabled').checked = config.autoLogin?.enabled || false;
    document.getElementById('username').value = config.autoLogin?.username || '';
    document.getElementById('password').value = config.autoLogin?.password || '';

    
    // Mission Monitor Configuration
    document.getElementById('missionMonitorEnabled').checked = config.missionMonitor?.enabled || false;
    document.getElementById('refreshInterval').value = (config.missionMonitor?.refreshInterval || 30000) / 1000; // Convert to seconds
    document.getElementById('showNotifications').checked = config.missionMonitor?.showNotifications || true;

    
    // Mission Acceptor Configuration
    document.getElementById('missionAcceptEnabled').checked = config.missionAccept?.enabled || false;
    document.getElementById('autoCloseTab').checked = config.missionAccept?.autoClose || true;
    document.getElementById('closeDelay').value = (config.missionAccept?.closeDelay || 2000) / 1000; // Convert to seconds
    
    // Load sound settings
    document.getElementById('soundEnabled').checked = config.sounds ? (config.sounds.enabled && config.sounds.missionAccepted) || false : true;
    
    // Page Refresh Timer Configuration
    document.getElementById('pageRefreshEnabled').checked = config.pageRefresh?.enabled || false;
    document.getElementById('customRefreshTime').value = config.pageRefresh?.intervalSeconds || 30;
    document.getElementById('showRefreshCountdown').checked = config.pageRefresh?.showCountdown || true;
    
    // Highlight the selected refresh time button if it matches a preset
    const presetValues = [5, 10, 20, 30];
    const refreshTime = config.pageRefresh?.intervalSeconds || 30;
    if (presetValues.includes(refreshTime)) {
      const buttons = document.querySelectorAll('.refresh-option');
      buttons.forEach(button => {
        if (parseInt(button.getAttribute('data-value')) === refreshTime) {
          button.classList.add('selected');
        }
      });
    }
    
    // Update activation status
    updateActivationStatus(config);
    
    // Update statistics display
    document.getElementById('missionsRefreshing').textContent = stats.totalRefreshes || 0;
    document.getElementById('missionsOpened').textContent = stats.missionsOpened || 0;
    document.getElementById('missionsAccepted').textContent = stats.missionsAccepted || 0;
    document.getElementById('loginAttempts').textContent = stats.loginAttempts || 0;
    document.getElementById('successfulLogins').textContent = stats.loginAttempts || 0;
    
    // Update main status badge
    updateMainStatus(config);
    
    // If activated, fetch referral code
    if (config.activation?.isActivated && config.activation?.activationKey) {
      fetchUserReferralCode(config.activation.activationKey);
    }
  });
}

// Fetch user's referral code from server
function fetchUserReferralCode(activationKey) {
  // For demo purposes, use a demo customer ID
  // In production, you'd extract the customer ID from the activation key
  const customerId = 'demo-customer-123';
  
  fetch(`https://jobhunter.one/api/extension/referral-code/${customerId}`)
    .then(response => response.json())
    .then(data => {
      if (data.success && data.referralCode) {
        chrome.storage.local.set({
          'user_referral_code': data.referralCode
        });
        console.log('Referral code stored:', data.referralCode);
      }
    })
    .catch(error => {
      console.error('Failed to fetch referral code:', error);
      // Store a demo referral code for testing
      chrome.storage.local.set({
        'user_referral_code': 'DEMO123'
      });
    });
}

// Save configuration to storage
function saveConfig() {
  // Get configuration from storage
  chrome.storage.local.get(['config'], function(result) {
    let config = result.config || defaultConfig;
    
    // Update Auto Login Configuration
    config.autoLogin = config.autoLogin || {};
    config.autoLogin.enabled = document.getElementById('autoLoginEnabled').checked;
    config.autoLogin.username = document.getElementById('username').value;
    config.autoLogin.password = document.getElementById('password').value;

    
    // Update Mission Monitor Configuration
    config.missionMonitor = config.missionMonitor || {};
    config.missionMonitor.enabled = document.getElementById('missionMonitorEnabled').checked;
    config.missionMonitor.refreshInterval = (parseInt(document.getElementById('refreshInterval').value) || 30) * 1000; // Convert to milliseconds
    config.missionMonitor.showNotifications = document.getElementById('showNotifications').checked;

    
    // Update Mission Acceptor Configuration
    config.missionAccept = config.missionAccept || {};
    config.missionAccept.enabled = document.getElementById('missionAcceptEnabled').checked;
    config.missionAccept.autoClose = document.getElementById('autoCloseTab').checked;
    config.missionAccept.closeDelay = (parseInt(document.getElementById('closeDelay').value) || 2) * 1000; // Convert to milliseconds
    
    // Update Sound Settings
    config.sounds = config.sounds || {};
    config.sounds.enabled = document.getElementById('soundEnabled').checked;
    config.sounds.missionAccepted = document.getElementById('soundEnabled').checked;
    
    // Update Page Refresh Timer Configuration
    config.pageRefresh = config.pageRefresh || {};
    config.pageRefresh.enabled = document.getElementById('pageRefreshEnabled').checked;
    config.pageRefresh.intervalSeconds = parseInt(document.getElementById('customRefreshTime').value) || 30;
    config.pageRefresh.showCountdown = document.getElementById('showRefreshCountdown').checked;
    
    // Save configuration to storage
    chrome.storage.local.set({ config: config }, function() {
      // Show success notification
      showNotification('Configuration saved successfully!', 'success');
      
      // Update main status badge
      updateMainStatus(config);
      
      // Notify background script of configuration update
      chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        config: config
      });
      
      // Send message directly to the active tab
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        if (tabs && tabs.length > 0) {
          console.log('Sending config update to active tab:', tabs[0].id);
          chrome.tabs.sendMessage(tabs[0].id, {
            type: 'UPDATE_CONFIG',
            config: config
          }, function(response) {
            console.log('Active tab response:', response);
          });
        }
      });
      
      // Also broadcast to all OCUS domain tabs
      chrome.tabs.query({url: ["*://app.ocus.com/*", "*://*.ocus.work/*"]}, function(tabs) {
        if (tabs && tabs.length > 0) {
          console.log('Broadcasting config update to', tabs.length, 'OCUS tabs');
          tabs.forEach(function(tab) {
            chrome.tabs.sendMessage(tab.id, {
              type: 'UPDATE_CONFIG',
              config: config
            });
          });
        } else {
          console.log('No OCUS tabs found to send configuration');
        }
      });
    });
  });
}

// Emergency stop all automation
function emergencyStop() {
  // Get configuration from storage
  chrome.storage.local.get(['config'], function(result) {
    let config = result.config || defaultConfig;
    
    // Disable all automation
    if (config.autoLogin) config.autoLogin.enabled = false;
    if (config.missionMonitor) config.missionMonitor.enabled = false;
    if (config.missionAccept) config.missionAccept.enabled = false;
    
    // Save configuration to storage
    chrome.storage.local.set({ config: config }, function() {
      // Update UI
      document.getElementById('autoLoginEnabled').checked = false;
      document.getElementById('missionMonitorEnabled').checked = false;
      document.getElementById('missionAcceptEnabled').checked = false;
      
      // Show success notification
      showNotification('All automation has been disabled!', 'error');
      
      // Update main status badge
      updateMainStatus(config);
      
      // Notify background script of configuration update
      chrome.runtime.sendMessage({
        type: 'UPDATE_CONFIG',
        config: config
      });
      
      // Send emergency stop notification
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Emergency Stop',
        message: 'All automation has been disabled!',
        priority: 2
      });
    });
  });
}

// Reset statistics
function resetStats() {
  // Reset localStorage counters first
  resetLocalStorageCounters();
  
  // Save default statistics to storage
  chrome.storage.local.set({ stats: defaultStats }, function() {
    // Update statistics display
    document.getElementById('missionsRefreshing').textContent = 0;
    document.getElementById('missionsOpened').textContent = 0;
    document.getElementById('missionsAccepted').textContent = 0;
    document.getElementById('loginAttempts').textContent = 0;
    document.getElementById('successfulLogins').textContent = 0;
    
    // Show success notification
    showNotification('Statistics have been reset!', 'success');
  });
}

// Listen for mission counter updates from content scripts
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.type === 'UPDATE_MISSION_COUNTER') {
    const acceptedElement = document.getElementById('missionsAccepted');
    if (acceptedElement) {
      acceptedElement.textContent = request.count;
    }
    
    // Update storage as well
    chrome.storage.local.get(['stats'], function(result) {
      let stats = result.stats || defaultStats;
      stats.missionsAccepted = request.count;
      chrome.storage.local.set({ stats: stats });
    });
  }
  
  // Listen for interval changes from floating panel
  if (request.type === 'INTERVAL_CHANGED') {
    const customRefreshTimeInput = document.getElementById('customRefreshTime');
    if (customRefreshTimeInput) {
      customRefreshTimeInput.value = request.interval;
    }
    
    // Update quick selection buttons
    const refreshOptions = document.querySelectorAll('.refresh-option');
    refreshOptions.forEach(option => {
      option.classList.remove('selected');
      if (parseInt(option.dataset.value) === request.interval) {
        option.classList.add('selected');
      }
    });
  }
});

// Show notification in the popup
function showNotification(message, type) {
  const notification = document.getElementById('notification');
  notification.textContent = message;
  notification.className = 'notification ' + type;
  
  // Hide notification after 3 seconds
  setTimeout(function() {
    notification.className = 'notification';
  }, 3000);
}

// Update activation status
function updateActivationStatus(config) {
  const activationStatus = document.getElementById('activationStatus');
  const activationContent = document.getElementById('activationContent');
  const activatedContent = document.getElementById('activatedContent');
  const demoUsesRemaining = document.getElementById('demoUsesRemaining');
  const extensionStatus = document.getElementById('extensionStatus');
  
  if (config.activation?.isActivated) {
    activationStatus.textContent = 'Activated';
    activationStatus.className = 'status-badge';
    activationContent.style.display = 'none';
    activatedContent.style.display = 'block';
  } else {
    const remaining = config.demo?.usesRemaining || 3;
    activationStatus.textContent = 'Demo Mode';
    activationStatus.className = 'status-badge warning';
    activationContent.style.display = 'block';
    activatedContent.style.display = 'none';
    
    demoUsesRemaining.textContent = remaining;
    
    // Clear existing content
    extensionStatus.innerHTML = '';
    
    if (remaining > 0) {
      // Create main text
      const mainText = document.createElement('span');
      mainText.textContent = `**START FREE** - ${remaining}/3 trial missions remaining`;
      extensionStatus.appendChild(mainText);
      
      // Add line break
      extensionStatus.appendChild(document.createElement('br'));
      
      // Create small container
      const smallContainer = document.createElement('small');
      const link = document.createElement('a');
      // Try to get user's referral code from extension storage, fallback to general checkout
      chrome.storage.local.get(['user_referral_code'], (result) => {
        if (result.user_referral_code) {
          link.href = `https://jobhunter.one/checkout?ref=${result.user_referral_code}`;
        } else {
          link.href = 'https://jobhunter.one/checkout';
        }
      });
      link.target = '_blank';
      link.style.color = '#2563EB';
      link.style.textDecoration = 'underline';
      link.textContent = '🔑 Get Activation Key';
      
      smallContainer.appendChild(link);
      extensionStatus.appendChild(smallContainer);
    } else {
      // Create main text
      const mainText = document.createElement('span');
      mainText.textContent = 'Demo finished!';
      extensionStatus.appendChild(mainText);
      
      // Add line break
      extensionStatus.appendChild(document.createElement('br'));
      
      // Create small container
      const smallContainer = document.createElement('small');
      const link = document.createElement('a');
      // Try to get user's referral code from extension storage, fallback to general checkout
      chrome.storage.local.get(['user_referral_code'], (result) => {
        if (result.user_referral_code) {
          link.href = `https://jobhunter.one/checkout?ref=${result.user_referral_code}`;
        } else {
          link.href = 'https://jobhunter.one/checkout';
        }
      });
      link.target = '_blank';
      link.style.color = '#4CAF50';
      link.style.textDecoration = 'underline';
      link.style.fontWeight = 'bold';
      link.textContent = '🔑 Download Activation Key Now';
      
      smallContainer.appendChild(link);
      extensionStatus.appendChild(smallContainer);
    }
  }
}

// Activate extension function
async function activateExtension() {
  const activationKey = document.getElementById('activationKey').value.trim();
  const errorDiv = document.getElementById('activation-error');
  
  if (!activationKey) {
    errorDiv.textContent = 'Please enter an activation code';
    errorDiv.style.display = 'block';
    return;
  }
  
  // Get version token from manifest
  const manifest = chrome.runtime.getManifest();
  const versionToken = manifest.version_token || 'b7d3f8e2-4a1b-4c7d-9e2f-3d8a5c9e7f1b';
  
  try {
    // Show loading state
    const activateButton = document.getElementById('activateButton');
    activateButton.disabled = true;
    activateButton.textContent = 'Activating...';
    errorDiv.style.display = 'none';
    
    // Validate activation code with backend - using placeholder URL for now
    const validateUrl = 'https://ocusjobhunter.com/api/activation/validate';
    console.log('Validating activation code:', activationKey);
    
    // For now, simulate successful activation since backend is not deployed
    // In production, uncomment the actual API calls below
    /*
    const response = await fetch(validateUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        code: activationKey,
        versionToken: versionToken
      })
    });
    
    const data = await response.json();
    
    if (response.ok && data.success) {
      // Activate the code
      const activateResponse = await fetch('https://ocusjobhunter.com/api/activation/activate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          code: activationKey,
          deviceId: await getDeviceId()
        })
      });
      
      const activateData = await activateResponse.json();
      
      if (activateResponse.ok && activateData.success) {
    */
    
    // Temporary validation for demo
    const validKeys = ['OCUS-2024-DEMO-KEY', 'OCUS-TRIAL-2024-EXT'];
    if (validKeys.includes(activationKey)) {
      // Get config from storage
      chrome.storage.local.get(['config'], function(result) {
        let config = result.config || defaultConfig;
        
        // Update activation status
        config.activation.isActivated = true;
        config.activation.activationKey = activationKey;
        config.activation.activatedAt = new Date().toISOString();
        config.activation.customerId = 'demo-customer-' + Date.now();
        
        // Reset demo uses to show unlimited
        config.demo.usesRemaining = -1; // -1 indicates unlimited
        
        // Save config
        chrome.storage.local.set({ config: config }, function() {
          // Update UI
          updateActivationStatus(config);
          
          // Clear the input
          document.getElementById('activationKey').value = '';
          
          // Show success notification
          showNotification('Extension activated successfully!', 'success');
          
          // Update the demo uses counter to show unlimited
          updateDemoUsesCounter(config);
          
          // Update customer ID display
          const customerIdElement = document.getElementById('activated-customer-id');
          if (customerIdElement) {
            customerIdElement.textContent = config.activation.customerId || '-';
          }
          
          // Notify background script
          chrome.runtime.sendMessage({
            type: 'UPDATE_CONFIG',
            config: config
          });
          
          // Fetch referral code for the newly activated user
          fetchUserReferralCode(activationKey);
        });
      });
    } else {
      throw new Error('Invalid activation code');
    }
    /*
      } else {
        throw new Error(activateData.error || 'Failed to activate code');
      }
    } else {
      throw new Error(data.error || 'Invalid activation code');
    }
    */
  } catch (error) {
    errorDiv.textContent = error.message;
    errorDiv.style.display = 'block';
  } finally {
    // Reset button state
    const activateButton = document.getElementById('activateButton');
    activateButton.disabled = false;
    activateButton.textContent = '🚀 Activate Extension';
  }
}

// Helper function to get unique device ID
async function getDeviceId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['deviceId'], function(result) {
      if (result.deviceId) {
        resolve(result.deviceId);
      } else {
        // Generate new device ID
        const deviceId = 'ext-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        chrome.storage.local.set({ deviceId: deviceId }, function() {
          resolve(deviceId);
        });
      }
    });
  });
}

// Update main status badge
function updateMainStatus(config) {
  const mainStatus = document.getElementById('mainStatus');
  
  // Check if any automation is enabled
  const anyEnabled = (config.autoLogin?.enabled || 
                     config.missionMonitor?.enabled || 
                     config.missionAccept?.enabled) || false;
  
  // Update status badge based on activation status
  if (config.activation?.isActivated) {
    if (anyEnabled) {
      mainStatus.textContent = 'Active';
      mainStatus.className = 'status-badge';
    } else {
      mainStatus.textContent = 'Licensed';
      mainStatus.className = 'status-badge';
    }
  } else {
    const remaining = config.demo?.usesRemaining || 3;
    if (remaining > 0) {
      mainStatus.textContent = `**FREE** (${remaining})`;
      mainStatus.className = 'status-badge warning';
    } else {
      mainStatus.textContent = 'Get Key';
      mainStatus.className = 'status-badge disabled';
    }
  }
}
