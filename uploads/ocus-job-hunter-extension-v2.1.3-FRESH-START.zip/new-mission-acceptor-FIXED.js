/**
 * OCUS Unified Extension - New Mission Acceptor (FIXED)
 * 
 * CRITICAL BUG FIX: Trial counter was being reset on every page load
 * Fixed to properly track trial usage across sessions
 */

// Configuration
const CONFIG = {
  enabled: true,
  autoRedirect: true,
  redirectDelay: 3000, // 3 seconds - as requested by user
  maxAttempts: 20,
  attemptInterval: 800, // Faster interval to ensure we catch the button quickly
  debug: true, // Set to true for detailed logging
  homepage: 'https://app.ocus.com/' // Homepage URL to redirect to after acceptance
};

/**
 * Check trial status - returns whether user can accept missions
 */
async function checkTrialStatus() {
  return new Promise((resolve) => {
    try {
      // Check activation and simple trial counter
      chrome.storage.local.get(['isActivated', 'activation_key_data', 'ocus_trial_count'], (result) => {
        if (chrome.runtime.lastError) {
          log('Chrome storage error, assuming trial active');
          resolve({ canAccept: true, remaining: 3 });
          return;
        }
        
        // Check if user is activated through any method
        const isActivated = result.isActivated || 
                           (result.activation_key_data && result.activation_key_data.isActivated);
        
        if (isActivated) {
          log('User is activated - unlimited usage');
          resolve({ canAccept: true, remaining: 'unlimited' });
          return;
        }
        
        // Use single, simple trial counter - FIXED: Don't reset this value
        const trialUsed = result.ocus_trial_count || 0;
        
        const remaining = Math.max(0, 3 - trialUsed);
        
        log(`Trial status check: ${trialUsed}/3 used, ${remaining} remaining`);
        log('Storage data:', { 
          trialUsed: result.trialUsed, 
          demoData: result.demo_usage_data,
          isActivated: result.isActivated,
          activationData: result.activation_key_data
        });
        
        resolve({ 
          canAccept: remaining > 0, 
          remaining: remaining,
          trialUsed: trialUsed
        });
      });
    } catch (error) {
      log('Error checking trial status:', error);
      // Default to allowing usage if we can't check
      resolve({ canAccept: true, remaining: 3, trialUsed: 0 });
    }
  });
}

// State tracking
let missionAccepted = false;
let attemptCount = 0;
let attemptTimer = null;

/**
 * Initialize the mission acceptor
 * FIXED: Don't reset trial count on initialization - only initialize once EVER
 */
async function init() {
  log('Mission acceptor initializing...');
  
  // FIXED: Only initialize trial count if it has NEVER been set before
  chrome.storage.local.get(['ocus_trial_count', 'trial_system_ever_initialized'], (result) => {
    if (!result.trial_system_ever_initialized) {
      // This is the FIRST TIME EVER - set initial values
      chrome.storage.local.set({ 
        ocus_trial_count: 0,
        trial_system_ever_initialized: true,
        first_initialized_at: Date.now()
      }, () => {
        log('🔄 TRIAL SYSTEM FIRST-TIME INITIALIZATION: Set to 0');
      });
    } else {
      log(`🔍 EXISTING USER: Trial count is ${result.ocus_trial_count || 0}/3`);
    }
  });
  
  // Check trial status first
  const trialStatus = await checkTrialStatus();
  if (!trialStatus.canAccept) {
    log('Trial exhausted, mission acceptor disabled');
    showStatus('Trial exhausted! Enter activation code to continue.', 'error');
    return;
  }
  
  // Only run on mission pages
  if (!isMissionPage()) {
    log('Not a mission page, skipping initialization');
    return;
  }
  
  // Show status
  showStatus('Looking for Accept button...', 'info');
  
  // Start looking for the accept button
  startAcceptProcess();
  
  // Set up a mutation observer to detect DOM changes
  setupMutationObserver();
  
  log('Mission acceptor initialized successfully');
}

/**
 * Check if the current page is a mission page
 * @returns {boolean} True if the current page appears to be a mission page
 */
function isMissionPage() {
  // Check URL pattern - with updated pattern to match both mission and missions URLs
  const url = window.location.href;
  
  // Explicit check for the URL pattern the user specified
  if (url.includes('app.ocus.com/missions/')) {
    log('Detected mission page from exact URL pattern: app.ocus.com/missions/');
    return true;
  }
  
  // Also check other common patterns as fallback
  if (url.includes('/mission/') || 
      url.includes('/assignments/') || 
      url.includes('ocus.com/assignment')) {
    log('Detected mission page from URL pattern');
    return true;
  }
  
  // Check for the exact button the user specified
  try {
    const exactButton = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (exactButton) {
      const buttonText = (exactButton.innerText || exactButton.textContent || '').trim();
      if (buttonText === 'Accept assignment') {
        log('Detected mission page from exact button match');
        return true;
      }
    }
  } catch (error) {
    log('Error checking for button', error);
  }
  
  // Check for other mission-specific elements
  const missionIndicators = [
    'div[data-test="mission-details"]',
    '.mission-details',
    '.mission-header'
  ];
  
  for (const selector of missionIndicators) {
    try {
      const elements = document.querySelectorAll(selector);
      if (elements && elements.length > 0) {
        log(`Detected mission page from element: ${selector}`);
        return true;
      }
    } catch (error) {
      // Some selectors might not work in all browsers
    }
  }
  
  log('Not a mission page');
  return false;
}

/**
 * Start the accept process
 */
function startAcceptProcess() {
  if (missionAccepted) return;
  
  attemptAccept();
}

/**
 * Attempt to find and click the accept button
 */
async function attemptAccept() {
  if (missionAccepted) {
    log('Mission already accepted, skipping attempt');
    return;
  }
  
  // Check trial status before each attempt
  const trialStatus = await checkTrialStatus();
  if (!trialStatus.canAccept) {
    log('Trial exhausted during attempt, stopping mission acceptor');
    showStatus('Trial exhausted! Enter activation code to continue.', 'error');
    return;
  }
  
  attemptCount++;
  log(`Accept attempt ${attemptCount}/${CONFIG.maxAttempts}`);
  
  if (attemptCount > CONFIG.maxAttempts) {
    log('Max attempts reached, giving up');
    showStatus('Could not find Accept button after maximum attempts', 'error');
    return;
  }
  
  // Look for the button
  const button = findAcceptButton();
  
  if (button) {
    log('Accept button found, attempting to click');
    
    if (clickAcceptButton(button)) {
      await handleAcceptSuccess();
      return;
    } else {
      log('Click failed, will retry');
    }
  } else {
    log(`Accept button not found (attempt ${attemptCount})`);
  }
  
  // Schedule next attempt
  attemptTimer = setTimeout(attemptAccept, CONFIG.attemptInterval);
}

/**
 * Find the accept button
 * @returns {Element|null} The accept button element if found
 */
function findAcceptButton() {
  // Primary selectors based on user's specification
  const primarySelectors = [
    'button[data-test="accept-assignment-btn"]' // Exact match for user's button
  ];
  
  // Try primary selectors first
  for (const selector of primarySelectors) {
    try {
      const buttons = document.querySelectorAll(selector);
      for (const button of buttons) {
        // Check if it contains the expected text
        const buttonText = (button.innerText || button.textContent || '').trim();
        if (buttonText === 'Accept assignment') {
          log(`Found accept button with primary selector: ${selector}`);
          log(`Button text: "${buttonText}"`);
          return button;
        }
      }
    } catch (error) {
      log(`Error with selector ${selector}:`, error);
    }
  }
  
  // Fallback selectors if primary doesn't work
  const fallbackSelectors = [
    'button:contains("Accept assignment")',
    'button:contains("Accept")',
    '[class*="accept"]',
    '[data-test*="accept"]',
    'button[class*="primary"]',
    'button[class*="submit"]'
  ];
  
  for (const selector of fallbackSelectors) {
    try {
      const buttons = document.querySelectorAll(selector);
      for (const button of buttons) {
        const buttonText = (button.innerText || button.textContent || '').trim().toLowerCase();
        if (buttonText.includes('accept')) {
          log(`Found accept button with fallback selector: ${selector}`);
          log(`Button text: "${buttonText}"`);
          return button;
        }
      }
    } catch (error) {
      log(`Error with fallback selector ${selector}:`, error);
    }
  }
  
  // Custom contains selector (since CSS :contains might not work)
  try {
    const allButtons = document.querySelectorAll('button');
    for (const button of allButtons) {
      const buttonText = (button.innerText || button.textContent || '').trim();
      if (buttonText === 'Accept assignment' || 
          buttonText === 'Accept' ||
          buttonText.toLowerCase().includes('accept')) {
        log(`Found accept button by text search: "${buttonText}"`);
        return button;
      }
    }
  } catch (error) {
    log('Error in text-based button search:', error);
  }
  
  return null;
}

/**
 * Scroll button into view
 */
function scrollButtonIntoView(button) {
  try {
    button.scrollIntoView({ behavior: 'smooth', block: 'center' });
    log('Scrolled button into view');
  } catch (error) {
    log('Error scrolling button into view:', error);
  }
}

/**
 * Click the accept button
 * @param {Element} button The button to click
 * @returns {boolean} True if click succeeded
 */
function clickAcceptButton(button) {
  if (!button) return false;
  
  let clickSucceeded = false;
  
  // Before attempting to click, ensure the button is in view
  scrollButtonIntoView(button);
  
  // Method 1: Native click (most reliable)
  try {
    log('Attempting native click method');
    button.click();
    clickSucceeded = true;
    log('Native click succeeded');
  } catch (error) {
    log('Native click failed', error);
  }
  
  return clickSucceeded;
}

/**
 * Handle successful mission acceptance
 */
async function handleAcceptSuccess() {
  log('Mission accepted successfully!');
  missionAccepted = true;
  showStatus('Mission accepted! Redirecting...', 'success');
  
  // Play success sound if enabled
  try {
    chrome.storage.local.get(['config'], (result) => {
      const config = result.config || {};
      if (config.sounds && config.sounds.enabled && config.sounds.missionAccepted) {
        if (typeof window.playSound === 'function') {
          window.playSound('missionAccepted');
          log('Playing mission accepted sound');
        }
      }
    });
  } catch (error) {
    log('Error playing success sound:', error);
  }
  
  // Clear any pending attempts
  clearTimeout(attemptTimer);
  
  // Update trial tracking and counters after successful click
  try {
    await updateTrialAndCounters();
  } catch (error) {
    log('Error updating trial and counters:', error);
  }
  
  // Redirect to homepage by clicking Home navigation after delay
  if (CONFIG.autoRedirect) {
    setTimeout(() => {
      log(`Redirecting to homepage after ${CONFIG.redirectDelay}ms by clicking Home navigation`);
      
      // Find and click the Home navigation element
      const homeElements = document.querySelectorAll('a[href="/"]');
      let homeLink = null;
      
      // Look for the Home link that contains the "Home" text
      for (const link of homeElements) {
        const homeSpan = link.querySelector('span.tw-border-orange');
        if (homeSpan && homeSpan.textContent.trim() === 'Home') {
          homeLink = link;
          break;
        }
      }
      
      // Fallback: look for any link with "Home" text
      if (!homeLink) {
        for (const link of homeElements) {
          if (link.textContent.includes('Home')) {
            homeLink = link;
            break;
          }
        }
      }
      
      // Click the home link if found
      if (homeLink) {
        log('Found Home navigation element, clicking it');
        homeLink.click();
      } else {
        // Fallback: try clicking the logo
        const logo = document.querySelector('a[href="/"] img') || document.querySelector('a.nux');
        if (logo) {
          log('Home navigation not found, clicking logo instead');
          const logoLink = logo.closest('a');
          if (logoLink) {
            logoLink.click();
          }
        } else {
          log('Could not find Home navigation or logo, using URL redirect as fallback');
          window.location.href = CONFIG.homepage;
        }
      }
    }, CONFIG.redirectDelay);
  }
}

// Global lock to prevent double execution
let trialUpdateInProgress = false;

/**
 * Update trial usage and mission counters after successful acceptance
 * FIXED: Proper counter increment with accurate messaging
 */
async function updateTrialAndCounters() {
  // CRITICAL: Prevent double execution
  if (trialUpdateInProgress) {
    log('🚫 TRIAL UPDATE ALREADY IN PROGRESS - SKIPPING');
    return;
  }
  
  trialUpdateInProgress = true;
  log('🟦 === TRIAL UPDATE START ===');
  
  try {
    // Use synchronous method to prevent race conditions
    chrome.storage.local.get(['ocus_trial_count'], (result) => {
      const currentCount = result.ocus_trial_count || 0;
      const newCount = currentCount + 1;
      
      log(`🔢 TRIAL COUNT: ${currentCount} → ${newCount}`);
      
      // Save the new count
      chrome.storage.local.set({ ocus_trial_count: newCount }, () => {
        log(`✅ TRIAL COUNT SAVED: ${newCount}`);
        
        // Show appropriate message based on count - FIXED LOGIC
        if (newCount === 1) {
          log('✨ MISSION 1/3 COMPLETED');
          showStatus('Mission 1/3 completed! 2 more trial missions remaining.', 'success');
        } else if (newCount === 2) {
          log('✨ MISSION 2/3 COMPLETED');
          showStatus('Mission 2/3 completed! 1 more trial mission remaining.', 'success');
        } else if (newCount >= 3) {
          log('🏁 ALL 3 MISSIONS COMPLETED - TRIAL FINISHED');
          showStatus('All 3 trial missions completed! Time to activate.', 'info');
          setTimeout(() => {
            if (confirm('You have completed all 3 free trial missions! Ready to unlock unlimited mission acceptance?')) {
              window.open('https://jobhunter.one/', '_blank');
            }
          }, 2000);
        }
        
        // Update panel counter
        const remaining = Math.max(0, 3 - newCount);
        updatePanelCounter(newCount, remaining);
        
        // Release lock
        trialUpdateInProgress = false;
      });
    });
  } catch (error) {
    log('❌ TRIAL UPDATE ERROR:', error);
    trialUpdateInProgress = false;
  }
  
  log('🟦 === TRIAL UPDATE END ===');
}

/**
 * Show floating trial notification
 * FIXED: Show accurate used/remaining count
 */
function showTrialNotification(remaining, used) {
  // Create floating notification
  const notification = document.createElement('div');
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 15px 20px;
    border-radius: 10px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    font-weight: bold;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
    z-index: 10000;
    max-width: 350px;
    text-align: center;
    animation: slideInRight 0.5s ease-out;
  `;
  
  if (remaining > 0) {
    notification.textContent = `🔥 TRIAL MODE: ${used || 0}/3 missions used, ${remaining} remaining!`;
  } else {
    notification.textContent = `⚠️ TRIAL COMPLETE! All 3 missions used. Activate for unlimited missions.`;
    notification.style.background = 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)';
  }
  
  document.body.appendChild(notification);
  
  // Auto remove after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.parentNode.removeChild(notification);
    }
  }, 5000);
  
  log(`Showed trial notification: ${used || 0}/3 used, ${remaining} remaining`);
}

/**
 * Update the floating panel counter
 */
function updatePanelCounter(used, remaining) {
  // Try to find existing OCUS panel counter
  let counterElement = document.querySelector('#ocus-trial-counter');
  
  if (!counterElement) {
    // Create new counter if it doesn't exist
    counterElement = document.createElement('div');
    counterElement.id = 'ocus-trial-counter';
    counterElement.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.8);
      color: white;
      padding: 10px 15px;
      border-radius: 20px;
      font-family: Arial, sans-serif;
      font-size: 12px;
      font-weight: bold;
      z-index: 9999;
      backdrop-filter: blur(10px);
      border: 1px solid rgba(255, 255, 255, 0.2);
    `;
    document.body.appendChild(counterElement);
  }
  
  // Update counter text
  if (remaining > 0) {
    counterElement.textContent = `OCUS Trial: ${used}/3 used`;
    counterElement.style.background = 'rgba(0, 123, 255, 0.8)';
  } else {
    counterElement.textContent = `OCUS Trial: Complete (3/3)`;
    counterElement.style.background = 'rgba(255, 107, 107, 0.8)';
  }
  
  log(`Updated panel counter: ${used}/3 used, ${remaining} remaining`);
}

/**
 * Set up mutation observer to detect DOM changes
 */
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    if (missionAccepted) return;
    
    let shouldCheckForButton = false;
    
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        shouldCheckForButton = true;
      }
    });
    
    if (shouldCheckForButton) {
      log('DOM changed, checking for accept button');
      const button = findAcceptButton();
      if (button && !missionAccepted) {
        log('Accept button found after DOM change, attempting click');
        if (clickAcceptButton(button)) {
          handleAcceptSuccess();
        }
      }
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  log('Mutation observer set up');
}

/**
 * Show status to user
 * @param {string} message The message to show
 * @param {string} type The type of message (info, success, error)
 */
function showStatus(message, type = 'info') {
  log(`Status (${type}): ${message}`);
  
  // Create or update status element
  let statusElement = document.getElementById('ocus-status');
  
  if (!statusElement) {
    statusElement = document.createElement('div');
    statusElement.id = 'ocus-status';
    statusElement.style.cssText = `
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      padding: 10px 20px;
      border-radius: 20px;
      font-family: Arial, sans-serif;
      font-size: 14px;
      font-weight: bold;
      z-index: 10001;
      transition: all 0.3s ease;
      max-width: 400px;
      text-align: center;
    `;
    document.body.appendChild(statusElement);
  }
  
  // Set message and style based on type
  statusElement.textContent = message;
  
  switch (type) {
    case 'success':
      statusElement.style.background = 'linear-gradient(135deg, #28a745 0%, #20c997 100%)';
      statusElement.style.color = 'white';
      break;
    case 'error':
      statusElement.style.background = 'linear-gradient(135deg, #dc3545 0%, #fd7e14 100%)';
      statusElement.style.color = 'white';
      break;
    default:
      statusElement.style.background = 'linear-gradient(135deg, #007bff 0%, #6f42c1 100%)';
      statusElement.style.color = 'white';
  }
  
  // Auto-hide after a delay
  setTimeout(() => {
    if (statusElement && statusElement.parentNode) {
      statusElement.style.opacity = '0';
      setTimeout(() => {
        if (statusElement.parentNode) {
          statusElement.parentNode.removeChild(statusElement);
        }
      }, 300);
    }
  }, type === 'error' ? 8000 : 5000);
}

/**
 * Logging function
 * @param {...any} args Arguments to log
 */
function log(...args) {
  if (CONFIG.debug) {
    console.log('[OCUS Mission Acceptor]', ...args);
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Also initialize on page focus (in case of navigation)
window.addEventListener('focus', () => {
  if (!missionAccepted && isMissionPage()) {
    log('Page focused, reinitializing if needed');
    setTimeout(init, 1000);
  }
});