/**
 * DEBUG TOOL: Test and debug storage systems
 * Run this in browser console to check what's happening with trial counters
 */

console.log('🔍 STORAGE DEBUG TOOL LOADED');

function debugStorage() {
  console.log('📊 === STORAGE DEBUG REPORT ===');
  
  const keysToCheck = [
    'trial_missions_completed',
    'ocus_trial_count',
    'ocus_mission_count', 
    'demo_usage_data',
    'config',
    'unified_trial_system_v3',
    'isActivated',
    'activation_key_data'
  ];
  
  chrome.storage.local.get(keysToCheck, (result) => {
    console.log('🗄️ ALL STORAGE DATA:');
    keysToCheck.forEach(key => {
      if (result[key] !== undefined) {
        console.log(`  ${key}:`, result[key]);
      } else {
        console.log(`  ${key}: (not set)`);
      }
    });
    
    // Calculate what each system thinks
    console.log('\n📈 SYSTEM INTERPRETATIONS:');
    
    // Unified system
    const unifiedCount = result.trial_missions_completed || 0;
    console.log(`  Unified System: ${unifiedCount}/3 missions completed`);
    
    // Old systems
    const oldTrialCount = result.ocus_trial_count || 0;
    console.log(`  Old Trial Count: ${oldTrialCount}`);
    
    const demoData = result.demo_usage_data;
    if (demoData) {
      console.log(`  Demo Usage Data: ${demoData.used}/${demoData.maxUses} used`);
    }
    
    const config = result.config;
    if (config && config.demo) {
      console.log(`  Config Demo: ${config.demo.usesRemaining} remaining`);
    }
    
    console.log('\n🎯 RECOMMENDATIONS:');
    if (unifiedCount !== oldTrialCount) {
      console.log('  ⚠️  CONFLICT: Unified and old systems have different counts!');
    }
    
    if (unifiedCount < 3) {
      console.log(`  ✅ Should allow missions: ${3 - unifiedCount} remaining`);
    } else {
      console.log('  ❌ Should block missions: Trial complete');
    }
  });
}

function clearAllTrialData() {
  console.log('🧹 CLEARING ALL TRIAL DATA');
  
  const keysToClear = [
    'trial_missions_completed',
    'ocus_trial_count',
    'ocus_mission_count', 
    'demo_usage_data',
    'config',
    'unified_trial_system_v3',
    'session_initialized',
    'trial_system_ever_initialized',
    'ultimate_fix_applied'
  ];
  
  chrome.storage.local.remove(keysToClear, () => {
    console.log('✅ All trial data cleared');
    console.log('🔄 Setting fresh unified system...');
    
    chrome.storage.local.set({
      unified_trial_system_v3: true,
      trial_missions_completed: 0
    }, () => {
      console.log('✅ Fresh unified system set');
      debugStorage();
    });
  });
}

function simulateMissionComplete() {
  console.log('🎯 SIMULATING MISSION COMPLETION');
  
  chrome.storage.local.get(['trial_missions_completed'], (result) => {
    const current = result.trial_missions_completed || 0;
    const next = current + 1;
    
    console.log(`📈 Incrementing: ${current} → ${next}`);
    
    chrome.storage.local.set({ trial_missions_completed: next }, () => {
      console.log(`✅ Mission ${next}/3 completed`);
      debugStorage();
    });
  });
}

// Make functions available globally
window.debugStorage = debugStorage;
window.clearAllTrialData = clearAllTrialData;
window.simulateMissionComplete = simulateMissionComplete;

console.log('🛠️ Debug functions available:');
console.log('  debugStorage() - Show current storage state');
console.log('  clearAllTrialData() - Reset all trial systems');  
console.log('  simulateMissionComplete() - Test mission increment');

// Run initial debug
debugStorage();