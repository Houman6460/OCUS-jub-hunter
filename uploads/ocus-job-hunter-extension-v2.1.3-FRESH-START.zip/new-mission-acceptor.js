/**
 * OCUS Unified Extension - New Mission Acceptor (FINAL FIX)
 * 
 * FINAL FIX: Unified trial system that works properly with activation manager
 * - Uses single counter system across all components
 * - Disables extension only after exactly 3 missions
 * - Shows popup activation form instead of redirecting to checkout
 */

// Configuration
const CONFIG = {
  enabled: true,
  autoRedirect: true,
  redirectDelay: 3000,
  maxAttempts: 20,
  attemptInterval: 800,
  debug: true,
  homepage: 'https://app.ocus.com/'
};

/**
 * UNIFIED TRIAL SYSTEM: Reset all conflicting storage and use single counter
 */
async function initializeUnifiedTrialSystem() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['unified_trial_system_v3'], (result) => {
      if (!result.unified_trial_system_v3) {
        console.log('🔄 INITIALIZING UNIFIED TRIAL SYSTEM V3');
        
        // Clear all conflicting trial data
        const keysToRemove = [
          'demo_usage_data',
          'ocus_trial_count', 
          'ocus_mission_count',
          'session_initialized',
          'trial_system_ever_initialized',
          'ultimate_fix_applied'
        ];
        
        chrome.storage.local.remove(keysToRemove, () => {
          // Set unified system
          chrome.storage.local.set({
            unified_trial_system_v3: true,
            trial_missions_completed: 0,
            trial_max_missions: 3,
            system_initialized_at: Date.now()
          }, () => {
            console.log('✅ UNIFIED TRIAL SYSTEM V3 INITIALIZED');
            resolve();
          });
        });
      } else {
        console.log('✅ UNIFIED TRIAL SYSTEM V3 ALREADY ACTIVE');
        resolve();
      }
    });
  });
}

/**
 * Check unified trial status
 */
async function checkUnifiedTrialStatus() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['isActivated', 'activation_key_data', 'trial_missions_completed'], (result) => {
      if (chrome.runtime.lastError) {
        console.log('Storage error, assuming trial active');
        resolve({ canAccept: true, remaining: 3, used: 0 });
        return;
      }
      
      // Check activation status
      const isActivated = result.isActivated || 
                         (result.activation_key_data && result.activation_key_data.isActivated);
      
      if (isActivated) {
        console.log('✅ USER ACTIVATED - UNLIMITED USAGE');
        resolve({ canAccept: true, remaining: 'unlimited', used: 0 });
        return;
      }
      
      // Check unified trial counter
      const missionsCompleted = result.trial_missions_completed || 0;
      const remaining = Math.max(0, 3 - missionsCompleted);
      
      console.log(`📊 UNIFIED TRIAL STATUS: ${missionsCompleted}/3 completed, ${remaining} remaining`);
      
      resolve({
        canAccept: missionsCompleted < 3,  // Allow if less than 3 missions completed
        remaining: remaining,
        used: missionsCompleted
      });
    });
  });
}

// State tracking
let missionAccepted = false;
let attemptCount = 0;
let attemptTimer = null;
let updateInProgress = false;

/**
 * Initialize the mission acceptor with unified trial system
 */
async function init() {
  console.log('🚀 MISSION ACCEPTOR INITIALIZING (FINAL FIX)');
  
  // Initialize unified trial system
  await initializeUnifiedTrialSystem();
  
  // Check trial status
  const trialStatus = await checkUnifiedTrialStatus();
  if (!trialStatus.canAccept) {
    console.log('❌ TRIAL EXHAUSTED - EXTENSION DISABLED');
    showStatus('Trial complete! Use activation code to continue.', 'error');
    return;
  }
  
  console.log(`✅ TRIAL ACTIVE: ${trialStatus.used}/3 used, ${trialStatus.remaining} remaining`);
  
  // Only run on mission pages
  if (!isMissionPage()) {
    console.log('ℹ️ Not a mission page');
    return;
  }
  
  // Start acceptance process
  showStatus(`Trial ${trialStatus.used}/3 - Looking for Accept button...`, 'info');
  startAcceptProcess();
  setupMutationObserver();
  
  console.log('✅ MISSION ACCEPTOR READY');
}

/**
 * Check if current page is a mission page
 */
function isMissionPage() {
  const url = window.location.href;
  
  if (url.includes('app.ocus.com/missions/')) {
    console.log('✅ Mission page detected');
    return true;
  }
  
  if (url.includes('/mission/') || url.includes('/assignments/')) {
    console.log('✅ Mission page detected');
    return true;
  }
  
  // Check for accept button
  try {
    const button = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (button && button.textContent.trim() === 'Accept assignment') {
      console.log('✅ Mission page detected (accept button found)');
      return true;
    }
  } catch (error) {
    console.log('Error checking button', error);
  }
  
  return false;
}

/**
 * Start accept process
 */
function startAcceptProcess() {
  if (missionAccepted) return;
  attemptAccept();
}

/**
 * Attempt to accept mission
 */
async function attemptAccept() {
  if (missionAccepted) return;
  
  // Re-check trial status before each attempt
  const trialStatus = await checkUnifiedTrialStatus();
  if (!trialStatus.canAccept) {
    console.log('❌ Trial exhausted during attempt');
    showStatus('Trial complete! Activate to continue.', 'error');
    return;
  }
  
  attemptCount++;
  console.log(`🔄 Attempt ${attemptCount}/${CONFIG.maxAttempts}`);
  
  if (attemptCount > CONFIG.maxAttempts) {
    console.log('❌ Max attempts reached');
    showStatus('Accept button not found', 'error');
    return;
  }
  
  const button = findAcceptButton();
  
  if (button) {
    console.log('✅ Accept button found, clicking...');
    if (clickAcceptButton(button)) {
      await handleAcceptSuccess();
      return;
    }
  }
  
  // Retry
  attemptTimer = setTimeout(attemptAccept, CONFIG.attemptInterval);
}

/**
 * Find accept button
 */
function findAcceptButton() {
  // Primary selector
  try {
    const button = document.querySelector('button[data-test="accept-assignment-btn"]');
    if (button && button.textContent.trim() === 'Accept assignment') {
      return button;
    }
  } catch (error) {
    console.log('Error finding button', error);
  }
  
  // Fallback: search all buttons
  try {
    const buttons = document.querySelectorAll('button');
    for (const button of buttons) {
      const text = button.textContent.trim();
      if (text === 'Accept assignment' || text === 'Accept') {
        console.log(`Found button by text: "${text}"`);
        return button;
      }
    }
  } catch (error) {
    console.log('Error in fallback search', error);
  }
  
  return null;
}

/**
 * Click accept button
 */
function clickAcceptButton(button) {
  if (!button) return false;
  
  try {
    button.scrollIntoView({ behavior: 'smooth', block: 'center' });
    button.click();
    console.log('✅ Button clicked');
    return true;
  } catch (error) {
    console.log('❌ Click failed:', error);
    return false;
  }
}

/**
 * Handle successful acceptance
 */
async function handleAcceptSuccess() {
  console.log('🎉 MISSION ACCEPTED!');
  missionAccepted = true;
  
  clearTimeout(attemptTimer);
  
  // Update unified trial counter
  await updateUnifiedTrialCounter();
  
  // Redirect to homepage
  if (CONFIG.autoRedirect) {
    setTimeout(() => {
      console.log('🏠 Redirecting to homepage');
      window.location.href = CONFIG.homepage;
    }, CONFIG.redirectDelay);
  }
}

/**
 * Update unified trial counter
 */
async function updateUnifiedTrialCounter() {
  if (updateInProgress) {
    console.log('🚫 Update already in progress');
    return;
  }
  
  updateInProgress = true;
  console.log('📊 === UPDATING UNIFIED TRIAL COUNTER ===');
  
  return new Promise((resolve) => {
    chrome.storage.local.get(['trial_missions_completed'], (result) => {
      const currentCompleted = result.trial_missions_completed || 0;
      const newCompleted = currentCompleted + 1;
      
      console.log(`📈 MISSIONS: ${currentCompleted} → ${newCompleted}`);
      
      chrome.storage.local.set({ trial_missions_completed: newCompleted }, () => {
        console.log(`✅ SAVED: ${newCompleted} missions completed`);
        
        // Update activation manager storage to match
        updateActivationManagerStorage(newCompleted);
        
        // Show appropriate message
        const remaining = 3 - newCompleted;
        
        if (newCompleted === 1) {
          console.log('🎯 MISSION 1/3 COMPLETED');
          showStatus('Mission 1/3 completed! 2 more trial missions remaining.', 'success');
        } else if (newCompleted === 2) {
          console.log('🎯 MISSION 2/3 COMPLETED');
          showStatus('Mission 2/3 completed! 1 more trial mission remaining.', 'success');
        } else if (newCompleted >= 3) {
          console.log('🏁 ALL 3 MISSIONS COMPLETED');
          showStatus('All 3 trial missions completed! Click extension icon to activate.', 'info');
          // DO NOT redirect to checkout - let user click extension popup instead
        }
        
        updateTrialCounter(newCompleted, remaining);
        updateInProgress = false;
        resolve();
      });
    });
  });
}

/**
 * Update activation manager storage to stay in sync
 */
function updateActivationManagerStorage(missionsCompleted) {
  // Update demo_usage_data to match our unified counter
  const demoData = {
    used: missionsCompleted,
    maxUses: 3,
    lastUsed: Date.now()
  };
  
  chrome.storage.local.set({ 
    demo_usage_data: demoData,
    config: {
      demo: {
        usesRemaining: Math.max(0, 3 - missionsCompleted),
        maxUses: 3
      }
    }
  }, () => {
    console.log('✅ Synced with activation manager storage');
  });
}

/**
 * Update trial counter display
 */
function updateTrialCounter(used, remaining) {
  let counter = document.querySelector('#ocus-unified-counter');
  
  if (!counter) {
    counter = document.createElement('div');
    counter.id = 'ocus-unified-counter';
    counter.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: rgba(0, 0, 0, 0.9);
      color: white;
      padding: 12px 16px;
      border-radius: 20px;
      font-family: Arial, sans-serif;
      font-size: 13px;
      font-weight: bold;
      z-index: 10000;
      border: 2px solid #007bff;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(counter);
  }
  
  if (remaining > 0) {
    counter.textContent = `OCUS Trial: ${used}/3 (${remaining} left)`;
    counter.style.borderColor = '#007bff';
    counter.style.background = 'rgba(0, 123, 255, 0.9)';
  } else {
    counter.textContent = `OCUS Trial: Complete (3/3)`;
    counter.style.borderColor = '#28a745';
    counter.style.background = 'rgba(40, 167, 69, 0.9)';
  }
}

/**
 * Setup mutation observer
 */
function setupMutationObserver() {
  const observer = new MutationObserver((mutations) => {
    if (missionAccepted) return;
    
    let shouldCheck = false;
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        shouldCheck = true;
      }
    });
    
    if (shouldCheck) {
      const button = findAcceptButton();
      if (button && !missionAccepted) {
        if (clickAcceptButton(button)) {
          handleAcceptSuccess();
        }
      }
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
}

/**
 * Show status message
 */
function showStatus(message, type = 'info') {
  console.log(`📢 ${type.toUpperCase()}: ${message}`);
  
  let status = document.getElementById('ocus-status');
  
  if (!status) {
    status = document.createElement('div');
    status.id = 'ocus-status';
    status.style.cssText = `
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      padding: 12px 24px;
      border-radius: 25px;
      font-family: Arial, sans-serif;
      font-size: 14px;
      font-weight: bold;
      z-index: 10001;
      max-width: 400px;
      text-align: center;
      box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    `;
    document.body.appendChild(status);
  }
  
  status.textContent = message;
  
  switch (type) {
    case 'success':
      status.style.background = 'linear-gradient(135deg, #28a745 0%, #20c997 100%)';
      status.style.color = 'white';
      break;
    case 'error':
      status.style.background = 'linear-gradient(135deg, #dc3545 0%, #fd7e14 100%)';
      status.style.color = 'white';
      break;
    default:
      status.style.background = 'linear-gradient(135deg, #007bff 0%, #6f42c1 100%)';
      status.style.color = 'white';
  }
  
  // Auto-hide
  setTimeout(() => {
    if (status && status.parentNode) {
      status.style.opacity = '0';
      setTimeout(() => {
        if (status.parentNode) {
          status.parentNode.removeChild(status);
        }
      }, 300);
    }
  }, type === 'error' ? 8000 : 5000);
}

// Initialize
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

window.addEventListener('focus', () => {
  if (!missionAccepted && isMissionPage()) {
    setTimeout(init, 1000);
  }
});

console.log('🔧 OCUS Mission Acceptor (FINAL FIX) loaded');