/**
 * OCUS Unified Extension - Mission Monitor
 * 
 * Monitors the OCUS platform for available missions and opens them in new tabs.
 * This is adapted from the original OCUS Auto Clicker extension.
 * 
 * V2: Enhanced with improved mission detection and URL handling
 */

// Configuration state - renamed to avoid conflicts with other extensions
let monitorConfig = {
  missionMonitor: {
    enabled: true,
    refreshInterval: 30000,
    showNotifications: true,
    maxSimultaneousMissions: 3,
    openInNewTab: true
  },
  processedMissions: new Set()
};

// Make sure we don't conflict with other extensions' config variables
if (typeof window.ocusConfigLoaded === 'undefined') {
  window.ocusConfigLoaded = true;
} else {
  console.warn('Multiple OCUS extensions detected - ensuring compatibility mode');
}

// Tracking state
let scanTimer = null;
let observerActive = false;
let mutationObserver = null;

// List of selectors to try for mission cards
const missionCardSelectors = [
  "div[data-cy-id='availablemission']", 
  "div.mission-card:not(a)", 
  "div.mission-card.v-card:not(a)", 
  "div.v-card.v-card--link.v-sheet:not(a)",
  "div.card-wrapper[data-v-id]",
  "div.card-wrapper div.card",
  "div.mission-list div[role='button']",
  "div.mission-card > a[href*='mission']",
  // Additional selectors for better compatibility
  ".v-sheet.v-card",
  ".v-list-item",
  "[href*='/mission/']",
  "[data-cy='dashboard-mission-card']",
  "[data-cy='mission-card']",
  ".mission-item",
  // New Vue.js specific selectors
  ".v-list-item.v-list-item--link",
  "div.v-card--link",
  // Simplified selectors that work across browsers
  ".v-list-item__title",
  "a[href*='/mission']",
  // Removed invalid :has-ancestor() selector
  ".v-list-item__title a[href*='/mission']"
];
let lastScanTime = 0;
let currentlyOpeningMissions = 0;

// Global handler to block "See more" button clicks completely
function setupSeeMoreBlocker() {
  console.log('[OCUS] Setting up global See More button blocker');
  
  // This handler runs in the capture phase to catch all events before they bubble
  document.addEventListener('click', function(e) {
    // Use our enhanced detection to block See More clicks
    if (isSeeMoreElement(e.target)) {
      console.log('[OCUS] Blocked click on "See more" button');
      e.stopPropagation();
      e.preventDefault();
      return false;
    }
    
    // Check all parent elements in case the click is on a child of See More
    let parent = e.target.parentElement;
    while (parent) {
      if (isSeeMoreElement(parent)) {
        console.log('[OCUS] Blocked click on child of "See more" button');
        e.stopPropagation();
        e.preventDefault();
        return false;
      }
      parent = parent.parentElement;
    }
  }, true); // true = capture phase, runs before bubbling phase
}

// Initialize
function init() {
  console.log('OCUS Mission Monitor initializing...');
  
  // Set up the See More button blocker
  setupSeeMoreBlocker();
  
  // Get configuration from storage
  chrome.storage.local.get(['config'], (result) => {
    if (result && result.config) {
      // Update configuration
      monitorConfig.missionMonitor = result.config.missionMonitor || monitorConfig.missionMonitor;
      
      // Convert processedMissions array to a Set for better performance
      if (result.config.processedMissions) {
        if (Array.isArray(result.config.processedMissions)) {
          monitorConfig.processedMissions = new Set(result.config.processedMissions);
        } else {
          monitorConfig.processedMissions = new Set(result.config.processedMissions);
        }
      }
      
      // Start monitoring if enabled
      if (monitorConfig.missionMonitor.enabled) {
        startMissionMonitor();
      }
    }
  });
  
  // Listen for configuration updates
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'CONFIG_UPDATED' && message.config) {
      const wasEnabled = monitorConfig.missionMonitor?.enabled;
      
      // Update configuration
      monitorConfig.missionMonitor = message.config.missionMonitor || monitorConfig.missionMonitor;
      
      // Convert processedMissions array to a Set for better performance
      if (message.config.processedMissions) {
        if (Array.isArray(message.config.processedMissions)) {
          monitorConfig.processedMissions = new Set(message.config.processedMissions);
        } else {
          monitorConfig.processedMissions = new Set(message.config.processedMissions);
        }
      }
      
      // Start or stop monitoring based on enabled state
      if (!wasEnabled && monitorConfig.missionMonitor.enabled) {
        startMissionMonitor();
      } else if (wasEnabled && !monitorConfig.missionMonitor.enabled) {
        stopMissionMonitor();
      }
    }
  });
}

// Start monitoring for missions
function startMissionMonitor() {
  console.log('Starting mission monitor...');
  
  // Clear any existing timers
  if (scanTimer) {
    clearInterval(scanTimer);
    scanTimer = null;
  }
  
  // Initial scan with a delay to let page fully load
  setTimeout(() => {
    if (document.visibilityState === 'visible') {
      scanForMissionCards();
    }
  }, 3000);
  
  // Set up periodic scanning with a safe interval
  const safeInterval = Math.max(15000, monitorConfig.missionMonitor.refreshInterval || 30000);
  scanTimer = setInterval(() => {
    // Only scan if tab is visible and enough time has passed since last scan
    const now = Date.now();
    if (document.visibilityState === 'visible' && 
        monitorConfig.missionMonitor.enabled && 
        (now - lastScanTime > 10000)) {
      lastScanTime = now;
      scanForMissionCards();
    }
  }, safeInterval);
  
  // Set up mutation observer to detect new mission cards
  setupMutationObserver();
  
  // Add visibility change listener to scan when tab becomes visible
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && monitorConfig.missionMonitor.enabled) {
      // Small delay to ensure DOM is ready
      setTimeout(() => {
        scanForMissionCards();
      }, 1000);
    }
  });
  
  // Show status indicator
  showStatusIndicator(true);
}

// Stop monitoring for missions
function stopMissionMonitor() {
  console.log('Stopping mission monitor...');
  
  // Clear scan timer
  if (scanTimer) {
    clearInterval(scanTimer);
    scanTimer = null;
  }
  
  // Disconnect mutation observer
  if (mutationObserver) {
    mutationObserver.disconnect();
    observerActive = false;
  }
  
  // Show status indicator
  showStatusIndicator(false);
}

// Scan the page for mission cards
function scanForMissionCards() {
  if (!monitorConfig.missionMonitor.enabled || window.location.href.includes('/mission/')) {
    return; // Don't scan if disabled or on a mission page
  }
  
  // Only run on mission list pages
  if (!window.location.href.includes('app.ocus.com') && 
      !window.location.href.includes('ocus.work')) {
    return;
  }
  
  // Check if we're at max simultaneous missions
  if (currentlyOpeningMissions >= monitorConfig.missionMonitor.maxSimultaneousMissions) {
    console.log(`Already opening ${currentlyOpeningMissions} missions (max: ${monitorConfig.missionMonitor.maxSimultaneousMissions})`);
    return;
  }
  
  console.log('[OCUS] Scanning for mission cards with direct element targeting...');
  
    // Using the global missionCardSelectors array defined at the top of the file
  
  // Additional specific element selectors within mission cards
  // Updated with consistent elements found across all mission cards based on source code analysis
  // Prioritizing selectors from extension #2 (Action Clicker) approach
  const specificElementSelectors = [
    // Primary target selectors (from extension #2)
    ".mission-card__offer-tag",  // The FOOD label
    ".mission-card__action",    // The arrow icon
    ".mission-card__date",      // The date component
    
    // Extension numbers
    ".extension-number", "[data-cy='extension-number']", ".extension-count", ".mission-card__extension-count",
    // Review numbers
    ".review-count", "[data-cy='review-count']", ".review-number", ".mission-card__review-count",
    // Additional FOOD labels
    ".food-label", "[data-test='food-label']", ".food-tag", ".mission-tag.food",
    // Additional arrow icons
    ".v-icon.mdi-arrow-right", ".arrow-icon", ".icon-arrow-right", ".accept-arrow",
    // Additional date components
    ".date-component", ".mission-date", ".deadline-date", "[data-cy='mission-date']"
  ];
  
  // Join all selectors with commas for querySelector
  const combinedSelector = missionCardSelectors.join(', ');
  
  // Get all mission cards
  const missionCards = Array.from(document.querySelectorAll(combinedSelector));
  
  console.log(`[OCUS] Found ${missionCards.length} potential mission cards`);
  
  // Try direct element targeting approach before processing individual cards
  const directTargetingSucceeded = tryDirectElementTargeting();
  
  // Only process individual cards if direct targeting didn't succeed
  if (!directTargetingSucceeded) {
    console.log('[OCUS] Direct targeting didn\'t find elements, trying per-card approach');
    
    // Process each mission card
    for (const card of missionCards) {
      // Don't exceed max simultaneous missions
      if (currentlyOpeningMissions >= monitorConfig.missionMonitor.maxSimultaneousMissions) {
        break;
      }
      
      // Generate a unique ID for the mission card
      const missionId = generateMissionId(card);
      
      // Skip if we've already processed this mission
      if (monitorConfig.processedMissions.has(missionId)) {
        //console.log(`Skipping already processed mission: ${missionId}`);
        continue;
      }
      
      // Check if the mission card is visible
      if (!isVisibleElement(card)) {
        //console.log(`Skipping invisible mission card: ${missionId}`);
        continue;
      }
      
      // Mark as processed
      monitorConfig.processedMissions.add(missionId);
      
      // Save updated processedMissions to storage (convert Set to Array)
      chrome.storage.local.get(['config'], (result) => {
        const updatedConfig = result.config || {};
        updatedConfig.processedMissions = Array.from(monitorConfig.processedMissions);
        chrome.storage.local.set({ config: updatedConfig });
      });
      
      // Update stats
      chrome.runtime.sendMessage({ type: 'MISSION_FOUND' });
      
      // IMPORTANT: Change logging to reflect we're targeting specific elements
      console.log(`Processing mission card elements: ${missionId}`);
      
      // Increment counter for simultaneous missions
      currentlyOpeningMissions++;
      
      // Try to find and click specific elements within the mission card first
      const didClickSpecificElement = tryClickSpecificElements(card);
      
      // If we couldn't click a specific element, fall back to the traditional approach
      if (!didClickSpecificElement) {
        // Open the mission in a new tab using the standard approach
        openMissionInNewTab(card, missionId);
      }
    }
  }
  
  // Try looking for specific elements directly even if we found mission cards
  if (currentlyOpeningMissions < monitorConfig.missionMonitor.maxSimultaneousMissions) {
    tryFindAndClickStandaloneElements();
    
    // If Vue support is available, try using it to find mission cards
    if (window.ocusVueSupport) {
      tryFindMissionsWithVueSupport();
    }
  }
  
  // If no mission cards were found, try the component approach
  if (missionCards.length === 0) {
    const componentSelectors = [
      "a[href*='/mission/']",
      "div[role='button'][data-cy-id]",
      "div.v-card--link"
    ];
    
    // Look for components that might be mission cards
    const components = Array.from(document.querySelectorAll(componentSelectors.join(', ')));
    
    console.log(`Found ${components.length} potential mission components`);
    
    for (const component of components) {
      // Don't exceed max simultaneous missions
      if (currentlyOpeningMissions >= monitorConfig.missionMonitor.maxSimultaneousMissions) {
        break;
      }
      
      // Find the parent mission card
      const missionCard = findParentCard(component);
      
      if (!missionCard) {
        continue;
      }
      
      // Generate a unique ID for the mission card
      const missionId = generateMissionId(missionCard);
      
      // Skip if we've already processed this mission
      if (monitorConfig.processedMissions.has(missionId)) {
        continue;
      }
      
      // Check if the mission card is visible
      if (!isVisibleElement(missionCard)) {
        continue;
      }
      
      // Mark as processed
      monitorConfig.processedMissions.add(missionId);
      
      // Save updated processedMissions to storage (convert Set to Array)
      chrome.storage.local.get(['config'], (result) => {
        const updatedConfig = result.config || {};
        updatedConfig.processedMissions = Array.from(monitorConfig.processedMissions);
        chrome.storage.local.set({ config: updatedConfig });
      });
      
      // Update stats
      chrome.runtime.sendMessage({ type: 'MISSION_FOUND' });
      
      console.log(`Opening mission component in new tab: ${missionId}`);
      
      // Increment counter for simultaneous missions
      currentlyOpeningMissions++;
      
      // Open the mission in a new tab
      openMissionComponentInNewTab(component);
    }
  }
}

// Find parent mission card from a component
function findParentCard(element) {
  // Try to find the parent mission card
  let current = element;
  let iterations = 0;
  const maxIterations = 10; // Prevent infinite loops
  
  while (current && iterations < maxIterations) {
    // Check if current element is a mission card
    if (current.classList.contains('mission-card') || 
        current.classList.contains('card-wrapper') || 
        current.getAttribute('data-cy-id') === 'availablemission' ||
        current.classList.contains('v-card') ||
        current.classList.contains('v-list-item') ||
        current.classList.contains('card') ||
        current.hasAttribute('data-cy') && current.getAttribute('data-cy').includes('mission')) {
      return current;
    }
    
    // Move up the DOM tree
    current = current.parentElement;
    iterations++;
  }
  
  return null;
}

// Direct method to handle mission cards based on OCUS 3 STEP approach
function tryDirectElementTargeting() {
  console.log('[OCUS] Targeting only specific mission card elements...');
  
  // Target ONLY these key mission elements
  const targetSelectors = [
    '.mission-card__action',    // The arrow icon
    '.mission-card__offer-tag', // The FOOD label
    '.mission-card__date'       // The date component
  ];
  
  let anyClicked = false;
  
  // Try to find and click ONLY specific mission card components
  for (const selector of targetSelectors) {
    try {
      const elements = document.querySelectorAll(selector);
      console.log(`[OCUS] Found ${elements.length} elements with selector: ${selector}`);
      
      if (elements && elements.length > 0) {
        // Process elements in random order
        const shuffledElements = Array.from(elements).sort(() => Math.random() - 0.5);
        
        for (const element of shuffledElements) {
          // Skip the "See more" button and any links to search pages
          if (element.closest('a[href="/missions/search"]') || 
              (element.tagName === 'A' && element.getAttribute('href') === '/missions/search')) {
            console.log('[OCUS] Skipping "See more" button');
            continue;
          }
          
          // Make sure the element is visible and part of a mission card
          if (isVisibleElement(element) && isPartOfMissionCard(element)) {
            const success = openMissionComponentInNewWindow(element);
            if (success) {
              console.log(`[OCUS] Successfully opened mission from component selector: ${selector}`);
              anyClicked = true;
              break;
            }
          }
        }
        
        if (anyClicked) break;
      }
    } catch (error) {
      console.error(`[OCUS] Error with selector ${selector}:`, error);
    }
  }
  
  // If no specific components worked, try direct mission cards (but not "See more")
  if (!anyClicked) {
    console.log('[OCUS] Trying direct mission cards...');
    const missionCards = document.querySelectorAll('div.mission-card, [data-cy-id="availablemission"]');
    
    if (missionCards && missionCards.length > 0) {
      console.log(`[OCUS] Found ${missionCards.length} mission cards`);
      
      // Process each card
      for (const card of missionCards) {
        // Skip if this is a "See more" container
        if (card.querySelector('a[href="/missions/search"]')) {
          console.log('[OCUS] Skipping card with "See more" button');
          continue;
        }
        
        if (isVisibleElement(card)) {
          const success = openMissionCardInNewWindow(card);
          if (success) {
            console.log('[OCUS] Successfully opened mission card in new window');
            anyClicked = true;
            break;
          }
        }
      }
    }
  }
  
  return anyClicked;
}

// Global function to detect 'See more' elements that should be ignored
function isSeeMoreElement(element) {
  if (!element) return false;
  
  // Direct checks
  if (element.tagName === 'A' && element.getAttribute('href') === '/missions/search') {
    return true;
  }
  
  // Check exact text match for "See more" label
  if (element.textContent && element.textContent.trim() === 'See more') {
    return true;
  }
  
  // Check for parent elements that are "See more" links
  if (element.closest && element.closest('a[href="/missions/search"]')) {
    return true;
  }
  
  // Check for containers with "See more" text
  if (element.textContent && element.textContent.includes('See more')) {
    // Check if it's a small element that is likely the "See more" button
    const text = element.textContent.trim();
    if (text.length < 20 && text.includes('See more')) {
      return true;
    }
    
    // Check for common classes associated with "See more"
    if (element.className && (
        element.className.includes('orange--text') ||
        element.className.includes('font-weight-bold')
      ) && element.textContent.includes('See more')) {
      return true;
    }
  }
  
  return false;
}

// Helper function to check if an element is part of a mission card
function isPartOfMissionCard(element) {
  // First check if it's a "See more" element - if so, immediately return false
  if (isSeeMoreElement(element)) {
    return false;
  }
  
  // Check if the element is part of a mission card
  const hasParentCard = !!element.closest('div.mission-card') || 
                       !!element.closest('[data-cy-id="availablemission"]');
                       
  // Double-check it's not part of a "See more" button
  const isNotSeeMore = !element.closest('a[href="/missions/search"]') && 
                     !element.textContent.includes('See more');
                     
  return hasParentCard && isNotSeeMore;
}

// Helper function to directly handle clicks on mission component elements
function openMissionComponentInNewWindow(component) {
  console.log('[OCUS] Attempting to open mission via direct component:', component.className);
  
  try {
    // Skip if this is related to the "See more" button using our enhanced detection
    if (isSeeMoreElement(component)) {
      console.log('[OCUS] Skipping "See more" element');
      return false;
    }
    
    // Step 1: Try to find the parent mission card
    const parentCard = component.closest('div.mission-card') || 
                       component.closest('[data-cy-id="availablemission"]') ||
                       component.closest('div.v-card') || 
                       component.closest('div[tabindex="0"]');
    
    if (parentCard) {
      // Double-check the parent card isn't a "See more" container using enhanced detection
      if (isSeeMoreElement(parentCard)) {
        console.log('[OCUS] Parent card is a "See more" element - skipping');
        return false;
      }
      return openMissionCardInNewWindow(parentCard);
    } else {
      console.log('[OCUS] Could not find parent mission card');
      return false;
    }
  } catch (e) {
    console.error('[OCUS] Error opening mission component:', e);
    return false;
  }
}

// Open a mission card in a new window - improved to prevent same-page navigation
function openMissionCardInNewWindow(missionCard) {
  console.log('[OCUS] Attempting to open mission card in new window');
  
  try {
    // Skip if this is related to the "See more" button
    if (isSeeMoreElement(missionCard)) {
      console.log('[OCUS] Skipping "See more" element');
      return false;
    }
    
    // Method 1: Target the specific mission elements within the card (most reliable)
    const missionElements = missionCard.querySelectorAll('.mission-card__action, .mission-card__offer-tag, .mission-card__date');
    if (missionElements && missionElements.length > 0) {
      // Click specifically on the mission element, not the entire card
      const missionElement = missionElements[0];
      console.log(`[OCUS] Found specific element in card: ${missionElement.className}`);
      
      // Look for direct mission links first
      const directLinks = missionCard.querySelectorAll('a[href*="/mission/"]');
      if (directLinks && directLinks.length > 0) {
        const href = directLinks[0].href || directLinks[0].getAttribute('href');
        if (href) {
          // Skip if this is a missions/search link
          if (href.includes('/missions/search') || isSeeMoreElement(directLinks[0])) {
            console.log('[OCUS] Skipping search link or See more button');
            return false;
          }
          
          // Make sure we get the full URL
          const fullUrl = href.includes('://') ? href : 
                          href.startsWith('/') ? `${window.location.origin}${href}` : 
                          `${window.location.origin}/${href}`;
                          
          console.log(`[OCUS] Found direct mission link: ${fullUrl}`);
          
          // Force open in new window
          const newWindow = window.open('about:blank', '_blank');
          if (newWindow) {
            newWindow.location.href = fullUrl;
            console.log('[OCUS] Opened mission URL in new window');
            
            // Show notification
            if (monitorConfig.missionMonitor.showNotifications) {
              chrome.runtime.sendMessage({
                type: 'SHOW_NOTIFICATION',
                title: 'Mission Opened!',
                message: 'Mission opened in new window'
              });
            }
            
            // Update stats for found and opened missions
            chrome.runtime.sendMessage({ type: 'MISSION_FOUND' });
            updateOpenedCounter();
            
            return true;
          }
        }
      }
    }
    
    // Method 2: Extract mission ID from attributes or content
    let missionId = '';
    
    // Check data attributes for mission ID
    for (let attr of missionCard.getAttributeNames()) {
      const value = missionCard.getAttribute(attr);
      if (attr.includes('mission') && value) {
        const matches = value.match(/\d+/);
        if (matches && matches[0]) {
          missionId = matches[0];
          console.log(`[OCUS] Found mission ID in attribute: ${missionId}`);
          break;
        }
      }
    }
    
    // If no ID found yet, look for href links differently
    if (!missionId) {
      const allLinks = missionCard.querySelectorAll('a[href]');
      for (const link of allLinks) {
        const href = link.getAttribute('href');
        // Skip search links
        if (href && href.includes('/missions/search')) {
          continue;
        }
        // Look for mission links
        if (href && href.includes('mission')) {
          const matches = href.match(/[\/=](\d+)/);
          if (matches && matches[1]) {
            missionId = matches[1];
            console.log(`[OCUS] Found mission ID in link href: ${missionId}`);
            break;
          }
        }
      }
    }
    
    // If still no ID, look in text content
    if (!missionId) {
      const text = missionCard.textContent;
      if (!text.includes('See more')) { // Skip if this is a 'See more' element
        const matches = text.match(/mission[\s-]*(\d+)/i);
        if (matches && matches[1]) {
          missionId = matches[1];
          console.log(`[OCUS] Found mission ID in text: ${missionId}`);
        }
      }
    }
    
    // If we found an ID, construct and open the URL
    if (missionId) {
      // Try the standard mission URL format
      const url = `${window.location.origin}/mission/${missionId}`;
      console.log(`[OCUS] Opening mission URL: ${url}`);
      
      // Use the about:blank technique for guaranteed new window
      const newWindow = window.open('about:blank', '_blank');
      if (newWindow) {
        newWindow.location.href = url;
        console.log(`[OCUS] Opened mission URL in new window: ${url}`);
        
        // Show notification
        if (monitorConfig.missionMonitor.showNotifications) {
          chrome.runtime.sendMessage({
            type: 'SHOW_NOTIFICATION',
            title: 'Mission Opened!',
            message: `Mission ${missionId} opened in new window`
          });
        }
        
        // Update stats
        chrome.runtime.sendMessage({ type: 'MISSION_FOUND' });
        
        // Play sound alert for new mission found
        if (window.ocusSoundManager) {
          window.ocusSoundManager.playSound('newMission').catch(error => {
            console.error('[OCUS] Error playing new mission sound:', error);
          });
        }
        
        return true;
      }
    }
    
    // Try clicking with all navigation prevented
    console.log('[OCUS] Using click with navigation prevention');
    
    // Global click prevention - force ALL clicks to open in new tabs
    const preventDefaultNavigation = (e) => {
      // First use our enhanced detection function to catch all "See more" elements
      if (isSeeMoreElement(e.target)) {
        console.log('[OCUS] Ignoring click on "See more" element');
        return;
      }
      
      // For other elements, check for links in the event path
      let url = null;
      let target = e.target;
      
      // Find any link in the event path
      while (target) {
        if (target.tagName === 'A' && target.href) {
          // Skip "See more"/search links
          if (target.href.includes('/missions/search')) {
            return;
          }
          url = target.href;
          break;
        }
        if (!target.parentElement) break;
        target = target.parentElement;
      }
      
      // Prevent same-tab navigation
      if (url && url.includes('/mission/')) {
        e.preventDefault();
        e.stopPropagation();
        console.log(`[OCUS] Intercepted navigation attempt to: ${url}`);
        window.open(url, '_blank');
        return false;
      }
    };
    
    // Add global nav prevention
    document.addEventListener('click', preventDefaultNavigation, true);
    
    // Find specific action elements on the mission card
    const actionElement = missionCard.querySelector('.mission-card__action');
    const dateElement = missionCard.querySelector('.mission-card__date');
    const offerElement = missionCard.querySelector('.mission-card__offer-tag');
    
    // Try clicking the specific elements
    const elementToClick = actionElement || dateElement || offerElement || missionCard;
    console.log(`[OCUS] Clicking specific element: ${elementToClick.className}`);
    elementToClick.click();
    
    // Remove the event listener after a short delay
    setTimeout(() => {
      document.removeEventListener('click', preventDefaultNavigation, true);
    }, 500);
    
    return true;
  } catch (e) {
    console.error('[OCUS] Error opening mission card:', e);
    return false;
  }
}

// Guaranteed new tab opener - no exceptions
function forceOpenInNewTab(url) {
  try {
    // Always ensure the URL is absolute
    const absoluteUrl = url.includes('://') ? url : 
      url.startsWith('/') ? `${window.location.origin}${url}` : 
      `${window.location.origin}/${url}`;
    
    console.log(`[OCUS] FORCING open in new tab: ${absoluteUrl}`);
    
    // Method 1: Use window.open with _blank (most reliable)
    const newWindow = window.open(absoluteUrl, '_blank');
    
    // Method 2: As fallback, create and click a temporary link
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      console.log('[OCUS] Fallback to temporary link method');
      const tempLink = document.createElement('a');
      tempLink.href = absoluteUrl;
      tempLink.target = '_blank';
      tempLink.rel = 'noopener noreferrer';
      tempLink.style.display = 'none';
      document.body.appendChild(tempLink);
      tempLink.click();
      setTimeout(() => { document.body.removeChild(tempLink); }, 100);
    }
    
    // Update stats
    chrome.runtime.sendMessage({ type: 'MISSION_FOUND' });
    
    // Show notification
    if (monitorConfig.missionMonitor.showNotifications) {
      chrome.runtime.sendMessage({
        type: 'SHOW_NOTIFICATION',
        title: 'Mission Opened in New Tab!',
        message: `Opening: ${absoluteUrl.split('/').pop()}`
      });
    }
    
    return true;
  } catch (error) {
    console.error('[OCUS] Error in forceOpenInNewTab:', error);
    return false;
  }
}

// Helper function to clean up the extension UI after mission actions
function cleanupAfterMissionAction() {
  // Update the processed missions count in the popup
  chrome.runtime.sendMessage({
    type: 'UPDATE_PROCESSED_COUNT',
    count: monitorConfig.processedMissions.size
  });
  
  // Decrement the counter for simultaneous missions after a delay
  setTimeout(() => {
    currentlyOpeningMissions = Math.max(0, currentlyOpeningMissions - 1);
    console.log(`[OCUS] Decreased simultaneous missions counter to ${currentlyOpeningMissions}`);
  }, 2000);
}

// Helper function to extract mission URL from an element or its parents
function extractMissionUrl(element) {
  // Check the element itself
  if (element.tagName === 'A' && element.href && element.href.includes('/mission/')) {
    return element.href;
  }
  
  // Check parent elements for an anchor with mission URL
  let current = element.parentElement;
  let iterations = 0;
  const maxIterations = 5;
  
  while (current && iterations < maxIterations) {
    // Look for anchor tags with mission URLs
    const anchors = current.querySelectorAll('a[href*="/mission/"]');
    if (anchors && anchors.length > 0) {
      return anchors[0].href;
    }
    
    // Check if the current element itself is an anchor
    if (current.tagName === 'A' && current.href && current.href.includes('/mission/')) {
      return current.href;
    }
    
    // Move up the DOM tree
    current = current.parentElement;
    iterations++;
  }
  
  return null;
}

// Helper function to find parent mission card
function findParentMissionCard(element) {
  let current = element;
  let iterations = 0;
  const maxIterations = 5;
  
  while (current && iterations < maxIterations) {
    // Check if this is a mission card
    if (current.classList && 
       (current.classList.contains('mission-card') || 
        (current.dataset && current.dataset.cyId === 'availablemission') || 
        (current.getAttribute && current.getAttribute('data-cy-id') === 'availablemission'))) {
      return current;
    }
    
    // Move up the DOM tree
    current = current.parentElement;
    iterations++;
  }
  
  return null;
}

// Extract mission ID from a card element
function extractMissionIdFromCard(card) {
  // Try various methods to extract mission ID
  
  // Method 1: Try data attributes
  if (card.dataset && card.dataset.missionId) {
    return card.dataset.missionId;
  }
  
  // Method 2: Try ID attribute
  if (card.id && card.id.includes('mission-')) {
    return card.id.replace('mission-', '');
  }
  
  // Method 3: Try to find data-id attribute
  if (card.getAttribute && card.getAttribute('data-id')) {
    return card.getAttribute('data-id');
  }
  
  // Method 4: Try extracting from Vue component
  if (window.ocusVueSupport && window.ocusVueSupport.initialized) {
    try {
      const vueInstance = window.ocusVueSupport.findVueComponent(card);
      if (vueInstance) {
        const props = window.ocusVueSupport.getVueComponentProps(vueInstance);
        if (props && props.mission && props.mission.id) {
          return props.mission.id;
        }
      }
    } catch (error) {
      console.error('[OCUS] Error extracting ID from Vue component:', error);
    }
  }
  
  // Method 5: Try to find from nested elements with mission IDs
  const idElements = card.querySelectorAll('[data-mission-id], [data-id]');
  if (idElements && idElements.length > 0) {
    for (const el of idElements) {
      if (el.dataset.missionId) return el.dataset.missionId;
      if (el.dataset.id) return el.dataset.id;
    }
  }
  
  return null;
}

// Helper function to extract mission URL from a mission card
function extractMissionUrlFromCard(card) {
  // First try to find any anchor tags with mission URLs
  const anchors = card.querySelectorAll('a[href*="/mission/"]');
  if (anchors && anchors.length > 0) {
    return anchors[0].href;
  }
  
  // Try to extract from Vue data
  if (window.ocusVueSupport && window.ocusVueSupport.initialized) {
    try {
      const vueInstance = window.ocusVueSupport.findVueComponent(card);
      if (vueInstance) {
        const props = window.ocusVueSupport.getVueComponentProps(vueInstance);
        if (props && props.mission && props.mission.id) {
          // Construct URL from mission ID
          return `${window.location.origin}/mission/${props.mission.id}`;
        }
      }
    } catch (error) {
      console.error('[OCUS] Error extracting URL from Vue component:', error);
    }
  }
  
  // If we still don't have a URL, try to build one from any ID attribute
  if (card.id && card.id.includes('mission-')) {
    const missionId = card.id.replace('mission-', '');
    return `${window.location.origin}/mission/${missionId}`;
  }
  
  // Try data attributes
  if (card.dataset && card.dataset.missionId) {
    return `${window.location.origin}/mission/${card.dataset.missionId}`;
  }
  
  return null;
}

// Try to click specific elements within a mission card
function tryClickSpecificElements(missionCard) {
  console.log('[OCUS] Trying to click specific elements within mission card...');
  
  // Look for direct mission links first (most reliable for new tab)
  const missionLinks = missionCard.querySelectorAll('a[href*="/mission/"]');
  if (missionLinks && missionLinks.length > 0) {
    for (const link of missionLinks) {
      if (isVisibleElement(link)) {
        console.log(`[OCUS] Found direct mission link in card, opening: ${link.href}`);
        window.open(link.href, '_blank');
        
        // Show notification
        if (monitorConfig.missionMonitor.showNotifications) {
          chrome.runtime.sendMessage({
            type: 'SHOW_NOTIFICATION',
            title: 'Mission Link Opened!',
            message: `Opening mission in new tab`
          });
        }
        
        return true;
      }
    }
  }
  
  // Prioritized elements to click based on OCUS platform consistency
  // The order matters - we try the most reliable elements first
  const prioritizedSelectors = [
    // PRIMARY TARGETS - from extension #2 approach
    '.mission-card__action',           // The arrow icon (most reliable)
    '.mission-card__offer-tag',        // The FOOD label
    '.mission-card__date',             // Date component
    
    // Extension & Review numbers
    '.mission-card__extension-count',
    '.mission-card__review-count',
    '.extension-number', 
    '[data-cy="extension-number"]', 
    '.extension-count',
    '.review-count', 
    '[data-cy="review-count"]', 
    '.review-number',
    
    // FOOD labels (additional selectors)
    '.food-label', 
    '[data-test="food-label"]', 
    '.food-tag', 
    '.mission-tag.food',
    
    // Arrow icons (additional selectors)
    '.v-icon.mdi-arrow-right', 
    '.arrow-icon', 
    '.icon-arrow-right', 
    '.accept-arrow',
    
    // Date components (additional selectors)
    '.date-component', 
    '.mission-date', 
    '.deadline-date', 
    '[data-cy="mission-date"]',
    
    // Action buttons
    '.action-button',
    '.v-btn',
    'button',
    
    // Links that are not the entire card
    'a[href*="/mission/"]',
    'a[href*="/missions/"]'
  ];
  
  // Look for specific elements using prioritized order
  const specificElements = [];
  for (const selector of prioritizedSelectors) {
    const elements = missionCard.querySelectorAll(selector);
    elements.forEach(el => specificElements.push(el));
  }
  
  // Filter out null elements
  const validElements = specificElements.filter(el => el !== null && isVisibleElement(el));
  
  console.log(`[OCUS] Found ${validElements.length} specific elements to try clicking`);
  
  for (const element of validElements) {
    console.log(`[OCUS] Attempting to click ${element.tagName}${element.className ? '.' + element.className.replace(/ /g, '.') : ''}`);
    
    try {
      // If it's a link, always open in new tab
      if (element.tagName === 'A' && element.href) {
        const url = element.href;
        console.log(`[OCUS] Opening link in new tab: ${url}`);
        window.open(url, '_blank');
        if (typeof window.updateOpenedCounter === 'function') {
          window.updateOpenedCounter();
        }
        return true;
      }
      
      // Store current URL to detect navigation
      const originalUrl = window.location.href;
      
      // Try to click the element
      element.click();
      
      // Set up a timeout to check if we navigated to a mission page
      setTimeout(() => {
        if (window.location.href !== originalUrl && window.location.href.includes('/mission/')) {
          const missionUrl = window.location.href;
          // Go back to mission list
          history.back();
          // Open in new tab
          setTimeout(() => {
            window.open(missionUrl, '_blank');
            console.log(`[OCUS] Detected navigation to ${missionUrl}, opening in new tab`);
          }, 100);
        }
      }, 500);
      
      // Show notification
      if (monitorConfig.missionMonitor.showNotifications) {
        chrome.runtime.sendMessage({
          type: 'SHOW_NOTIFICATION',
          title: 'Mission Element Clicked!',
          message: 'Attempting to open in new tab...'
        });
      }
      
      return true;
    } catch (error) {
      console.error('[OCUS] Error clicking element:', error);
    }
  }
  
  // If no specific elements could be clicked, return false
  return false;
}

// Try to find and click standalone elements on the page
function tryFindAndClickStandaloneElements() {
  console.log('[OCUS] Looking for standalone mission elements...');
  
  // Get all specific elements on the page - prioritizing consistent elements from CHANGELOG.md
  const combinedSelector = [
    // Primary consistent elements from CHANGELOG.md that should be targeted first
    '.mission-card__offer-tag',   // The FOOD label
    '.mission-card__action',     // The arrow icon
    '.mission-card__date',       // The date component
    
    // Extension and review numbers - consistent components
    '.mission-card__extension-count', '.mission-card__review-count',
    
    // Secondary classic selectors as fallback
    '.extension-number', '[data-cy="extension-number"]', '.extension-count',
    '.review-count', '[data-cy="review-count"]', '.review-number',
    '.food-label', '[data-test="food-label"]', '.food-tag', '.mission-tag.food',
    '.v-icon.mdi-arrow-right', '.arrow-icon', '.icon-arrow-right', '.accept-arrow',
    '.date-component', '.mission-date', '.deadline-date', '[data-cy="mission-date"]',
    
    // Mission specifics
    '.mission-name', '.mission-title', '.mission-location', '.mission-details',
    
    // Vue.js specific elements (avoiding invalid :has selectors)
    '.v-list-item__title', '.v-card--link', '.v-list-item--link',
    
    // Links that might point to missions
    'a[href*="/mission/"]', 'a[href*="/missions/"]'
  ].join(', ');
  
  const elements = Array.from(document.querySelectorAll(combinedSelector));
  console.log(`[OCUS] Found ${elements.length} potential standalone elements`);
  
  // Filter to only visible elements not already in a known processed mission card
  const standaloneElements = elements.filter(el => {
    // Must be visible
    if (!isVisibleElement(el)) return false;
    
    // Check if it's part of a mission card we've already processed
    const parentCard = findParentCard(el);
    if (parentCard) {
      const missionId = generateMissionId(parentCard);
      return !monitorConfig.processedMissions.has(missionId);
    }
    
    // It's a standalone element
    return true;
  });
  
  console.log(`[OCUS] Found ${standaloneElements.length} standalone elements to try clicking`);
  
  let clickCount = 0;
  const maxClicks = monitorConfig.missionMonitor.maxSimultaneousMissions - currentlyOpeningMissions;
  
  for (const element of standaloneElements) {
    // Don't exceed max simultaneous missions
    if (clickCount >= maxClicks) break;
    
    console.log(`[OCUS] Attempting to click standalone element: ${element.tagName}${element.className ? '.' + element.className.replace(/ /g, '.') : ''}`);
    
    try {
      // If it's a link, use a different approach
      if (element.tagName === 'A' && element.href) {
        const url = element.href;
        console.log(`[OCUS] Opening link in new tab: ${url}`);
        window.open(url, '_blank');
        if (typeof window.updateOpenedCounter === 'function') {
          window.updateOpenedCounter();
        }
        clickCount++;
        currentlyOpeningMissions++;
        
        // Decrement counter after delay
        setTimeout(() => {
          currentlyOpeningMissions--;
        }, 5000);
        
        continue;
      }
      
      // Find clickable parent or ancestor if the element itself isn't directly clickable
      let clickTarget = element;
      
      // If the element doesn't look clickable, try to find a clickable parent
      if (!(element.tagName === 'BUTTON' || 
            element.tagName === 'A' || 
            element.getAttribute('role') === 'button' || 
            element.classList.contains('v-btn') || 
            element.classList.contains('clickable'))) {
        
        // Look for clickable ancestors
        let parent = element.parentElement;
        let depth = 0;
        const maxDepth = 3; // Don't go too far up
        
        while (parent && depth < maxDepth) {
          if (parent.tagName === 'BUTTON' || 
              parent.tagName === 'A' || 
              parent.getAttribute('role') === 'button' || 
              parent.classList.contains('v-btn') || 
              parent.classList.contains('clickable')) {
            clickTarget = parent;
            break;
          }
          parent = parent.parentElement;
          depth++;
        }
      }
      
      // Create and dispatch a click event
      const clickEvent = new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
        view: window
      });
      
      clickTarget.dispatchEvent(clickEvent);
      console.log('[OCUS] Successfully clicked standalone element:', clickTarget);
      
      // Show notification
      if (monitorConfig.missionMonitor.showNotifications) {
        chrome.runtime.sendMessage({
          type: 'SHOW_NOTIFICATION',
          title: 'Mission Found!',
          message: 'Clicking on standalone mission element...'
        });
      }
      
      clickCount++;
      currentlyOpeningMissions++;
      
      // Decrement counter after delay
      setTimeout(() => {
        currentlyOpeningMissions--;
      }, 5000);
      
    } catch (error) {
      console.error('[OCUS] Error clicking standalone element:', error);
    }
  }
  
  return clickCount > 0;
}

// Try to find missions using Vue.js support if available
function tryFindMissionsWithVueSupport() {
  if (!window.ocusVueSupport) {
    console.log('[OCUS] Vue support not available');
    return;
  }
  
  console.log('[OCUS] Trying to find missions using Vue support...');
  
  try {
    // Get Vue component instances from the page
    const instances = window.ocusVueSupport?.findVueComponentInstances('mission') || [];
    
    console.log(`[OCUS] Found ${instances.length} potential Vue mission components`);
    
    let clickCount = 0;
    const maxClicks = monitorConfig.missionMonitor.maxSimultaneousMissions - currentlyOpeningMissions;
    
    for (const instance of instances) {
      // Don't exceed max simultaneous missions
      if (clickCount >= maxClicks) break;
      
      // Try to extract element from Vue instance
      const element = instance.$el || instance._vnode?.el || instance.elm;
      if (!element) {
        console.log('[OCUS] Could not extract element from Vue instance:', instance);
        continue;
      }
      
      // Generate a unique ID for this Vue component
      const missionId = generateMissionId(element) || `vue-mission-${Math.random().toString(36).substring(2, 15)}`;
      
      // Skip if we've already processed this mission
      if (monitorConfig.processedMissions.has(missionId)) {
        continue;
      }
      
      // Mark as processed
      monitorConfig.processedMissions.add(missionId);
      
      // Save updated processedMissions to storage
      chrome.storage.local.get(['config'], (result) => {
        const updatedConfig = result.config || {};
        updatedConfig.processedMissions = Array.from(monitorConfig.processedMissions);
        chrome.storage.local.set({ config: updatedConfig });
      });
      
      console.log('[OCUS] Trying to interact with Vue mission component:', instance);
      
      // Try to extract mission URL from instance props or data
      let missionUrl = null;
      
      // Try to access props using Vue-specific approaches
      const props = window.ocusVueSupport?.getVueComponentProps(instance);
      
      if (props) {
        // Look for mission URL in various prop patterns
        if (props.mission && props.mission.id) {
          missionUrl = `/missions/${props.mission.id}`;
        } else if (props.id) {
          missionUrl = `/missions/${props.id}`;
        } else if (props.href && props.href.includes('/mission')) {
          missionUrl = props.href;
        } else if (props.to && props.to.includes('/mission')) {
          missionUrl = props.to;
        }
      }
      
      // If we found a mission URL, open it
      if (missionUrl) {
        // Make sure it's a full URL
        if (!missionUrl.startsWith('http')) {
          missionUrl = `https://app.ocus.com${missionUrl.startsWith('/') ? '' : '/'}${missionUrl}`;
        }
        
        console.log(`[OCUS] Opening Vue mission in new tab: ${missionUrl}`);
        window.open(missionUrl, '_blank');
        if (typeof window.updateOpenedCounter === 'function') {
          window.updateOpenedCounter();
        }
        
        // Update stats
        chrome.runtime.sendMessage({ type: 'MISSION_FOUND' });
        
        // Show notification
        if (monitorConfig.missionMonitor.showNotifications) {
          chrome.runtime.sendMessage({
            type: 'SHOW_NOTIFICATION',
            title: 'Mission Found!',
            message: 'Opening Vue mission in new tab...'
          });
        }
        
        clickCount++;
        currentlyOpeningMissions++;
        
        // Decrement counter after delay
        setTimeout(() => {
          currentlyOpeningMissions--;
        }, 5000);
        
        continue;
      }
      
      // If we couldn't extract a URL, try clicking the element
      try {
        console.log('[OCUS] Clicking Vue component element:', element);
        
        // Enhanced click handling for Vue components
        // 1. Try native click first
        element.click();
        
        // 2. If that doesn't work, try a MouseEvent
        const clickEvent = new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        element.dispatchEvent(clickEvent);
        
        // Add more complete interaction sequence for Vue
        const mousedownEvent = new MouseEvent('mousedown', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        element.dispatchEvent(mousedownEvent);
        
        const mouseupEvent = new MouseEvent('mouseup', {
          bubbles: true,
          cancelable: true,
          view: window
        });
        element.dispatchEvent(mouseupEvent);
        
        // Update stats
        chrome.runtime.sendMessage({ type: 'MISSION_FOUND' });
        
        // Show notification
        if (monitorConfig.missionMonitor.showNotifications) {
          chrome.runtime.sendMessage({
            type: 'SHOW_NOTIFICATION',
            title: 'Mission Found!',
            message: 'Clicking Vue mission element...'
          });
        }
        
        clickCount++;
        currentlyOpeningMissions++;
        
        // Decrement counter after delay
        setTimeout(() => {
          currentlyOpeningMissions--;
        }, 5000);
      } catch (error) {
        console.error('[OCUS] Error clicking Vue component element:', error);
      }
    }
    
    return clickCount > 0;
  } catch (error) {
    console.error('[OCUS] Error using Vue support:', error);
    return false;
  }
}

// Generate a unique ID for a mission card
function generateMissionId(missionCard) {
  // Try to find mission ID in href attribute
  const linkElement = missionCard.querySelector('a[href*="/mission/"]');
  if (linkElement) {
    const href = linkElement.getAttribute('href');
    const match = href.match(/\/mission\/([a-zA-Z0-9-]+)/);
    if (match && match[1]) {
      return match[1];
    }
  }
  
  // Try to find mission ID in data attributes
  const dataId = missionCard.getAttribute('data-id') || 
                 missionCard.getAttribute('data-mission-id') || 
                 missionCard.getAttribute('data-cy-id');
  if (dataId) {
    return dataId;
  }
  
  // Generate ID based on text content
  const textContent = missionCard.textContent.trim();
  if (textContent) {
    // Create a hash from text content
    let hash = 0;
    for (let i = 0; i < textContent.length; i++) {
      hash = ((hash << 5) - hash) + textContent.charCodeAt(i);
      hash |= 0; // Convert to 32bit integer
    }
    return 'text-' + Math.abs(hash);
  }
  
  // Generate ID based on position
  return 'pos-' + generatePositionId(missionCard);
}

// Generate a position-based ID for an element
function generatePositionId(element) {
  if (!element) return 'unknown';
  
  // Get element position
  const rect = element.getBoundingClientRect();
  
  // Round to nearest 5px to allow for small positioning differences
  const x = Math.round(rect.left / 5) * 5;
  const y = Math.round(rect.top / 5) * 5;
  const width = Math.round(rect.width / 5) * 5;
  const height = Math.round(rect.height / 5) * 5;
  
  return `${x}-${y}-${width}-${height}`;
}

// Helper function to direct handle clicks on mission component elements
function openMissionComponentInNewTab(component) {
  // If it's a link, get the href
  if (component.tagName === 'A' && component.getAttribute('href')) {
    const href = component.getAttribute('href');
    
    // Make sure it's a mission link
    if (href.includes('/mission/')) {
      // Extract mission ID
      const match = href.match(/\/mission\/([a-zA-Z0-9-]+)/);
      const missionId = match && match[1] ? match[1] : 'unknown';
      
      // Open in new tab
      console.log(`Opening mission link in new tab: ${href}`);
      
      // Construct full URL if needed
      let fullUrl = href;
      if (href.startsWith('/')) {
        fullUrl = window.location.origin + href;
      }
      
      // Update stats
      chrome.runtime.sendMessage({ type: 'MISSION_OPENED' });
      
      // Show notification
      if (monitorConfig.missionMonitor.showNotifications) {
        chrome.runtime.sendMessage({
          type: 'SEND_NOTIFICATION',
          title: 'Mission Found',
          message: `Opening mission ${missionId} in new tab`,
          priority: 1
        });
      }
      
      // Open in new tab
      window.open(fullUrl, '_blank');
      
      // Decrement counter after a delay
      setTimeout(() => {
        currentlyOpeningMissions--;
      }, 2000);
      
      return;
    }
  }
  
  // For non-link elements, try to find a click handler
  console.log('Clicking on non-link component to open mission');
  
  // Click the component
  component.click();
  
  // For elements with Vue.js click handlers, we need to also check for new tabs
  setTimeout(() => {
    // Decrement counter after a delay
    currentlyOpeningMissions--;
  }, 2000);
}

// Open a mission card in a new tab with enhanced direct element targeting
async function openMissionInNewTab(missionCard, missionId) {
  console.log('[OCUS] Enhanced openMissionInNewTab starting for mission ID:', missionId);
  
  // First try the specific direct element targeting approach
  // This targets interactive elements within mission cards that might open the mission
  const specificElements = [
    // 1. Extension numbers (HIGHEST priority) - as requested
    missionCard.querySelector('.extension-number'), 
    missionCard.querySelector('[data-cy="extension-number"]'),
    missionCard.querySelector('[data-test="extension-number"]'),
    missionCard.querySelector('[data-automation-id="extension-number"]'),
    missionCard.querySelector('.mission-extension'),
    missionCard.querySelector('.extension-id'),
    missionCard.querySelector('[aria-label*="extension"]'),
    
    // 2. Review numbers (HIGH priority) - as requested
    missionCard.querySelector('.review-count'),
    missionCard.querySelector('.review-number'),
    missionCard.querySelector('[data-cy="review-count"]'),
    missionCard.querySelector('[data-review-count]'),
    missionCard.querySelector('.reviews-needed'),
    missionCard.querySelector('[aria-label*="review"]'),
    missionCard.querySelector('.mission-reviews'),
    
    // 3. FOOD labels (HIGH priority) - as requested
    missionCard.querySelector('.food-label'),
    missionCard.querySelector('.food-tag'),
    missionCard.querySelector('.mission-tag.food'),
    missionCard.querySelector('[data-tag="food"]'),
    missionCard.querySelector('.v-chip:contains("FOOD")'),
    missionCard.querySelector('.mission-category-food'),
    missionCard.querySelector('.mission-card__offer-tag:contains("FOOD")'),
    
    // 4. Arrow icons (HIGH priority) - as requested
    missionCard.querySelector('.v-icon.notranslate.mdi.mdi-arrow-right'),
    missionCard.querySelector('.v-icon.mdi-arrow-right'),
    missionCard.querySelector('.v-icon.mdi-chevron-right'),
    missionCard.querySelector('.arrow-icon'),
    missionCard.querySelector('.icon-arrow-right'),
    missionCard.querySelector('.icon-chevron-right'),
    missionCard.querySelector('i[aria-hidden="true"].v-icon'),
    missionCard.querySelector('[aria-label="View mission"]'),
    missionCard.querySelector('.mission-card__action'), // Action area with arrow icon
    
    // 5. Date components (HIGH priority) - as requested
    missionCard.querySelector('.mission-date'),
    missionCard.querySelector('.date-component'),
    missionCard.querySelector('.deadline'),
    missionCard.querySelector('.timestamp'),
    missionCard.querySelector('.mission-card__date'),
    missionCard.querySelector('[data-cy="mission-date"]'),
    missionCard.querySelector('[data-test="mission-deadline"]'),
    missionCard.querySelector('.due-date'),
    
    // Card structure elements (Nuxt.js/Vue specific)
    missionCard.querySelector('.mission-card__info'),
    missionCard.querySelector('.mission-card__offer'),
    missionCard.querySelector('.mission-card__organization'),
    missionCard.querySelector('.mission-card__icon'),
    missionCard.querySelector('.v-card--link'),
    missionCard.querySelector('.v-card__title'),
    missionCard.querySelector('.v-card__text'),
    
    // Other high-priority click targets
    missionCard.querySelector('.font-weight-bold'),
    missionCard.querySelector('p.font-weight-bold'),
    missionCard.querySelector('.mission-card__offer-tag'),
    missionCard.querySelector('.v-chip'),
    missionCard.querySelector('.v-chip__content'),
    missionCard.querySelector('button.action-button'),
    missionCard.querySelector('button.view-mission'),
    missionCard.querySelector('button.view-details'),
    missionCard.querySelector('[role="button"]'),
    missionCard.querySelector('.v-btn'),
    missionCard.querySelector('[data-mission-id]'),
    missionCard.querySelector('[data-id]'),
    missionCard.querySelector('[data-cy-id="availablemission"]'),
    missionCard.querySelector('[data-cy-id]'),
    missionCard.querySelector('.v-list-item'),
    missionCard.querySelector('.nuxt-link')
  ].filter(el => el !== null && isVisibleElement(el));
  
  console.log(`[OCUS] Found ${specificElements.length} interactive elements in mission card`);
  
  // First try clicking a specific interactive element
  if (specificElements.length > 0) {
    // Try multiple elements in order until one works
    // This helps when the first element isn't actually clickable
    const maxElementsToTry = Math.min(3, specificElements.length);
    
    for (let i = 0; i < maxElementsToTry; i++) {
      const element = specificElements[i];
      console.log(`[OCUS] Attempting to click interactive element ${i+1}/${maxElementsToTry}: ${element.tagName}${element.className ? '.' + element.className.replace(/ /g, '.') : ''}`);
      
      try {
        // If the element is an anchor tag with href, open it directly
        if (element.tagName === 'A' && element.getAttribute('href')) {
          let href = element.getAttribute('href');
          
          // Ensure we have a full URL
          if (href.startsWith('/')) {
            href = window.location.origin + href;
          }
          
          console.log(`[OCUS] Opening element href in new tab: ${href}`);
          window.open(href, '_blank');
          
          // Successfully opened - update stats and return
          updateMissionOpenedStats(missionId);
          return;
        } else {
          // For non-anchor elements, find clickable parent if needed
          let clickTarget = element;
          
          // If the element doesn't look directly clickable, find a clickable parent
          if (!(element.tagName === 'BUTTON' || 
                element.tagName === 'A' || 
                element.getAttribute('role') === 'button' || 
                element.classList.contains('v-btn') || 
                element.classList.contains('clickable') ||
                element.classList.contains('btn'))) {
            
            // Look for clickable ancestors up to 3 levels
            let parent = element.parentElement;
            let depth = 0;
            const maxDepth = 3;
            
            while (parent && depth < maxDepth) {
              if (parent.tagName === 'BUTTON' || 
                  parent.tagName === 'A' || 
                  parent.getAttribute('role') === 'button' || 
                  parent.classList.contains('v-btn') || 
                  parent.classList.contains('clickable') ||
                  parent.classList.contains('btn') ||
                  parent.classList.contains('v-card--link') ||
                  parent.classList.contains('mission-card') ||
                  parent.classList.contains('mission-card__action') ||
                  parent.hasAttribute('data-cy-id') ||
                  parent.getAttribute('tabindex') === '0') {
                clickTarget = parent;
                break;
              }
              parent = parent.parentElement;
              depth++;
            }
          }
          
          console.log(`[OCUS] Clicking target element: ${clickTarget.tagName}${clickTarget.className ? '.' + clickTarget.className.replace(/ /g, '.') : ''}`);
          
          // Check if the element has a Vue router link or Nuxt link
          const hasVueRouter = clickTarget.hasAttribute('to') || 
                              clickTarget.classList.contains('nuxt-link') || 
                              clickTarget.classList.contains('router-link');
          
          // Enhanced click approach for Vue/Nuxt elements
          if (hasVueRouter) {
            console.log('[OCUS] Using Vue/Nuxt specific interaction approach');
            
            // Get the destination from the 'to' attribute if available
            const routerDestination = clickTarget.getAttribute('to');
            if (routerDestination) {
              console.log(`[OCUS] Found Vue router destination: ${routerDestination}`);
              
              // Try to construct a full URL for opening in a new tab
              // This is a best-effort approach that may or may not work depending on the app
              const fullUrl = routerDestination.startsWith('/') 
                ? window.location.origin + routerDestination
                : window.location.origin + '/' + routerDestination;
              
              window.open(fullUrl, '_blank');
              updateMissionOpenedStats(missionId);
              return;
            }
          }
          
          // Try multiple click methods for maximum compatibility
          // First try plain click - simplest and most standard
          try {
            if (clickTarget.click) {
              clickTarget.click();
              // Wait briefly to see if a navigation happens
              setTimeout(() => {
                console.log('[OCUS] Checking if click triggered navigation...');
              }, 100);
            }
          } catch (clickError) {
            console.error('[OCUS] Error with direct click:', clickError);
          }
          
          // Then try comprehensive event dispatch for better framework compatibility
          try {
            // More comprehensive event sequence for frameworks
            const events = ['mouseenter', 'mouseover', 'mousedown', 'mouseup', 'click'];
            events.forEach(eventType => {
              try {
                const event = new MouseEvent(eventType, {
                  view: window,
                  bubbles: true,
                  cancelable: true,
                  buttons: 1,
                  clientX: Math.floor(clickTarget.getBoundingClientRect().left + 5),
                  clientY: Math.floor(clickTarget.getBoundingClientRect().top + 5)
                });
                clickTarget.dispatchEvent(event);
              } catch (eventError) {
                console.error(`[OCUS] Error dispatching ${eventType} event:`, eventError);
              }
            });
            
            // For Vue-specific elements, try activating them with __vue__ property
            if (clickTarget.__vue__) {
              console.log('[OCUS] Element has Vue instance, attempting Vue-specific activation');
              try {
                if (clickTarget.__vue__.$emit) {
                  clickTarget.__vue__.$emit('click');
                }
              } catch (vueError) {
                console.error('[OCUS] Error activating Vue element:', vueError);
              }
            }
          } catch (e) {
            console.error('[OCUS] Error with event dispatching:', e);
          }
        }
        
        // Update statistics - this element might have triggered a navigation
        updateMissionOpenedStats(missionId);
        
        // Wait briefly before trying the next element
        // This gives time for any framework to process the click
        await new Promise(resolve => setTimeout(resolve, 300));
        
      } catch (error) {
        console.error(`[OCUS] Error clicking element ${i+1}:`, error);
        // Continue to next element
      }
    }
  }
  
  // Helper function to update stats and show notifications
  function updateMissionOpenedStats(missionId) {
    // Update stats
    chrome.runtime.sendMessage({ type: 'MISSION_OPENED' });
    
    // Show notification
    if (monitorConfig.missionMonitor.showNotifications) {
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Mission Found',
        message: `Opening mission via interactive element`,
        priority: 1
      });
    }
    
    // Also show UI message if helper is available
    if (window.ocusHelpers && typeof window.ocusHelpers.showStatusMessage === 'function') {
      window.ocusHelpers.showStatusMessage(`Opening mission ${missionId} via interactive element`, true);
    }
    
    // Decrement counter after a delay
    setTimeout(() => {
      currentlyOpeningMissions--;
    }, 2000);
  }
  
  // Fallback: Look for direct links using selectors
  console.log('[OCUS] Falling back to link detection approach');
  
  const linkSelectors = [
    'a[href*="/mission/"]',
    'a[href*="/missions/"]',
    'a[href*="mission"]',
    '.v-card--link[href*="/mission/"]',
    '.v-card--link',
    '[role="link"][href*="/mission/"]',
    '[data-cy="mission-details-link"]',
    'a[href*="detail"]' // Sometimes mission links have 'detail' in the URL
  ];
  
  for (const selector of linkSelectors) {
    const linkElement = missionCard.querySelector(selector);
    if (linkElement) {
      // Use the direct link
      let href = linkElement.getAttribute('href');
      
      // Skip if no href or invalid
      if (!href) continue;
      
      // Construct full URL if needed
      if (href.startsWith('/')) {
        href = window.location.origin + href;
      }
      
      console.log(`[OCUS] Opening mission link in new tab: ${href}`);
      
      // Update stats
      chrome.runtime.sendMessage({ type: 'MISSION_OPENED' });
      
      // Show notification
      if (monitorConfig.missionMonitor.showNotifications) {
        chrome.runtime.sendMessage({
          type: 'SEND_NOTIFICATION',
          title: 'Mission Found',
          message: `Opening mission ${missionId} in new tab`,
          priority: 1
        });
      }
      
      // Also show UI message using our helper
      if (window.ocusHelpers && typeof window.ocusHelpers.showStatusMessage === 'function') {
        window.ocusHelpers.showStatusMessage(`Opening mission ${missionId} in new tab`, true);
      }
      
      // Open in new tab
      window.open(href, '_blank');
      
      // Decrement counter after a delay
      setTimeout(() => {
        currentlyOpeningMissions--;
      }, 2000);
      
      return;
    }
  }
  
  // Check for any URLs in the card (broader search)
  console.log('[OCUS] Looking for any mission-related URLs in the card');
  
  // Advanced URL detection
  // 1. Try data attributes that might contain URLs
  let missionUrl = null;
  const dataAttributes = ['href', 'data-href', 'data-url', 'data-mission-url', 'data-link'];
  
  for (const attr of dataAttributes) {
    if (missionCard.hasAttribute(attr)) {
      const attrValue = missionCard.getAttribute(attr);
      if (attrValue && (attrValue.includes('mission') || attrValue.match(/\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i))) {
        missionUrl = attrValue;
        break;
      }
    }
  }
  
  // 2. Check all nested links (even if they don't match our initial selectors)
  if (!missionUrl) {
    const allLinks = missionCard.querySelectorAll('a');
    for (const link of allLinks) {
      let href = link.getAttribute('href');
      if (!href) continue;
      
      // Check for mission-like paths (also accept UUIDs as potential mission IDs)
      if (href.includes('mission') || href.match(/\/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)) {
        missionUrl = href;
        break;
      }
    }
  }
  
  // 3. Check background images for mission URL fragments
  if (!missionUrl) {
    try {
      const elementsWithBg = Array.from(missionCard.querySelectorAll('*')).filter(el => {
        try {
          const style = window.getComputedStyle(el);
          return style.backgroundImage && style.backgroundImage !== 'none';
        } catch (e) {
          return false;
        }
      });
      
      for (const el of elementsWithBg) {
        const style = window.getComputedStyle(el);
        const bgImage = style.backgroundImage;
        
        // Check for mission paths in the background image URL
        const urlMatch = bgImage.match(/url\(['"]?(.*?)['"]?\)/);
        if (urlMatch && urlMatch[1]) {
          const bgUrl = urlMatch[1];
          if (bgUrl.includes('mission')) {
            const pathMatch = bgUrl.match(/(\/mission\/[\w-]+)/) || bgUrl.match(/(\/missions\/[\w-]+)/);
            if (pathMatch && pathMatch[1]) {
              missionUrl = pathMatch[1];
              break;
            }
          }
        }
      }
    } catch (e) {
      console.error('[OCUS] Error analyzing background images:', e);
    }
  }
  
  // If we found a URL through any method, open it
  if (missionUrl) {
    // Ensure it's a full URL
    if (missionUrl.startsWith('/')) {
      missionUrl = window.location.origin + missionUrl;
    }
    
    console.log(`[OCUS] Opening extracted mission URL: ${missionUrl}`);
    
    // Update stats
    chrome.runtime.sendMessage({ type: 'MISSION_OPENED' });
    
    // Show notification
    if (monitorConfig.missionMonitor.showNotifications) {
      chrome.runtime.sendMessage({
        type: 'SEND_NOTIFICATION',
        title: 'Mission Found',
        message: `Opening mission URL: ${missionUrl.substring(0, 30)}...`,
        priority: 1
      });
    }
    
    // Open in new tab
    window.open(missionUrl, '_blank');
    
    // Decrement counter after a delay
    setTimeout(() => {
      currentlyOpeningMissions--;
    }, 2000);
    
    return;
  }
  
  // Last resort: try clicking the card directly
  console.log('[OCUS] No URLs found, attempting to click the entire mission card');
  
  try {
    // Try multiple clicking methods for maximum compatibility
    // 1. Direct click
    if (missionCard.click) {
      missionCard.click();
    }
    
    // 2. Vue/Nuxt specific approach: check for the tabindex="0" elements which often indicate clickable cards
    const clickableElements = missionCard.querySelectorAll('[tabindex="0"]');
    if (clickableElements.length > 0) {
      console.log(`[OCUS] Trying tabindex="0" elements (${clickableElements.length} found)`);
      
      for (const element of clickableElements) {
        try {
          // Try clicking the element directly
          element.click();
          
          // If it's a Vue component, also try Vue-specific activation
          if (element.__vue__) {
            try {
              if (element.__vue__.$emit) {
                element.__vue__.$emit('click');
              }
            } catch (vueError) {
              console.error('[OCUS] Error with Vue click:', vueError);
            }
          }
          
          // Dispatch a more comprehensive event sequence for Vue/Nuxt
          ['mouseenter', 'mouseover', 'mousedown', 'mouseup', 'click'].forEach(eventType => {
            try {
              const event = new MouseEvent(eventType, {
                view: window,
                bubbles: true,
                cancelable: true,
                buttons: 1
              });
              element.dispatchEvent(event);
            } catch (e) {
              console.error(`[OCUS] Error dispatching ${eventType}:`, e);
            }
          });
          
          updateMissionOpenedStats(missionId);
          return;
        } catch (e) {
          console.error('[OCUS] Error clicking tabindex element:', e);
        }
      }
    }
    
    // 3. Try to find elements with background images that might contain mission info
    const elementsWithBackground = Array.from(missionCard.querySelectorAll('*')).filter(el => {
      try {
        const style = window.getComputedStyle(el);
        return style.backgroundImage && style.backgroundImage !== 'none' && !style.backgroundImage.includes('gradient');
      } catch (e) {
        return false;
      }
    });
    
    if (elementsWithBackground.length > 0) {
      console.log(`[OCUS] Found ${elementsWithBackground.length} elements with background images, analyzing...`);
      
      for (const element of elementsWithBackground) {
        try {
          // Try to extract a URL from the background-image
          const style = window.getComputedStyle(element);
          const bgImage = style.backgroundImage;
          const urlMatch = bgImage.match(/url\(['"](.*?)['"]\)/i);
          
          if (urlMatch && urlMatch[1]) {
            const bgUrl = urlMatch[1];
            console.log(`[OCUS] Found background image URL: ${bgUrl}`);
            
            // Look for a mission ID or other identifier in the URL
            const pathParts = bgUrl.split('/');
            const potentialIds = pathParts.filter(part => /^[a-f0-9-]{8,}$/i.test(part));
            
            if (potentialIds.length > 0) {
              console.log(`[OCUS] Potential mission ID found in background image: ${potentialIds[0]}`);
              // Try to construct a mission URL from this ID
              const guessedMissionUrl = `${window.location.origin}/missions/${potentialIds[0]}`;
              window.open(guessedMissionUrl, '_blank');
              updateMissionOpenedStats(missionId);
              return;
            }
          }
          
          // If we couldn't extract a useful URL, try clicking the element with the background
          element.click();
          updateMissionOpenedStats(missionId);
          return;
        } catch (e) {
          console.error('[OCUS] Error processing background element:', e);
        }
      }
    }
    
    // 2. Event dispatch method (more compatible with some frameworks)
    try {
      ['mousedown', 'mouseup', 'click'].forEach(eventType => {
        const event = new MouseEvent(eventType, {
          view: window,
          bubbles: true,
          cancelable: true,
          buttons: 1
        });
        missionCard.dispatchEvent(event);
      });
    } catch (e) {
      console.error('[OCUS] Error dispatching mouse events:', e);
    }
    
    // 3. Try programmatic navigation if the card has a data-id that might be a mission ID
    const possibleIds = [
      missionCard.getAttribute('data-id'),
      missionCard.getAttribute('data-mission-id'),
      missionCard.getAttribute('data-cy-id'),
      missionCard.id
    ].filter(id => id && (id.includes('mission') || id.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)));
    
    if (possibleIds.length > 0) {
      const id = possibleIds[0];
      const constructedUrl = window.location.origin + '/mission/' + id.replace('mission-', '');
      console.log(`[OCUS] Attempting programmatic navigation with constructed URL: ${constructedUrl}`);
      window.open(constructedUrl, '_blank');
    }
  } catch (e) {
    console.error('[OCUS] Error with direct card interactions:', e);
  }
  
  // Update stats
  chrome.runtime.sendMessage({ type: 'MISSION_OPENED' });
  
  // Show notification
  if (monitorConfig.missionMonitor.showNotifications) {
    chrome.runtime.sendMessage({
      type: 'SEND_NOTIFICATION',
      title: 'Mission Found',
      message: `Attempted to open mission ${missionId}`,
      priority: 1
    });
  }
  
  // Decrement counter after a delay
  setTimeout(() => {
    currentlyOpeningMissions--;
  }, 2000);
}

// Set up an improved mutation observer to detect new mission cards
function setupMutationObserver() {
  if (observerActive) {
    return; // Already set up
  }
  
  console.log('[OCUS] Setting up enhanced mutation observer for mission cards');
  
  // Create a new mutation observer with more comprehensive checks
  mutationObserver = new MutationObserver((mutations) => {
    // Check if we should scan based on mutations
    let shouldScan = false;
    let importantChanges = false;
    
    for (const mutation of mutations) {
      // Check for attribute changes that might indicate a mission list update
      if (mutation.type === 'attributes') {
        const targetElement = mutation.target;
        if (targetElement.matches && (
            targetElement.matches('.mission-list') ||
            targetElement.matches('.mission-container') ||
            targetElement.matches('.missions-wrapper') ||
            targetElement.matches('[data-cy="missions-container"]') ||
            targetElement.closest('.mission-list, .mission-container, .missions-wrapper, [data-cy="missions-container"]')
        )) {
          console.log('[OCUS] Detected attribute change in mission container');
          importantChanges = true;
          shouldScan = true;
          break;
        }
      }
      
      // Check if nodes were added
      if (mutation.addedNodes.length > 0) {
        for (const node of mutation.addedNodes) {
          // Skip non-element nodes
          if (node.nodeType !== Node.ELEMENT_NODE) {
            continue;
          }
          
          // Check for all possible mission card selectors
          if (node.matches && missionCardSelectors.some(selector => {
            try {
              return node.matches(selector) || (node.querySelector && node.querySelector(selector));
            } catch (e) {
              // Some selectors might cause errors in certain browsers
              return false;
            }
          })) {
            console.log('[OCUS] Detected new mission card added to DOM');
            importantChanges = true;
            shouldScan = true;
            break;
          }
          
          // Also check for mission list containers being added
          if (node.matches && (
              node.matches('.mission-list') ||
              node.matches('.mission-container') ||
              node.matches('.missions-wrapper') ||
              node.matches('[data-cy="missions-container"]') ||
              (node.querySelector && node.querySelector('.mission-list, .mission-container, .missions-wrapper, [data-cy="missions-container"]'))
          )) {
            console.log('[OCUS] Detected new mission container added to DOM');
            importantChanges = true;
            shouldScan = true;
            break;
          }
        }
      }
      
      // Check if nodes were removed (could indicate list refresh)
      if (!shouldScan && mutation.removedNodes.length > 0) {
        for (const node of mutation.removedNodes) {
          // Skip non-element nodes
          if (node.nodeType !== Node.ELEMENT_NODE) {
            continue;
          }
          
          // Check if a mission card was removed (might indicate list refresh)
          if (node.matches && missionCardSelectors.some(selector => {
            try {
              return node.matches(selector) || (node.querySelector && node.querySelector(selector));
            } catch (e) {
              return false;
            }
          })) {
            console.log('[OCUS] Detected mission card removed from DOM');
            shouldScan = true;
            break;
          }
        }
      }
      
      if (shouldScan) {
        break;
      }
    }
    
    // Scan if needed with appropriate delay
    if (shouldScan && monitorConfig.missionMonitor.enabled) {
      // Use shorter delay for important changes, longer for less critical ones
      const delay = importantChanges ? 300 : 800;
      
      // Small delay to ensure DOM is fully updated
      setTimeout(() => {
        scanForMissionCards();
      }, delay);
    }
  });
  
  // Start observing
  mutationObserver.observe(document.body, {
    childList: true,
    subtree: true
  });
  
  observerActive = true;
}

// Enhanced visibility check with more robust criteria
function isVisibleElement(element) {
  // Use the global helper if available
  if (window.ocusHelpers && typeof window.ocusHelpers.isVisibleElement === 'function') {
    return window.ocusHelpers.isVisibleElement(element);
  }
  
  // Fallback implementation with enhanced checks
  if (!element) return false;
  
  try {
    // First check if element is connected to the DOM
    if (!element.isConnected) return false;
    
    // Check computed styles
    const style = window.getComputedStyle(element);
    if (style.display === 'none' || 
        style.visibility === 'hidden' || 
        style.opacity === '0') {
      return false;
    }
    
    // Check dimensions
    if (element.offsetWidth <= 0 || element.offsetHeight <= 0) {
      return false;
    }
    
    // Check if element is actually in the viewport
    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) {
      return false;
    }
    
    // Check if element is within viewport bounds (at least partially)
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth;
    const viewportHeight = window.innerHeight || document.documentElement.clientHeight;
    
    if (rect.right < 0 || rect.bottom < 0 || 
        rect.left > viewportWidth || rect.top > viewportHeight) {
      // Element is completely outside viewport
      // But we'll still consider it visible for mission cards as they may be scrolled into view
      // Just log this information
      console.log('[OCUS] Element outside viewport, but considered potentially visible');
    }
    
    // Check if element or its ancestors have overflow: hidden and the element is outside the container
    let parent = element.parentElement;
    while (parent && parent !== document.body) {
      const parentStyle = window.getComputedStyle(parent);
      if ((parentStyle.overflow === 'hidden' || 
           parentStyle.overflowY === 'hidden' || 
           parentStyle.overflowX === 'hidden') && 
          (element.offsetTop < parent.scrollTop || 
           element.offsetLeft < parent.scrollLeft || 
           element.offsetTop + element.offsetHeight > parent.scrollTop + parent.offsetHeight || 
           element.offsetLeft + element.offsetWidth > parent.scrollLeft + parent.offsetWidth)) {
        // Element is hidden by overflow
        console.log('[OCUS] Element hidden by parent overflow');
        return false;
      }
      parent = parent.parentElement;
    }
    
    return true;
  } catch (e) {
    console.error('[OCUS] Error in isVisibleElement:', e);
    // In case of error, assume element is visible to avoid missing potential missions
    return true;
  }
}

// Display a status indicator to show if mission monitoring is enabled
function showStatusIndicator(enabled, customText) {
  // Only proceed if document.body exists
  if (!document.body) {
    console.log('[OCUS] Cannot show status indicator - document.body not available');
    return;
  }
  
  // Use helper function if available
  if (window.ocusHelpers && typeof window.ocusHelpers.showStatusMessage === 'function') {
    window.ocusHelpers.showStatusMessage(
      customText || (enabled ? 'Mission Monitor: ON' : 'Mission Monitor: OFF'),
      enabled ? true : false
    );
    return;
  }
  
  // Remove any existing indicator
  const existingIndicator = document.getElementById('ocus-monitor-indicator');
  if (existingIndicator) {
    existingIndicator.remove();
  }
  
  // Create indicator element
  const indicator = document.createElement('div');
  indicator.id = 'ocus-monitor-indicator';
  indicator.textContent = customText || (enabled ? 'Mission Monitor: ON' : 'Mission Monitor: OFF');
  
  // Use helper function for adding styles if available
  if (window.ocusHelpers && typeof window.ocusHelpers.safeAppendStyles === 'function') {
    window.ocusHelpers.safeAppendStyles(`
      #ocus-monitor-indicator {
        position: fixed;
        bottom: 10px;
        right: 10px;
        padding: 5px 10px;
        border-radius: 5px;
        z-index: 9999;
        font-size: 12px;
        font-family: Arial, sans-serif;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        background: ${enabled ? '#4CAF50' : '#F44336'};
        color: white;
        transition: opacity 0.3s;
        opacity: 0.9;
        pointer-events: none;
      }
    `, 'ocus-monitor-indicator-styles');
  } else {
    // Style the indicator directly as fallback
    Object.assign(indicator.style, {
      position: 'fixed',
      bottom: '10px',
      right: '10px',
      padding: '5px 10px',
      borderRadius: '5px',
      zIndex: '9999',
      fontSize: '12px',
      fontFamily: 'Arial, sans-serif',
      boxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
      background: enabled ? '#4CAF50' : '#F44336',
      color: 'white',
      transition: 'opacity 0.3s',
      opacity: '0.9',
      pointerEvents: 'none'
    });
  }
  
  // Add to document
  document.body.appendChild(indicator);
  
  // Hide after a few seconds
  setTimeout(() => {
    if (indicator.parentNode) {
      indicator.style.opacity = '0';
      
      // Remove after fade out
      setTimeout(() => {
        if (indicator.parentNode) {
          indicator.remove();
        }
      }, 1000);
    }
  }, 5000);
}

// Initialize when the DOM is fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// Add interval to check for Vue initialization (some OCUS pages use Vue.js)
function checkForVueInit() {
  // Check if the page uses Vue.js
  const vueElements = document.querySelectorAll('[data-v-id], [data-v-app], [data-v-component]');
  if (vueElements.length > 0) {
    // If Vue elements are found, scan for mission cards
    if (monitorConfig.missionMonitor.enabled) {
      scanForMissionCards();
    }
  }
}

// Periodically check for Vue initialization
setInterval(checkForVueInit, 5000);


/**
 * Update OPENED missions counter in floating panel - ONLY update counters, not form fields
 */
function updateOpenedCounter() {
  try {
    // Get current count from storage and increment
    let currentCount = parseInt(localStorage.getItem('ocus_missions_opened') || '0');
    currentCount = currentCount + 1;
    localStorage.setItem('ocus_missions_opened', currentCount.toString());
    
    // Update panel counter - find the OPENED label and update its number (ONLY in floating panel)
    const openedElements = Array.from(document.querySelectorAll('div')).filter(div => {
      const text = div.textContent?.trim();
      // Make sure this is in the floating panel, not a form field
      const isInFloatingPanel = div.closest('.ocus-floating-panel') || 
                                div.closest('[id*="ocus"]') || 
                                div.closest('[class*="ocus"]') ||
                                (div.parentElement && div.parentElement.textContent && 
                                 div.parentElement.textContent.includes('OPENED') && 
                                 !div.closest('form') && !div.closest('input'));
      return text === 'OPENED' && isInFloatingPanel && div.nextElementSibling && div.nextElementSibling.textContent?.match(/^\d+$/);
    });
    
    openedElements.forEach(openedLabel => {
      const numberDiv = openedLabel.nextElementSibling;
      if (numberDiv && !numberDiv.closest('input') && !numberDiv.closest('form')) {
        numberDiv.textContent = currentCount.toString();
        console.log('[OCUS] Updated OPENED counter to:', currentCount);
      }
    });
    
    // Update Chrome extension stats
    if (typeof chrome !== 'undefined' && chrome.storage) {
      chrome.storage.local.get(['stats'], (result) => {
        let stats = result.stats || { missionsFound: 0, missionsOpened: 0, missionsAccepted: 0, loginAttempts: 0, successfulLogins: 0 };
        stats.missionsOpened = currentCount;
        chrome.storage.local.set({ stats: stats });
      });
    }
    
    // Look for blue number displays for OPENED - ONLY in panels, NOT in forms
    const allDivs = document.querySelectorAll('div:not(form div):not(input *)');
    allDivs.forEach(div => {
      const text = div.textContent?.trim();
      const style = window.getComputedStyle(div);
      
      // Make sure this is NOT an input field or form element
      if (text && text.match(/^\d+$/) && 
          !div.closest('input') && 
          !div.closest('form') && 
          !div.hasAttribute('contenteditable') &&
          div.tagName !== 'INPUT' &&
          div.parentElement?.textContent?.includes('OPENED') && (
        style.color.includes('rgb(59, 130, 246)') || 
        style.color.includes('rgb(37, 99, 235)') ||
        style.color.includes('#3b82f6') ||
        style.color.includes('#2563eb') ||
        div.className.includes('blue')
      )) {
        div.textContent = currentCount.toString();
        console.log('[OCUS] Updated OPENED blue counter to:', currentCount);
      }
    });
    
  } catch (error) {
    console.error('[OCUS] Error updating opened counter:', error);
  }
}

// Function to reset opened counter
function resetOpenedCounter() {
  localStorage.setItem('ocus_missions_opened', '0');
  console.log('[OCUS] OPENED counter reset to 0');
}

// Call updateOpenedCounter whenever a mission is opened
if (typeof window !== 'undefined') {
  window.updateOpenedCounter = updateOpenedCounter;
  window.resetOpenedCounter = resetOpenedCounter;
}
