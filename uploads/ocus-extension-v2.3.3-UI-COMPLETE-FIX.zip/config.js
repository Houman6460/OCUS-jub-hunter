/**
 * OCUS Unified Extension - Configuration (Fixed)
 * 
 * Central configuration file for API endpoints and settings with production URLs
 */

const EXTENSION_CONFIG = {
  // API Configuration
  API: {
    BASE_URL: 'https://jobhunter.one/api', // Production URL
    ENDPOINTS: {
      ACTIVATE: '/activation/validate',
      CHECK_DEMO: '/extension/check',
      USE_TRIAL: '/extension/use-trial'
    },
    TIMEOUT: 8000 // 8 second timeout for better reliability
  },

  // Demo Configuration
  DEMO: {
    MAX_USES: 3,
    STORAGE_KEY: 'demo_usage_data'
  },

  // Activation Configuration
  ACTIVATION: {
    STORAGE_KEY: 'activation_key_data'
  },

  // User ID Configuration
  USER_ID: {
    STORAGE_KEY: 'extension_user_id'
  },

  // Extension Status
  STATUS: {
    STORAGE_KEY: 'extension_status'
  },

  // Version Configuration
  VERSION: {
    TOKEN: 'b7d3f8e2-4a1b-4c7d-9e2f-3d8a5c9e7f1b',
    NUMBER: '2.2.0'
  },

  // Master Activation Keys - Complex Enterprise Level
  MASTER_KEYS: [
    'OCUS-PRO-7X9K-2M8L-QW3R-UNLIMITED-2025',
    'JOBHUNTER-ENTERPRISE-5N4B-8F7G-H1J2-PREMIUM-KEY',
    'UNLIMITED-ACCESS-9P0L-3K5M-6V8C-MASTER-2025',
    'PREMIUM-EXTENSION-4R7T-2Y9U-1I8O-ENTERPRISE-CODE',
    'MASTER-ACTIVATION-8Q5W-6E3R-9T7Y-UNLIMITED-ACCESS',
    'OCUS-ENTERPRISE-1A2S-3D4F-5G6H-PREMIUM-2025',
    'PROFESSIONAL-LICENSE-7Z8X-4C5V-2B6N-MASTER-KEY'
  ],

  // Demo Activation Keys
  DEMO_KEYS: [
    'OCUS-2024-DEMO-KEY',
    'OCUS-TRIAL-2024-EXT',
    'OCUS-UNLIMITED-2024'
  ]
};

// Make config available globally
if (typeof window !== 'undefined') {
  window.EXTENSION_CONFIG = EXTENSION_CONFIG;
}

// Export for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
  module.exports = EXTENSION_CONFIG;
}