// Debug Activation Helper
// This file adds extra debugging to help troubleshoot activation issues

console.log('🔧 DEBUG ACTIVATION LOADED');

// Intercept the activation button click with extra logging
window.addEventListener('DOMContentLoaded', function() {
  console.log('🔧 Debug script DOM ready');
  
  // Wait a bit for popup.js to load
  setTimeout(() => {
    const activateBtn = document.getElementById('activateButton');
    const keyInput = document.getElementById('activationKey');
    
    console.log('🔧 Debug - Activation button:', activateBtn);
    console.log('🔧 Debug - Key input:', keyInput);
    
    if (activateBtn) {
      // Add a second click handler for debugging
      activateBtn.addEventListener('click', function(e) {
        console.log('🎯 DEBUG: Button clicked!', e);
        console.log('🎯 Key value:', keyInput?.value);
        
        // Test with a master key directly
        if (!keyInput.value) {
          console.log('🔧 No key entered, trying master key test...');
          keyInput.value = 'OCUS-PRO-7X9K-2M8L-QW3R-UNLIMITED-2025';
          console.log('🔧 Set master key for testing');
        }
      }, true); // Use capture phase
    }
    
    // Also monitor key input changes
    if (keyInput) {
      keyInput.addEventListener('input', function(e) {
        console.log('🔧 Key input changed:', e.target.value);
      });
    }
  }, 100);
});

// Monitor storage changes
chrome.storage.onChanged.addListener((changes, area) => {
  console.log('🔧 Storage changed:', area, changes);
  if (changes.config?.newValue?.activation?.isActivated) {
    console.log('✅ ACTIVATION DETECTED IN STORAGE!');
  }
});